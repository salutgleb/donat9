// Наличие на складе DONAT9 без DOM: поиск, разбор CSV из опубликованной Google Таблицы,
// загрузка данных с запасным локальным JSON. Нормализация текста, словарь синонимов и тип запчасти
// общие с формой заявки: kind-core.js. Разметку и события держит stock.js.

import { compact, expandToken, foldText } from './kind-core.js';

export { SYNONYMS, TRUCK_PART_PREFIX_RE, compact, detectClue, detectKind, expandToken, foldText } from './kind-core.js';

export const KIND_VALUES = Object.freeze(['marine', 'truck']);
export const SEARCH_LIMIT = 50; // больше строк сразу не рисуем: длинный список на телефоне бесполезен
const FETCH_TIMEOUT_MS = 15000;

const FIELD_GAP = '\u0001'; // разделитель полей в строке поиска: токен не склеит конец артикула с названием

// Заголовки колонок в таблице Доната: русские и английские варианты.
const HEADER_ALIASES = Object.freeze({
  type: ['тип', 'type', 'вид', 'техника'],
  sku: ['артикул', 'sku', 'код', 'article', 'part number', 'номер запчасти', 'номер детали'],
  oem: ['oem', 'оем', 'oem номер', 'номер oem', 'oe'],
  name: ['название', 'наименование', 'name', 'запчасть', 'деталь'],
  maker: ['производитель', 'бренд', 'марка', 'maker', 'brand', 'manufacturer'],
  availability: ['наличие', 'количество', 'кол-во', 'остаток', 'статус', 'qty', 'quantity', 'stock', 'status', 'availability'],
  warehouse: ['склад', 'город', 'warehouse', 'location', 'локация'],
  leadTime: ['срок', 'срок поставки', 'срок доставки', 'lead time', 'leadtime'],
  demo: ['пример', 'демо', 'demo'],
});
const ITEM_FIELDS = Object.freeze(Object.keys(HEADER_ALIASES));
const MARINE_RE = /^(судов|судно|суда|морск|marine|ship|vessel)/;
const TRUCK_RE = /^(грузов|тягач|truck)/;
const YES_VALUES = Object.freeze(['да', 'yes', 'true', '1', 'y', '+', 'пример', 'демо', 'demo']);

function asString(value) {
  return value === null || value === undefined ? '' : String(value);
}

// ---------- Нормализация ----------

function cleanCell(value) {
  return asString(value).replace(/\s+/g, ' ').trim();
}

/** Тип строки: marine, truck или '' (пусто: строка видна в обоих разделах). */
export function parseType(value) {
  const text = cleanCell(value).toLowerCase();
  if (MARINE_RE.test(text) || text === 'marine') return 'marine';
  if (TRUCK_RE.test(text)) return 'truck';
  return '';
}

export function parseFlag(value) {
  if (value === true) return true;
  return YES_VALUES.includes(cleanCell(value).toLowerCase());
}

/** Строка склада в едином виде или null, если в ней нет ни артикула, ни OEM, ни названия. */
export function normalizeItem(raw) {
  const source = raw || {};
  const item = {
    type: parseType(source.type),
    sku: cleanCell(source.sku),
    oem: cleanCell(source.oem),
    name: cleanCell(source.name),
    maker: cleanCell(source.maker),
    availability: cleanCell(source.availability),
    warehouse: cleanCell(source.warehouse),
    leadTime: cleanCell(source.leadTime),
    demo: parseFlag(source.demo),
  };
  return item.sku || item.oem || item.name ? Object.freeze(item) : null;
}

/** Подпись наличия: число превращается в «4 шт.», ноль в «нет на складе», текст остаётся как есть. */
export function availabilityLabel(value, texts) {
  const labels = texts || { pieces: 'шт.', none: 'нет на складе', unknown: 'уточним' };
  const text = cleanCell(value);
  if (!text) return labels.unknown;
  if (/^\d+$/.test(text)) return Number(text) === 0 ? labels.none : Number(text) + ' ' + labels.pieces;
  return text;
}

// ---------- Поиск ----------

/** Строки с заранее посчитанной строкой поиска, чтобы не нормализовать всё на каждое нажатие. */
export function prepareStock(items) {
  return Object.freeze((items || []).map((item, index) => Object.freeze({
    item,
    index,
    codes: [compact(item.sku), compact(item.oem)].filter(Boolean),
    haystack: [item.sku, item.oem, item.name, item.maker].map(compact).join(FIELD_GAP),
  })));
}

function matchesKind(item, kind) {
  return !KIND_VALUES.includes(kind) || item.type === '' || item.type === kind;
}

function score(entry, tokens, whole) {
  if (!tokens.length) return 1;
  if (!tokens.every((token) => expandToken(token).some((form) => entry.haystack.includes(form)))) return 0;
  if (entry.codes.some((code) => code === whole)) return 100;
  if (entry.codes.some((code) => code.startsWith(whole))) return 80;
  if (entry.codes.some((code) => code.includes(whole))) return 60;
  return 40;
}

/**
 * Поиск по артикулу, OEM, названию и производителю. Каждое слово запроса должно найтись.
 * Точное совпадение номера выше, потом начало номера, потом часть номера, потом название.
 * @param {ReturnType<typeof prepareStock>} entries
 * @param {string} query
 * @param {{kind?: string, limit?: number}} [options] kind: marine, truck или all
 * @returns {{total: number, items: Array<Object>}}
 */
export function searchStock(entries, query, options) {
  const settings = options || {};
  const tokens = foldText(query).split(/\s+/).map(compact).filter(Boolean);
  const whole = compact(query);
  const found = (entries || [])
    .filter((entry) => matchesKind(entry.item, settings.kind))
    .map((entry) => ({ entry, rank: score(entry, tokens, whole) }))
    .filter((result) => result.rank > 0)
    .sort((a, b) => b.rank - a.rank || a.entry.index - b.entry.index);
  const limit = settings.limit || SEARCH_LIMIT;
  return Object.freeze({ total: found.length, items: found.slice(0, limit).map((result) => result.entry.item) });
}

// ---------- CSV ----------

/** Разделитель по первой строке: запятая (Google Таблицы), точка с запятой (Excel в России) или табуляция. */
export function detectDelimiter(text) {
  const firstLine = asString(text).split(/\r?\n/, 1)[0] || '';
  const counts = [',', ';', '\t'].map((delimiter) => ({ delimiter, count: firstLine.split(delimiter).length - 1 }));
  const best = counts.reduce((top, item) => (item.count > top.count ? item : top));
  return best.count > 0 ? best.delimiter : ',';
}

/**
 * CSV по RFC 4180: кавычки, "" внутри кавычек, переносы строк внутри ячейки, CRLF, BOM.
 * Пустые строки пропускаются.
 * @returns {Array<Array<string>>}
 */
export function parseCsv(text) {
  const source = asString(text).replace(/^\uFEFF/, '');
  const delimiter = detectDelimiter(source);
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quoted) {
      if (char !== '"') field += char;
      else if (source[index + 1] === '"') {
        field += '"';
        index += 1;
      } else quoted = false;
    } else if (char === '"' && field === '') {
      quoted = true;
    } else if (char === delimiter) {
      row.push(field);
      field = '';
    } else if (char === '\n' || char === '\r') {
      if (char === '\r' && source[index + 1] === '\n') index += 1;
      rows.push(row.concat([field]));
      row = [];
      field = '';
    } else {
      field += char;
    }
  }
  if (field !== '' || row.length) rows.push(row.concat([field]));
  return rows.filter((cells) => cells.some((cell) => cell.trim() !== ''));
}

function normalizeHeader(value) {
  return cleanCell(value).toLowerCase().replace(/ё/g, 'е').replace(/[_\s]+/g, ' ');
}

/** Какая колонка какое поле: {sku: 1, name: 2, ...}. Первая подходящая колонка выигрывает. */
export function mapColumns(headerRow) {
  const headers = (headerRow || []).map(normalizeHeader);
  return Object.freeze(ITEM_FIELDS.reduce((map, field) => {
    const column = headers.findIndex((header) => HEADER_ALIASES[field].includes(header));
    return column === -1 ? map : { ...map, [field]: column };
  }, {}));
}

/**
 * Строки таблицы в строки склада. Первая строка: заголовки.
 * @returns {{items: Array<Object>, skipped: number, error: string}} error 'columns', если нет ни артикула, ни названия
 */
export function itemsFromRows(rows) {
  const list = rows || [];
  if (!list.length) return { items: [], skipped: 0, error: 'columns' };
  const columns = mapColumns(list[0]);
  const hasKey = (field) => Object.prototype.hasOwnProperty.call(columns, field);
  if (!hasKey('sku') && !hasKey('name') && !hasKey('oem')) return { items: [], skipped: list.length - 1, error: 'columns' };
  const items = list.slice(1).map((cells) => normalizeItem(Object.fromEntries(
    Object.entries(columns).map(([field, column]) => [field, cells[column]]),
  )));
  return { items: items.filter(Boolean), skipped: items.filter((item) => !item).length, error: '' };
}

/** Данные из stock.json: {updatedAt, items: [...]} или просто массив строк. */
export function itemsFromJson(data) {
  const list = Array.isArray(data) ? data : (data && Array.isArray(data.items) ? data.items : null);
  if (!list) return { items: [], updatedAt: '', error: 'format' };
  const updatedAt = !Array.isArray(data) && typeof data.updatedAt === 'string' ? data.updatedAt : '';
  return { items: list.map(normalizeItem).filter(Boolean), updatedAt, error: '' };
}

// ---------- Загрузка ----------

async function fetchText(fetchFn, url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const response = await fetchFn(url, { cache: 'no-cache', credentials: 'omit', signal: controller.signal });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    return await response.text();
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Загружает наличие: сначала опубликованный CSV из Google Таблицы, если он задан,
 * при сбое локальный JSON (с пометкой fallback). Не бросает исключений.
 * @param {{csvUrl?: string, jsonUrl?: string, fetchFn?: Function}} options
 * @returns {Promise<{items: Array<Object>, source: ''|'csv'|'json', updatedAt: string, fallback: boolean, error: boolean}>}
 */
export async function loadStock(options) {
  const settings = options || {};
  const fetchFn = settings.fetchFn || globalThis.fetch;
  let csvFailed = false;
  if (settings.csvUrl) {
    try {
      const parsed = itemsFromRows(parseCsv(await fetchText(fetchFn, settings.csvUrl)));
      if (!parsed.error) return { items: parsed.items, source: 'csv', updatedAt: '', fallback: false, error: false };
      csvFailed = true;
    } catch (error) {
      csvFailed = true;
    }
  }
  if (settings.jsonUrl) {
    try {
      const parsed = itemsFromJson(JSON.parse(await fetchText(fetchFn, settings.jsonUrl)));
      if (!parsed.error) {
        return { items: parsed.items, source: 'json', updatedAt: parsed.updatedAt, fallback: csvFailed, error: false };
      }
    } catch (error) {
      // упадём в общий ответ ниже: посетитель увидит путь к заявке
    }
  }
  return { items: [], source: '', updatedAt: '', fallback: false, error: true };
}

// Якорь формы заявки: на сайте одна форма, короткая <form id="ask"> на главной, /marine/ и /truck/ (правки Доната 11.11, Р5).
// Якорь в адресе base важнее: так можно вести и в полную форму #lead-form.
const FORM_ANCHOR = 'ask';
const DEFAULT_REQUEST_PAGE = '/'; // форма главной

/** Ссылка на форму заявки с подставленным номером: /?kind=truck&part=...#ask. */
export function requestHref(base, prefill) {
  const url = new URL(asString(base) || DEFAULT_REQUEST_PAGE, 'https://donat9.com');
  const data = prefill || {};
  const params = new URLSearchParams();
  if (KIND_VALUES.includes(data.kind)) params.set('kind', data.kind);
  if (cleanCell(data.part)) params.set('part', cleanCell(data.part));
  url.search = params.toString();
  url.hash = url.hash || FORM_ANCHOR;
  return /^https?:/i.test(asString(base)) ? url.href : url.pathname + url.search + url.hash;
}

const MONTHS = Object.freeze(['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября',
  'октября', 'ноября', 'декабря']);
const ISO_DATE_RE = /^(\d{4})-(\d{2})-(\d{2})/;

/**
 * Дата для подписи «Остатки на …»: «5 ноября», с годом, если он не текущий. Не ISO (r2-gleb, замечание 2).
 * Непонятная строка остаётся как есть.
 * @param {string} iso «2026-11-05» или «2026-11-05T10:00:00+03:00»
 * @param {number} [now] для тестов
 */
export function formatStockDate(iso, now) {
  const match = ISO_DATE_RE.exec(asString(iso).trim());
  if (!match) return asString(iso).trim();
  const [year, month, day] = [Number(match[1]), Number(match[2]), Number(match[3])];
  if (month < 1 || month > 12 || day < 1 || day > 31) return asString(iso).trim();
  const thisYear = new Date(now === undefined ? Date.now() : now).getFullYear();
  return day + ' ' + MONTHS[month - 1] + (year === thisYear ? '' : ' ' + year);
}

/** Что подставить в заявку по строке склада: «WG9725220362 Турбокомпрессор SITRAK». */
export function partForRequest(item) {
  // У строки-примера марка не подтверждена: в заявку она не уходит (r2-facts, нарушение 2).
  return [item.sku || item.oem, item.name, item.demo ? '' : item.maker].filter(Boolean).join(' ');
}

// ---------- Наличие по заявке: экран после отправки формы (правки Доната 11.11, Р12) ----------

export const MATCH_PER_LINE = 5; // на одну строку поля запчасти: «турбина» не должна вывести весь список
export const MATCH_LIMIT = 20;
const LINE_SPLIT_RE = /\r?\n|;/;
const QUERY_MIN = 3; // «ТН» или «12» нашли бы полсписка

/**
 * Строки наличия по полю запчасти заявки: каждая строка поля (или часть через «;») ищется отдельно, найденное
 * собирается без повторов в порядке строк заявки. Короче трёх знаков строка не ищется.
 * @param {ReturnType<typeof prepareStock>} entries
 * @param {string} text поле «Номер или название запчасти»
 * @param {{kind?: string, perLine?: number, limit?: number}} [options]
 * @returns {ReadonlyArray<Object>} строки склада
 */
export function stockMatches(entries, text, options) {
  const settings = options || {};
  const queries = asString(text).split(LINE_SPLIT_RE).map(cleanCell).filter((line) => compact(line).length >= QUERY_MIN);
  const seen = new Set();
  const found = queries.flatMap((query) => searchStock(entries, query, { kind: settings.kind, limit: settings.perLine || MATCH_PER_LINE }).items)
    .filter((item) => (seen.has(item) ? false : seen.add(item)));
  return Object.freeze(found.slice(0, settings.limit || MATCH_LIMIT));
}

/** Все ли строки списка из примеров (demo): тогда экран говорит «Пример…», а не «остатки». Пустой список: false. */
export function allDemo(items) {
  const list = Array.from(items || []);
  return list.length > 0 && list.every((item) => item.demo);
}
