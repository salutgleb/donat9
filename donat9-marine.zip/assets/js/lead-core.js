// Логика формы заявки DONAT9: проверка полей, тело запроса, отправка с тайм-аутом, разбор ответа сервера,
// черновик для localStorage, текст заявки для мессенджера, тексты форм, подготовка фото и тип запчасти.
// Разметку и события держат lead-form.js (полная форма) и ask.js сайта (короткая): ask.js импортирует
// только отсюда (review/r2-fixes.md, «Интерфейс»). DOM здесь не трогается, кроме подготовки фото
// в браузере (canvas) и класса review у <html>. Правила полей совпадают с validateLead в backend/Code.gs
// и d9_validate_lead в api/lib.php, это проверяют тесты (tests/contract.test.mjs).

import { TEXT } from './lead-text.js';

export { detectClue, detectKind } from './kind-core.js';
export { TEXT };

export const LIMITS = Object.freeze({
  partMax: 1000,
  qtyMax: 40,
  cityMax: 100,
  nameMax: 80,
  companyMax: 120,
  commentMax: 1000,
  nickInputMax: 64,
  emailMax: 254, // RFC 5321
  phoneInputMax: 32,
  phoneDigitsMin: 8,
  phoneDigitsMax: 15, // E.164
  fileCountMax: 5,
  fileBytesMax: 8 * 1024 * 1024,
  minElapsedMs: 3000, // быстрее бэкенд считает форму ботом и молча выбрасывает
  timeoutMs: 40000, // холодный старт Apps Script бывает дольше 20 с (замер на wearesalut.com 23.10.2026)
  timeoutPerMbMs: 8000, // запас на загрузку файлов по медленной мобильной сети
  timeoutMaxMs: 120000,
  draftMaxAgeMs: 14 * 24 * 60 * 60 * 1000,
  summaryMax: 1500, // текст для ссылки WhatsApp: длинный адрес ломается в части браузеров
});

const MB = 1024 * 1024;

export const KINDS = Object.freeze([
  Object.freeze({ value: 'marine', label: 'Судовая' }),
  Object.freeze({ value: 'truck', label: 'Грузовая' }),
]);

export const URGENCY = Object.freeze([
  Object.freeze({ value: 'urgent', label: 'Срочно' }),
  Object.freeze({ value: 'normal', label: 'Обычный срок' }),
  Object.freeze({ value: 'quote', label: 'Пока узнаю цену' }),
]);

export const MESSENGERS = Object.freeze([
  Object.freeze({ value: 'call', label: 'Звонок' }),
  Object.freeze({ value: 'whatsapp', label: 'WhatsApp' }),
  Object.freeze({ value: 'telegram', label: 'Telegram' }),
  Object.freeze({ value: 'max', label: 'Макс' }),
]);

/** Для этих способов связи без телефона не обойтись. */
export const PHONE_MESSENGERS = Object.freeze(['call', 'whatsapp', 'max']);

/**
 * Способы связи короткой формы в порядке Доната (правки 11.11, Р9): почта, Telegram, WhatsApp, Макс, звонок.
 * Выбирают несколько; бэкенду уходят контакты выбранных и один способ в поле messenger (channelsMessenger).
 */
export const CHANNELS = Object.freeze(['email', 'telegram', 'whatsapp', 'max', 'call']);
/** Способы, которым нужен телефон. Telegram годится и с телефоном, и с ником. */
export const PHONE_CHANNELS = Object.freeze(['whatsapp', 'max', 'call']);
export const ADVANCE_MAX = 100; // «Аванс за запчасть, %»: целое от 0 до 100 (Донат)

export const FILE_EXTENSIONS = Object.freeze(['jpg', 'jpeg', 'png', 'webp', 'heic', 'heif', 'pdf', 'xlsx', 'docx',
  'csv', 'txt', 'mp4', 'mov']);
// Видео в заявке (SPEC.md, Р11): MP4 и MOV в общем списке и общем лимите FILES.
export const VIDEO_EXTENSIONS = Object.freeze(['mp4', 'mov']);
// Для выбора файлов: HEIC не перечислен, тогда iPhone обычно сам отдаёт фото в JPEG.
export const FILE_ACCEPT = '.jpg,.jpeg,.png,.webp,.pdf,.xlsx,.csv,.docx,.txt,.mp4,.mov';
// Три кнопки приложения короткой формы (Р11): фото, видео и любой файл, общий список и общий лимит FILES.
export const FILE_ACCEPTS = Object.freeze({ photo: '.jpg,.jpeg,.png,.webp', video: '.mp4,.mov', file: FILE_ACCEPT });

// Какой формат прячется за расширением и как его узнать по первым байтам. Те же сигнатуры проверяют
// оба бэкенда: файл с чужими байтами они отвергают вместе со всей заявкой, поэтому форма ловит его заранее.
const FILE_FAMILIES = Object.freeze({
  jpg: 'jpeg', jpeg: 'jpeg', png: 'png', webp: 'webp', heic: 'heic', heif: 'heic', pdf: 'pdf',
  xlsx: 'zip', docx: 'zip', csv: 'text', txt: 'text', mp4: 'mp4', mov: 'mov',
});
const FTYP = [0x66, 0x74, 0x79, 0x70];
const SIGNATURES = Object.freeze({
  jpeg: [[0, [0xff, 0xd8, 0xff]]],
  png: [[0, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]]],
  webp: [[0, [0x52, 0x49, 0x46, 0x46]], [8, [0x57, 0x45, 0x42, 0x50]]],
  heic: [[4, FTYP]],
  pdf: [[0, [0x25, 0x50, 0x44, 0x46]]],
  zip: [[0, [0x50, 0x4b, 0x03, 0x04]]],
  ole: [[0, [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]]],
});
// ISO BMFF: «ftyp» на 4-м байте, бренд на 8-м. Бренды HEIF значат фото HEIC, остальные видео MP4.
const HEIF_BRANDS = Object.freeze(['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1']);
// QuickTime (.mov): «ftyp» с брендом «qt  » или старый файл без ftyp, который начинается с атома moov, mdat, wide, free.
const QUICKTIME_BRAND = 'qt  ';
const QUICKTIME_ATOMS = Object.freeze(['moov', 'mdat', 'wide', 'free']);
// Видео целиком из атомов: 4 байта размера (big-endian) и 4 знака типа. Чтобы под .mp4 и .mov не прошёл HTML,
// ZIP или программа с подставленными первыми байтами, у первого атома правдоподобный размер (от 8 до конца файла,
// 1 значит 64-битный размер следом), а сразу за ним второй атом известного типа. Всё в первых 4096 байтах:
// дальше форма файл не читает. Те же правила в api/lib.php и Code.gs.
const ATOM_SCAN_BYTES = 4096;
const ATOM_HEADER_BYTES = 8;
const ATOM_LARGE_HEADER_BYTES = 16;
const ATOM_LARGE_SIZE = 1; // размер в 64 битах сразу за типом
const ATOM_TO_END = 0; // атом до конца файла: так бывает у последнего, но не у первого
const FTYP_MIN_BYTES = 16; // размер, тип, бренд и версия
const SECOND_ATOMS = Object.freeze(['moov', 'mdat', 'free', 'skip', 'wide', 'uuid', 'meta', 'moof', 'sidx', 'pdin', 'udta',
  'pnot']);
const UINT32 = 2 ** 32;
const IMAGE_EXTENSIONS = Object.freeze({ jpeg: 'jpg', png: 'png', webp: 'webp', heic: 'heic' });

/** Поля по шагам формы, в порядке на экране: первая ошибка в этом порядке получает фокус. */
// Фото на первом шаге рядом с «что нужно»: у кого нет номера запчасти, тот приложит фото шильдика.
export const STEP_FIELDS = Object.freeze({
  1: Object.freeze(['kind', 'part', 'files', 'qty', 'city', 'urgency']),
  2: Object.freeze(['name', 'phone', 'telegram', 'email', 'contact', 'messenger', 'company', 'comment', 'consent']),
});
export const FIELD_ORDER = Object.freeze([...STEP_FIELDS[1], ...STEP_FIELDS[2]]);

// Поле из ответа сервера и какой текст ошибки ему показать.
const SERVER_FIELD_ERRORS = Object.freeze({
  kind: 'kind',
  files: 'filesType',
  part: 'part',
  qty: 'qtyLong',
  city: 'cityLong',
  urgency: 'urgency',
  name: 'name',
  phone: 'phone',
  telegram: 'telegram',
  email: 'email',
  contact: 'contact',
  messenger: 'messenger',
  company: 'companyLong',
  comment: 'commentLong',
  consent: 'consent',
});

const FILES_STATUSES = Object.freeze(['saved', 'failed', 'skipped']);
const DRAFT_FIELDS = Object.freeze(['kind', 'part', 'qty', 'city', 'urgency', 'name', 'phone', 'telegram', 'email', 'messenger',
  'company', 'comment']);
export const DRAFT_KEY = 'donat9-lead-draft-v1';

const NICK_RE = /^[A-Za-z0-9_]{5,32}$/;
const NICK_LINK_RE = /^(?:https?:\/\/)?(?:www\.)?(?:t|telegram)\.me\//i;
// Почта: что-то@домен.зона, зона и кириллицей (донат9.рф). Тот же шаблон в Code.gs и api/lib.php.
const EMAIL_RE = /^[^\s@<>"'(),;:\\]+@[^\s@<>"'(),;:\\]+\.[^\s@<>"'(),;:\\.]{2,}$/u;
// «Куда ответить» одним полем: ник узнаётся по @ или ссылке t.me, без них по виду (латиница, от 5 знаков).
const NICK_HINT_RE = /^@|(?:^|\/\/|\.|\s)(?:t|telegram)\.me\//i;
const NICK_BARE_RE = /^[A-Za-z][A-Za-z0-9_]{4,31}$/;
// Правила телефона повторяют normalizePhone в Code.gs, тесты держат их одинаковыми.
const PHONE_CHARS_RE = /^\+?[\d\s().\u2010-\u2015-]+$/;
const RU_NATIONAL_RE = /^[3-9]\d{9}$/;
const RU_BARE_NATIONAL_RE = /^[349]\d{9}$/;
const RU_PHONE_PARTS_RE = /^\+7(\d{3})(\d{3})(\d{2})(\d{2})$/;
const CONTROL_CHARS_RE = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u202A-\u202E\u2066-\u2069]/g;
const BOT_RE = /^[A-Za-z0-9_]{5,64}$/;
const LEAD_ID_RE = /^[A-HJ-NP-Z2-9]{5}$/; // ответ ловушки для ботов 00000 сюда не подходит
const START_RE = /^[A-HJ-NP-Z2-9]{5}_[0-9a-f]{32}$/; // номер и случайный ключ для ссылки на бота
const ENDPOINT_RE = /^(?:https?:\/\/|\/)\S+$/; // полный адрес или путь на этом же сайте: /api/lead.php
const FILE_EXT_RE = /\.([A-Za-z0-9]{1,5})$/;
const SHORT_WORD_RE = /^(?:[«„(]?[А-Яа-яЁёA-Za-z]{1,2}|\+?\d+)$/; // «+7» и «900» тоже держатся за следующее слово
const DIGIT_HYPHEN_RE = /(\d)-(?=\d)/g; // только для replace
const NBSP = '\u00A0';
const NB_HYPHEN = '\u2011';

// ---------- Строки ----------

function asString(value) {
  return value === null || value === undefined ? '' : String(value);
}

/** Текст без управляющих символов, переносы строк приведены к \n. Как cleanText в Code.gs. */
export function cleanText(value) {
  return asString(value).replace(/\r\n?/g, '\n').replace(CONTROL_CHARS_RE, '').replace(/\n{3,}/g, '\n\n').trim();
}

/** Одна строка: пробелы и переносы схлопнуты. */
export function cleanLine(value) {
  return cleanText(value).replace(/\s+/g, ' ');
}

/** Неразрывный пробел после коротких слов и чисел и неразрывный дефис внутри чисел, как в вёрстке сайта. */
export function typo(text) {
  const words = asString(text).split(' ');
  return words.reduce((out, word, index) => {
    if (index === 0) return word;
    return out + (SHORT_WORD_RE.test(words[index - 1]) ? NBSP : ' ') + word;
  }, '').replace(DIGIT_HYPHEN_RE, '$1' + NB_HYPHEN);
}

/** «1,2 МБ» или «350 КБ». */
export function formatSize(bytes) {
  const value = Math.max(0, Number(bytes) || 0);
  if (value >= MB) return (Math.round((value / MB) * 10) / 10).toString().replace('.', ',') + ' МБ';
  return Math.max(1, Math.round(value / 1024)) + ' КБ';
}

// ---------- Контакты ----------

/** «anna_k» из «@anna_k», «t.me/anna_k» или «https://t.me/anna_k/». Остальное оставляет проверке. */
export function normalizeNick(value) {
  return cleanLine(value).replace(NICK_LINK_RE, '').replace(/\/+$/, '').replace(/^@/, '');
}

function russianNationalPart(digits, plus) {
  if (plus) return digits.charAt(0) === '7' ? digits.slice(1) : null;
  if (digits.length === 11 && (digits.charAt(0) === '7' || digits.charAt(0) === '8')) return digits.slice(1);
  if (digits.length === 10 && RU_BARE_NATIONAL_RE.test(digits)) return digits;
  return null;
}

/**
 * +7XXXXXXXXXX для российских записей, +<код страны><номер> для остальных.
 * @returns {string|null} '' для пустого поля, null, если это не номер
 */
export function normalizePhone(value) {
  const raw = cleanLine(value);
  if (!raw) return '';
  if (raw.length > LIMITS.phoneInputMax || !PHONE_CHARS_RE.test(raw)) return null;
  const digits = raw.replace(/\D/g, '');
  const plus = raw.charAt(0) === '+';
  const national = russianNationalPart(digits, plus);
  if (national !== null) return RU_NATIONAL_RE.test(national) ? '+7' + national : null;
  if (!plus || digits.length < LIMITS.phoneDigitsMin || digits.length > LIMITS.phoneDigitsMax) return null;
  return '+' + digits;
}

/** «+7 999 123-45-67» из «+79991234567»; иностранный номер как есть. */
export function formatPhone(phone) {
  const text = asString(phone);
  const parts = RU_PHONE_PARTS_RE.exec(text);
  return parts ? '+7 ' + parts[1] + ' ' + parts[2] + '-' + parts[3] + '-' + parts[4] : text;
}

/** Похоже ли на адрес почты: name@company.ru, zakaz@донат9.рф. Не длиннее 254 знаков. */
export function isEmail(value) {
  const text = cleanLine(value);
  return text.length <= LIMITS.emailMax && EMAIL_RE.test(text);
}

/**
 * «Куда ответить» одним полем: телефон, ник в Telegram (@ник, ссылка t.me или просто латиницей) или почта.
 * Текст как есть попадает в своё поле, проверку и нормализацию делают cleanValues и findErrors.
 * @returns {Readonly<{kind: 'phone'|'telegram'|'email'|'', phone: string, telegram: string, email: string}>}
 */
export function parseContact(value) {
  const text = cleanLine(value);
  const empty = { kind: '', phone: '', telegram: '', email: '' };
  if (!text) return Object.freeze(empty);
  if (NICK_HINT_RE.test(text) || NICK_BARE_RE.test(text)) return Object.freeze({ ...empty, kind: 'telegram', telegram: text });
  if (text.includes('@')) return Object.freeze({ ...empty, kind: 'email', email: text });
  return Object.freeze({ ...empty, kind: 'phone', phone: text });
}

const IMO_DIGITS = 7;
const IMO_WEIGHTS = Object.freeze([7, 6, 5, 4, 3, 2]); // первые шесть цифр, последняя цифра суммы равна седьмой
// Число сразу после слова IMO или ИМО («IMO:», «IMO №», «IMO No.»): группы цифр через пробел или дефис.
const IMO_AFTER_WORD_RE = /(?:^|[^\p{L}])(?:imo|имо)(?!\p{L})[\s:#№.-]*(?:no\.?\s*)?(\d+(?:[\s-]\d+)*)/iu;
const IMO_LONE_RE = /(?:^|\D)(\d{7})(?!\d)/; // отдельное число ровно из 7 цифр
const LETTER_RE = /\p{L}/u;

/** Цифры номера после слова IMO: группы подряд, пока не набралось 7 («IMO 9074 729» это 9074729). */
function imoDigitsAfterWord(text) {
  const match = IMO_AFTER_WORD_RE.exec(text);
  if (!match) return '';
  return match[1].split(/[\s-]/).reduce((digits, group) => (digits.length >= IMO_DIGITS ? digits : digits + group), '');
}

/**
 * Мягкая проверка поля «IMO или название судна» (07.11, придирки клиентов, А18; ревью r12, п. 4). Номером считается
 * число сразу после слова IMO, иначе отдельное число ровно из 7 цифр. Такого числа нет, а буквы есть: это название
 * судна, в том числе с цифрами («Волго-Балт 214», «Сормовский-3050»), подсказки нет. В поле одни цифры: проверяются они.
 * Форму не блокирует.
 * @returns {''|'length'|'checksum'} '' (пусто, название или верный номер), 'length' (цифр не 7),
 *   'checksum' (7 цифр, но последняя не сходится с суммой первых шести, умноженных на 7…2)
 */
export function imoProblem(value) {
  const text = cleanLine(value);
  const lone = IMO_LONE_RE.exec(text);
  const named = imoDigitsAfterWord(text) || (lone ? lone[1] : '');
  if (!named && LETTER_RE.test(text)) return '';
  const digits = named || text.replace(/\D/g, '');
  if (!digits) return '';
  if (digits.length !== IMO_DIGITS) return 'length';
  const sum = IMO_WEIGHTS.reduce((total, weight, index) => total + weight * Number(digits[index]), 0);
  return sum % 10 === Number(digits[IMO_DIGITS - 1]) ? '' : 'checksum';
}

/** Годится ли текст как контакт для ответа: телефон, ник в Telegram или почта. */
export function isContact(value) {
  const contact = parseContact(value);
  if (contact.kind === 'phone') return Boolean(normalizePhone(contact.phone));
  if (contact.kind === 'telegram') return NICK_RE.test(normalizeNick(contact.telegram));
  return contact.kind === 'email' && isEmail(contact.email);
}

// ---------- Значения и проверка ----------

const has = (list, value) => list.some((item) => item.value === value);
const labelOf = (list, value) => (list.find((item) => item.value === value) || { label: '' }).label;

/** «Техника: тягач» или ''. */
function kindLine(kind) {
  return Object.prototype.hasOwnProperty.call(TEXT.kindWords, kind) ? TEXT.kindLabel + ': ' + TEXT.kindWords[kind] : '';
}

// ---------- Короткая форма: способы связи, аванс, строки заявки (правки Доната 11.11, SPEC, раздел 4) ----------

/** Выбранные способы связи без чужих значений и повторов, в порядке Доната (CHANNELS). */
export function cleanChannels(list) {
  const picked = new Set(Array.from(list || []).map((item) => asString(item).trim()));
  return Object.freeze(CHANNELS.filter((channel) => picked.has(channel)));
}

/** Какие поля контактов нужны под выбор (Р9): почта для почты, телефон для WhatsApp, Макс, звонка и Telegram, ник для Telegram. */
export function channelFields(channels) {
  const list = cleanChannels(channels);
  return Object.freeze({
    email: list.includes('email'),
    phone: list.some((channel) => channel === 'telegram' || PHONE_CHANNELS.includes(channel)),
    telegram: list.includes('telegram'),
  });
}

/**
 * Один способ для поля messenger бэкенда (там одно значение из MESSENGERS): первый выбранный мессенджер или звонок
 * в порядке Доната. Только почта: ''. Оба бэкенда для WhatsApp, Макс и звонка требуют телефон: его требует и форма.
 */
export function channelsMessenger(channels) {
  return cleanChannels(channels).find((channel) => channel !== 'email') || '';
}

/**
 * Что из контактов уходит бэкенду по выбору (Р9): поле, которое под выбор не нужно, не уходит, даже если в нём
 * что-то осталось. Значения как ввели; нормализует их cleanValues.
 * @param {Array<string>} channels выбранные способы
 * @param {{phone?: string, telegram?: string, email?: string}} raw поля контактов формы
 */
export function channelContacts(channels, raw) {
  const fields = channelFields(channels);
  const source = raw || {};
  return Object.freeze({
    phone: fields.phone ? asString(source.phone) : '',
    telegram: fields.telegram ? asString(source.telegram) : '',
    email: fields.email ? asString(source.email) : '',
    messenger: channelsMessenger(channels),
  });
}

/**
 * Ошибки способов связи (Р9): {поле: ключ текста}. Ни одного способа: channels. Почта выбрана: нужна почта.
 * WhatsApp, Макс, звонок: нужен телефон. Telegram: ник или телефон. values после cleanValues (phone null: не номер).
 */
export function channelErrors(channels, values) {
  const list = cleanChannels(channels);
  if (!list.length) return Object.freeze({ channels: 'channels' });
  const source = values || {};
  const errors = {};
  if (list.includes('email')) {
    if (!source.email) errors.email = 'emailMissing';
    else if (!isEmail(source.email)) errors.email = 'email';
  }
  if (source.phone === null) errors.phone = 'phone';
  else if (!source.phone && list.some((channel) => PHONE_CHANNELS.includes(channel))) errors.phone = 'messengerPhone';
  if (list.includes('telegram')) {
    if (source.telegram && !NICK_RE.test(source.telegram)) errors.telegram = 'telegram';
    else if (!source.telegram && source.phone === '') errors.telegram = 'telegramMissing';
  }
  return Object.freeze(errors);
}

/** «WhatsApp, Макс и звонка» для ошибки «Для … нужен телефон.»: только способы, которым нужен телефон. */
export function phoneChannelsText(channels) {
  const words = cleanChannels(channels).filter((channel) => PHONE_CHANNELS.includes(channel)).map((channel) => TEXT.channelWords[channel]);
  if (words.length < 2) return words[0] || '';
  return words.slice(0, -1).join(', ') + ' и ' + words[words.length - 1];
}

const ADVANCE_RE = /^\d{1,3}$/;

/**
 * «Аванс за запчасть, %»: '' пусто, целое от 0 до 100 строкой без нулей впереди, null, если не так.
 * Знак процента и пробел перед ним прощаются: «30 %» это 30. Пробел внутри числа ошибка: «3 0» не 30.
 */
export function cleanAdvance(value) {
  const text = cleanLine(value).replace(/\s?%$/, '');
  if (!text) return '';
  return ADVANCE_RE.test(text) && Number(text) <= ADVANCE_MAX ? String(Number(text)) : null;
}

/** Короткая форма (Р1): обязательного поля нет, заявка уходит с номером или названием, комментарием или файлом. */
export function hasRequestSubject(part, userComment, files) {
  return Boolean(cleanText(part)) || Boolean(cleanText(userComment)) || Array.from(files || []).length > 0;
}

const pairLine = (label, value) => {
  const text = cleanLine(value);
  return text ? label + ': ' + text : '';
};

// Поля техники по её виду (правки Доната 12.11: «Производитель» без модели, «Марка» и «Модель» раздельно).
const TECH_KEYS = Object.freeze({
  marine: Object.freeze(['imo', 'mech', 'serial']),
  truck: Object.freeze(['vin', 'brand', 'model']),
});
// Условия одной запчасти: срок доставки (у судна), качество, аванс, логистика.
const TERM_KEYS = Object.freeze(['term', 'orig', 'advance', 'logistics']);

/**
 * Пары [ключ, «Поле: значение»] одной запчасти в порядке текста заявки, пустые пропускаются: поля техники,
 * количество и место (у единственной запчасти они уходят своими полями бэкенда, здесь их нет), условия.
 */
function partPairs(kind, fields) {
  const source = fields || {};
  const labels = TEXT.lines;
  const advance = cleanAdvance(source.advance);
  const own = {
    qty: pairLine(labels.qty, source.qty),
    place: pairLine(kind === 'truck' ? labels.city : labels.port, source.place),
    advance: advance ? labels.advance + ': ' + advance + ' %' : '',
  };
  const keys = [...TECH_KEYS[kind === 'truck' ? 'truck' : 'marine'], 'qty', 'place', ...TERM_KEYS];
  return keys.map((key) => [key, key in own ? own[key] : pairLine(labels[key], source[key])]).filter((pair) => pair[1]);
}

/** Строки на всю заявку: счёт с НДС и выбранные способы связи. */
function sharedLines(fields) {
  const labels = TEXT.lines;
  const channels = cleanChannels(fields.channels);
  return [
    fields.vat ? labels.vat + ': ' + labels.vatYes : '',
    channels.length ? labels.channels + ': ' + channels.map((channel) => TEXT.channels[channel]).join(', ') : '',
  ].filter(Boolean);
}

/**
 * Строки короткой формы «Поле: значение» (Р10), пустые пропускаются. tech: поля техники (судно: IMO, производитель,
 * заводской номер; тягач: VIN, марка, модель). terms: срок доставки, качество, аванс, логистика, счёт с НДС,
 * способы связи. У бэкенда для них своих полей нет: они уходят строками комментария (requestComment).
 * @param {{kind?: string, imo?: string, mech?: string, serial?: string, vin?: string, brand?: string, model?: string,
 *   term?: string, orig?: string, advance?: string, logistics?: string, vat?: boolean, channels?: Array<string>}} fields
 * @returns {Readonly<{tech: ReadonlyArray<string>, terms: ReadonlyArray<string>}>}
 */
export function askLines(fields) {
  const source = fields || {};
  const pairs = partPairs(source.kind, { ...source, qty: '', place: '' });
  const pick = (keys) => pairs.filter(([key]) => keys.includes(key)).map(([, line]) => line);
  const tech = pick([...TECH_KEYS.marine, ...TECH_KEYS.truck]);
  return Object.freeze({ tech: Object.freeze(tech), terms: Object.freeze([...pick(TERM_KEYS), ...sharedLines(source)]) });
}

// ---------- Несколько запчастей в одной заявке (правки Доната 12.11, «Добавить запчасть») ----------

/**
 * Заявка из нескольких запчастей одним запросом: контракт POST прежний, поэтому номера уходят списком в поле part,
 * а поля каждой запчасти строками комментария. Строка, одинаковая у всех запчастей (форма подставляет в новую
 * запчасть значения предыдущей), выносится в common и пишется один раз: так заявка умещается в лимит комментария.
 * @param {string} kind
 * @param {Array<{part?: string, qty?: string, place?: string, imo?: string, mech?: string, serial?: string, vin?: string,
 *   brand?: string, model?: string, term?: string, orig?: string, advance?: string, logistics?: string, comment?: string,
 *   files?: Array<{name: string}>}>} parts запчасти в порядке формы
 * @returns {Readonly<{part: string, city: string, common: ReadonlyArray<ReadonlyArray<string>>, blocks: ReadonlyArray<Object>}>}
 *   part: «1) …» списком для поля part; city: место доставки, если оно общее; common: общие пары [ключ, строка];
 *   blocks: {title, part, lines, files, comment} каждой запчасти
 */
export function askParts(kind, parts) {
  const list = Array.from(parts || []);
  const rows = list.map((item) => partPairs(kind, item));
  const isShared = ([key, line]) => rows.every((row) => row.some((pair) => pair[0] === key && pair[1] === line));
  const common = rows.length > 1 ? rows[0].filter(isShared) : [];
  const commonKeys = common.map(([key]) => key);
  const blocks = list.map((item, index) => Object.freeze({
    title: TEXT.lines.partTitle.replace('{n}', String(index + 1)),
    part: oneLine(item.part),
    lines: Object.freeze(rows[index].filter(([key]) => !commonKeys.includes(key)).map(([, line]) => line)),
    files: Object.freeze(Array.from(item.files || [])),
    comment: cleanText(item.comment),
  }));
  return Object.freeze({
    part: blocks.map((block, index) => (index + 1) + ') ' + (block.part || TEXT.partFallback)).join('\n'),
    city: commonKeys.includes('place') ? cleanLine(list[0].place) : '',
    common: Object.freeze(common.map((pair) => Object.freeze(pair))),
    blocks: Object.freeze(blocks),
  });
}

/** Номер запчасти одной строкой: в списке «1) … 2) …» перенос внутри номера читался бы как новая запчасть. */
function oneLine(text) {
  return cleanText(text).split('\n').map((line) => line.trim()).filter(Boolean).join('; ');
}

const commonBlock = (lines) => (lines.length ? [TEXT.lines.partsCommon + ':', ...lines] : []);
const ownComment = (block) => (block.comment ? TEXT.comment + ': ' + block.comment : '');

/**
 * Комментарий бэкенду для заявки из нескольких запчастей: общие строки, блоки «Запчасть N» со своими строками,
 * именами файлов и словами человека, в конце строки на всю заявку. Общее место доставки уходит полем city
 * и здесь не повторяется; запчасть без своих строк пропускается (её номер уже в поле part).
 * @param {ReturnType<typeof askParts>} parsed
 * @param {Array<string>} tail строки на всю заявку: счёт с НДС, способы связи (askLines(...).terms без запчасти)
 */
export function partsComment(parsed, tail) {
  const common = parsed.common.filter(([key]) => !(key === 'place' && parsed.city)).map(([, line]) => line);
  const blocks = parsed.blocks.flatMap((block) => {
    const names = block.files.map((file) => asString(file && file.name)).join(', ');
    const body = [...block.lines, names ? TEXT.lines.files + ': ' + names : '', ownComment(block)].filter(Boolean);
    return body.length ? [block.title, ...body] : [];
  });
  return [...commonBlock(common), ...blocks, ...(tail || [])].filter(Boolean).join('\n');
}

/**
 * Текст заявки из нескольких запчастей для мессенджера, письма и буфера: техника, число запчастей, общие строки,
 * блоки «Запчасть N: номер» с полями, файлами и комментарием, строки на всю заявку, контакты.
 * @param {ReturnType<typeof cleanValues>} values name пустое, если имени не дали
 * @param {ReturnType<typeof askParts>} parsed
 * @param {Array<string>} tail строки на всю заявку
 */
export function partsSummary(values, parsed, tail) {
  const blocks = parsed.blocks.flatMap((block) => [
    block.part ? block.title + ': ' + block.part : block.title,
    ...block.lines,
    filesLine(block.files),
    ownComment(block),
  ]);
  return [
    'Заявка с сайта DONAT9',
    kindLine(values.kind),
    TEXT.lines.partsCount + ': ' + parsed.blocks.length,
    ...commonBlock(parsed.common.map(([, line]) => line)),
    ...blocks,
    ...(tail || []),
    values.name ? 'Имя: ' + values.name : '',
    values.company ? 'Компания: ' + values.company : '',
    values.phone ? 'Телефон: ' + formatPhone(values.phone) : '',
    values.telegram ? 'Telegram: @' + values.telegram : '',
    values.email ? 'Почта: ' + values.email : '',
  ].filter(Boolean).join('\n');
}

/**
 * Комментарий заявки короткой формы одним полем: строки «Поле: значение» (askLines), в конце слова человека
 * «Комментарий: …». У бэкенда для этого своих полей нет (Р10, контракт POST не меняется).
 * @param {Array<string>} lines готовые строки «Поле: значение»
 * @param {string} userComment что человек написал в «Комментарии»
 */
export function requestComment(lines, userComment) {
  const own = cleanText(userComment);
  return [...(lines || []).map(cleanLine), own ? TEXT.comment + ': ' + own : ''].filter(Boolean).join('\n');
}

/**
 * Текст заявки короткой формы для мессенджера, письма и буфера (SPEC, раздел 4): «Нужно», «Техника», поля техники,
 * файлы (рано: длинная ссылка режется с конца), количество и место, строки Р10, контакты, комментарий.
 * Имя, компания и контакты в ссылку мессенджера не идут (chatText в contactLinks), в письмо и буфер идут.
 * @param {ReturnType<typeof cleanValues>} values part без запасной строки, name пустое, если имени не дали
 * @param {ReturnType<typeof askLines>} lines
 * @param {string} userComment
 * @param {Array<{name: string}>} [files]
 */
export function askSummary(values, lines, userComment, files) {
  const own = cleanText(userComment);
  const place = values.kind === 'truck' ? TEXT.lines.city : TEXT.lines.port;
  // Срок доставки первым в lines.terms: в тексте он встаёт сразу за местом доставки.
  return [
    'Заявка с сайта DONAT9',
    values.part ? 'Нужно: ' + values.part : '',
    kindLine(values.kind),
    ...lines.tech,
    filesLine(files),
    values.qty ? TEXT.lines.qty + ': ' + values.qty : '',
    values.city ? place + ': ' + values.city : '',
    ...lines.terms,
    values.name ? 'Имя: ' + values.name : '',
    values.company ? 'Компания: ' + values.company : '',
    values.phone ? 'Телефон: ' + formatPhone(values.phone) : '',
    values.telegram ? 'Telegram: @' + values.telegram : '',
    values.email ? 'Почта: ' + values.email : '',
    own ? TEXT.comment + ': ' + own : '',
  ].filter(Boolean).join('\n');
}

/**
 * Введённое, подготовленное к проверке и отправке.
 * phone: '' пусто, null не номер, иначе +7XXXXXXXXXX. email: как ввели, без лишних пробелов.
 */
export function cleanValues(raw) {
  const source = raw || {};
  return Object.freeze({
    kind: asString(source.kind).trim(),
    part: cleanText(source.part),
    qty: cleanLine(source.qty),
    city: cleanLine(source.city),
    urgency: asString(source.urgency).trim(),
    name: cleanLine(source.name),
    phone: normalizePhone(source.phone),
    telegram: normalizeNick(source.telegram),
    email: cleanLine(source.email),
    messenger: asString(source.messenger).trim(),
    company: cleanLine(source.company),
    comment: cleanText(source.comment),
    consent: Boolean(source.consent),
    hp: asString(source.hp),
  });
}

/** Лимиты файлов из config.js, но не выше, чем примет бэкенд. */
export function fileRules(config) {
  const source = config || {};
  const count = Number(source.maxCount);
  const mb = Number(source.maxTotalMb);
  return Object.freeze({
    enabled: source.enabled !== false,
    maxCount: Number.isFinite(count) && count > 0 ? Math.min(Math.floor(count), LIMITS.fileCountMax) : LIMITS.fileCountMax,
    maxBytes: Number.isFinite(mb) && mb > 0 ? Math.min(Math.floor(mb * MB), LIMITS.fileBytesMax) : LIMITS.fileBytesMax,
  });
}

/**
 * Лимит в мегабайтах для текста: вниз до десятых, «8», «7,5», «0,4». Вверх округлять нельзя: при 7,5 МБ
 * «до 8 МБ» обещает больше, чем примет форма. Сотые от Math.floor(мегабайты × MB) в fileRules не роняют десятую.
 */
export function limitMb(maxBytes) {
  const tenths = Math.floor(Math.round((Number(maxBytes) || 0) / MB * 1000) / 100);
  return String(tenths / 10).replace('.', ',');
}

/** «До 5 файлов, всего до 8 МБ.»: числа из FILES в config.js через fileRules, не выше лимитов бэкенда. */
export function filesLimitText(rules) {
  const limits = rules || fileRules();
  const count = limits.maxCount;
  const word = count % 10 === 1 && count % 100 !== 11 ? TEXT.filesWords[0] : TEXT.filesWords[1];
  return TEXT.filesLimit.replace('{count}', String(count)).replace('{files}', word)
    .replace('{mb}', limitMb(limits.maxBytes));
}

export function fileExtension(name) {
  const match = FILE_EXT_RE.exec(asString(name));
  return match ? match[1].toLowerCase() : '';
}

/** Четыре знака ASCII с этого места или '', если байтов меньше. */
function asciiAt(head, offset) {
  const bytes = head.slice(offset, offset + 4);
  return bytes.length === 4 ? String.fromCharCode(...bytes) : '';
}

/** Бренд ISO BMFF (4 знака после «ftyp») или '', если файл начинается не с ftyp. */
function isoBrand(head) {
  return asciiAt(head, 4) === 'ftyp' ? asciiAt(head, 8) : '';
}

function uint32At(head, offset) {
  return head[offset] * 2 ** 24 + (head[offset + 1] << 16) + (head[offset + 2] << 8) + head[offset + 3];
}

/** Атом с этого места: {size, type} или null, если заголовок не в первых 4096 байтах или размер неправдоподобен. */
function atomAt(head, offset, fileSize, first) {
  const scan = Math.min(head.length, ATOM_SCAN_BYTES);
  if (offset + ATOM_HEADER_BYTES > scan) return null;
  const declared = uint32At(head, offset);
  const type = asciiAt(head, offset + 4);
  if (declared === ATOM_LARGE_SIZE) {
    if (offset + ATOM_LARGE_HEADER_BYTES > scan) return null;
    const size = uint32At(head, offset + 8) * UINT32 + uint32At(head, offset + 12);
    return size >= ATOM_LARGE_HEADER_BYTES && offset + size <= fileSize ? { size, type } : null;
  }
  if (declared === ATOM_TO_END) return first ? null : { size: fileSize - offset, type };
  return declared >= ATOM_HEADER_BYTES && offset + declared <= fileSize ? { size: declared, type } : null;
}

/** Первый атом видео, если и он, и следующий за ним правдоподобны; иначе null. */
function firstVideoAtom(head, fileSize) {
  const first = atomAt(head, 0, fileSize, true);
  const second = first ? atomAt(head, first.size, fileSize, false) : null;
  return second && SECOND_ATOMS.includes(second.type) ? first : null;
}

function matchesVideo(head, family, fileSize) {
  const first = firstVideoAtom(head, fileSize);
  if (!first) return false;
  const brand = first.type === 'ftyp' && first.size >= FTYP_MIN_BYTES ? asciiAt(head, 8) : '';
  if (family === 'mov') return brand === QUICKTIME_BRAND || QUICKTIME_ATOMS.includes(first.type);
  return brand !== '' && !HEIF_BRANDS.includes(brand); // фото HEIC под .mp4 не видео
}

function matchesSignature(head, family, fileSize) {
  if (family === 'text') return head.length > 0 && !head.slice(0, 4096).includes(0);
  if (family === 'mp4' || family === 'mov') return matchesVideo(head, family, fileSize);
  const signed = (SIGNATURES[family] || []).length > 0 && SIGNATURES[family].every(([offset, bytes]) =>
    bytes.every((value, index) => head[offset + index] === value));
  if (!signed) return false;
  return family !== 'heic' || HEIF_BRANDS.includes(isoBrand(head));
}

/** Видео ли это по имени файла: MP4 или MOV. Для формы: кнопка «Видео», текст про лимит для видео. */
export function isVideo(name) {
  return VIDEO_EXTENSIONS.includes(fileExtension(name));
}

/** Видео, которое форма не возьмёт (Р11): одно оно тяжелее общего лимита FILES. */
export function isVideoTooBig(file, rules) {
  const limits = rules || fileRules();
  return Boolean(file) && isVideo(file.name) && Number(file.size) > limits.maxBytes;
}

/** «Видео тяжелее 8 МБ форма не примет…»: лимит из FILES через fileRules, вниз до десятых, как в подсказке. */
export function videoTooBigText(rules) {
  return TEXT.videoTooBig.replace('{mb}', limitMb((rules || fileRules()).maxBytes));
}

/**
 * Проверка первых байтов файла против его расширения. Фото с неверным расширением (PNG, сохранённый
 * как .jpg) переименовывается под настоящий формат, остальное с чужими байтами помечается неверным.
 * @param {string} name имя файла
 * @param {Uint8Array|Array<number>} head первые байты, лучше 4096
 * @param {number} [size] размер всего файла: по нему проверяются размеры атомов видео; без него длина head
 * @returns {{valid: boolean, name: string}}
 */
export function checkFileBytes(name, head, size) {
  const bytes = Array.from(head || []);
  const fileSize = Number.isFinite(size) && size >= bytes.length ? size : bytes.length;
  const family = FILE_FAMILIES[fileExtension(name)];
  if (!family) return { valid: false, name: asString(name) };
  if (matchesSignature(bytes, family, fileSize)) return { valid: true, name: asString(name) };
  const actual = IMAGE_EXTENSIONS[family] ? Object.keys(IMAGE_EXTENSIONS).find((image) => matchesSignature(bytes, image)) : '';
  if (!actual) return { valid: false, name: asString(name) };
  const base = asString(name).replace(/\.[A-Za-z0-9]{1,5}$/, '');
  return { valid: true, name: (base || 'photo') + '.' + IMAGE_EXTENSIONS[actual] };
}

/**
 * Ключ ошибки для списка файлов [{name, size, valid?}] или ''. valid: false ставит checkFileBytes.
 * @returns {''|'filesCount'|'filesType'|'filesMismatch'|'filesEmpty'|'filesSize'}
 */
export function checkFiles(files, rules) {
  const list = files || [];
  const limits = rules || fileRules();
  if (list.length > limits.maxCount) return 'filesCount';
  if (list.some((file) => !FILE_EXTENSIONS.includes(fileExtension(file.name)))) return 'filesType';
  if (list.some((file) => file.valid === false)) return 'filesMismatch';
  if (list.some((file) => !(file.size > 0))) return 'filesEmpty';
  const total = list.reduce((sum, file) => sum + file.size, 0);
  return total > limits.maxBytes ? 'filesSize' : '';
}

const PREVIEW_EXTENSIONS = Object.freeze(['jpg', 'jpeg', 'png', 'webp']);

/**
 * Показывать ли миниатюру приложенного файла: проверенное фото JPEG, PNG или WebP (07.11, придирки клиентов, А17).
 * HEIC браузер обычно не рисует, документам миниатюра не нужна: у них остаётся имя. Имя после checkFileBytes
 * говорит о настоящем формате (PNG, сохранённый как .jpg, уже .png).
 * @param {{name: string, valid?: boolean, blob?: Blob}} file подготовленный файл (prepareFile)
 */
export function isPreviewable(file) {
  return Boolean(file && file.blob) && file.valid !== false && PREVIEW_EXTENSIONS.includes(fileExtension(file.name));
}

/**
 * Текст ошибки файлов с числами из правил и именем файла (07.11, придирки клиентов, А5): для filesType первый файл
 * с чужим расширением, для остальных первый с чужими байтами. Назвать нечего (файл отверг сервер): общий текст.
 * @param {string} key ключ из checkFiles или ответа сервера
 * @param {Array<{name: string, valid?: boolean}>} [files] файлы формы
 */
export function filesErrorText(key, files, rules) {
  const list = Array.from(files || []);
  const limits = rules || fileRules();
  const bad = key === 'filesType'
    ? list.find((file) => !FILE_EXTENSIONS.includes(fileExtension(file.name)))
    : list.find((file) => file.valid === false);
  const name = bad ? asString(bad.name) : '';
  const template = key === 'filesType' && name ? TEXT.errors.filesTypeNamed : TEXT.errors[key];
  const values = { count: String(limits.maxCount), mb: limitMb(limits.maxBytes), name };
  return asString(template).replace(/\{(count|mb|name)\}/g, (_, field) => values[field]);
}

function lengthError(value, max, key) {
  return value.length > max ? key : '';
}

/**
 * Ошибки полей: {поле: ключ текста ошибки}. Те же правила, что validateLead в Code.gs.
 * @param {ReturnType<typeof cleanValues>} values
 * @param {Array<{name: string, size: number}>} [files] уже подготовленные файлы
 */
export function findErrors(values, files, rules) {
  const list = files || [];
  const email = values.email || '';
  const contactMissing = values.phone === '' && values.telegram === '' && email === '';
  const needsPhone = values.phone === '' && !contactMissing && PHONE_MESSENGERS.includes(values.messenger);
  const partMissing = !values.part && list.length === 0;
  const checks = [
    ['kind', has(KINDS, values.kind) ? '' : 'kind'],
    ['part', partMissing ? 'part' : lengthError(values.part, LIMITS.partMax, 'partLong')],
    ['qty', lengthError(values.qty, LIMITS.qtyMax, 'qtyLong')],
    ['city', lengthError(values.city, LIMITS.cityMax, 'cityLong')],
    ['urgency', values.urgency && !has(URGENCY, values.urgency) ? 'urgency' : ''],
    ['name', values.name ? lengthError(values.name, LIMITS.nameMax, 'nameLong') : 'name'],
    ['phone', values.phone === null ? 'phone' : (needsPhone ? 'messengerPhone' : '')],
    ['telegram', values.telegram !== '' && !NICK_RE.test(values.telegram) ? 'telegram' : ''],
    ['email', email !== '' && !isEmail(email) ? 'email' : ''],
    ['contact', contactMissing ? 'contact' : ''],
    ['messenger', values.messenger && !has(MESSENGERS, values.messenger) ? 'messenger' : ''],
    ['company', lengthError(values.company, LIMITS.companyMax, 'companyLong')],
    ['comment', lengthError(values.comment, LIMITS.commentMax, 'commentLong')],
    ['files', checkFiles(list, rules)],
    ['consent', values.consent ? '' : 'consent'],
  ];
  return Object.freeze(Object.fromEntries(checks.filter((check) => check[1])));
}

/** Ошибки только этого шага: для кнопки «Дальше». */
export function errorsForStep(errors, step) {
  const fields = STEP_FIELDS[step] || [];
  return Object.freeze(Object.fromEntries(Object.entries(errors).filter(([field]) => fields.includes(field))));
}

/** Первое по порядку на экране поле с ошибкой или ''. */
export function firstErrorField(errors) {
  return FIELD_ORDER.find((field) => Boolean(errors[field])) || '';
}

/** На каком шаге поле: 1 или 2. */
export function stepOf(field) {
  return STEP_FIELDS[1].includes(field) ? 1 : 2;
}

// ---------- Запрос и ответ ----------

/**
 * Тело POST, одно для любого бэкенда за ENDPOINT (Apps Script или обработчик на российском хостинге).
 * URLSearchParams оставляет запрос простым, без preflight, который Apps Script не обрабатывает.
 * @param {Array<{name: string, data: string}>} [files] base64 без префикса data:
 * @param {string} [consentVersion] версия текста согласия для журнала согласий
 */
export function buildBody(values, files, elapsedMs, page, consentVersion) {
  const list = files || [];
  const entries = [
    ['kind', values.kind],
    ['part', values.part],
    ['qty', values.qty],
    ['city', values.city],
    ['urgency', values.urgency],
    ['name', values.name],
    ['phone', values.phone || ''],
    ['telegram', values.telegram],
    ['email', values.email || ''],
    ['messenger', values.messenger],
    ['company', values.company],
    ['comment', values.comment],
    ['consent', values.consent ? '1' : ''],
    ['hp', values.hp],
    ['elapsed', String(Math.round(elapsedMs))],
    ['page', asString(page)],
    ['consent_version', asString(consentVersion)],
  ];
  const fileEntry = list.length ? [['files', JSON.stringify(list.map((file) => ({ name: file.name, data: file.data })))]] : [];
  return new URLSearchParams(entries.concat(fileEntry));
}

/** Сколько ждать ответа: 40 с плюс запас на каждый мегабайт тела, но не больше 2 минут. */
export function requestTimeoutMs(bodyBytes) {
  const extra = Math.floor(Math.max(0, Number(bodyBytes) || 0) / MB) * LIMITS.timeoutPerMbMs;
  return Math.min(LIMITS.timeoutMaxMs, LIMITS.timeoutMs + extra);
}

/** Задан ли адрес приёма заявок. Пустой или странный адрес значит «форма не подключена». */
export function isEndpointSet(endpoint) {
  return ENDPOINT_RE.test(asString(endpoint).trim());
}

/**
 * Ссылка t.me на бота с номером заявки и ключом или '', если сервер бота не назвал или ответ странный.
 * Только из ответа сервера: у бэкенда на российском хостинге бота нет, и номер его заявки боту неизвестен.
 */
export function botLink(serverBot, start) {
  const name = asString(serverBot).trim().replace(/^@/, '');
  return BOT_RE.test(name) && START_RE.test(asString(start)) ? 'https://t.me/' + name + '?start=' + start : '';
}

/**
 * Что ответ сервера значит для посетителя.
 * @returns {{type: 'success', id: string, bot: string, files: string}
 *   | {type: 'field', field: string, key: string}
 *   | {type: 'rate'|'server'|'unreadable'}}
 */
export function readResult(data) {
  if (!data || typeof data !== 'object') return { type: 'unreadable' };
  if (data.ok === true) {
    const id = asString(data.id);
    if (!LEAD_ID_RE.test(id)) return { type: 'unreadable' };
    const files = FILES_STATUSES.includes(data.files) ? data.files : '';
    const start = asString(data.start).startsWith(id + '_') ? data.start : '';
    return { type: 'success', id, bot: botLink(data.bot, start), files };
  }
  if (data.error === 'validation' && Object.prototype.hasOwnProperty.call(SERVER_FIELD_ERRORS, data.field)) {
    return { type: 'field', field: data.field, key: SERVER_FIELD_ERRORS[data.field] };
  }
  if (data.error === 'rate' || data.error === 'server') return { type: data.error };
  return { type: 'unreadable' };
}

async function readJson(response) {
  try {
    return JSON.parse(await response.text());
  } catch (error) {
    return null; // страница прокси или HTML-ошибка Google: посетитель получит прямые контакты
  }
}

/**
 * Отправляет заявку. Не бросает исключений: любой исход становится типом результата.
 * Без ENDPOINT сразу отвечает {type: 'offline'} и в сеть не ходит.
 * @param {{endpoint: string, body: URLSearchParams, timeoutMs?: number, fetchFn?: Function}} request
 */
export async function sendLead(request) {
  if (!isEndpointSet(request.endpoint)) return { type: 'offline' };
  const fetchFn = request.fetchFn || globalThis.fetch;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), request.timeoutMs || LIMITS.timeoutMs);
  try {
    const response = await fetchFn(request.endpoint.trim(), {
      method: 'POST',
      body: request.body,
      redirect: 'follow', // Apps Script отвечает через редирект на googleusercontent.com
      credentials: 'omit',
      cache: 'no-store',
      signal: controller.signal,
    });
    return readResult(await readJson(response));
  } catch (error) {
    return { type: error && error.name === 'AbortError' ? 'timeout' : 'network' };
  } finally {
    clearTimeout(timer);
  }
}

// ---------- Черновик ----------

/**
 * Черновик формы для localStorage: только то, что человек ввёл. Согласие, ловушка и файлы не хранятся.
 * @returns {string} JSON или '', если сохранять нечего
 */
export function serializeDraft(raw, now) {
  const source = raw || {};
  const fields = Object.fromEntries(DRAFT_FIELDS.map((name) => [name, asString(source[name]).slice(0, LIMITS.commentMax)]));
  const meaningful = DRAFT_FIELDS.some((name) => name !== 'kind' && fields[name].trim() !== '');
  return meaningful ? JSON.stringify({ v: 1, savedAt: Number(now) || 0, fields }) : '';
}

/** Поля черновика или null, если его нет, он испорчен или старше maxAgeMs. */
export function parseDraft(text, now, maxAgeMs) {
  if (!text) return null;
  let data;
  try {
    data = JSON.parse(text);
  } catch (error) {
    return null;
  }
  if (!data || data.v !== 1 || !data.fields || typeof data.fields !== 'object') return null;
  const age = Number(now) - Number(data.savedAt);
  if (!(age >= 0) || age > (maxAgeMs || LIMITS.draftMaxAgeMs)) return null;
  return Object.freeze(Object.fromEntries(DRAFT_FIELDS.map((name) => [name, asString(data.fields[name])])));
}

/** Подстановка из адреса страницы: /request/?kind=truck&part=WG9725220362. */
export function prefillFromSearch(search) {
  const params = new URLSearchParams(asString(search));
  const kind = asString(params.get('kind')).trim();
  return Object.freeze({
    kind: has(KINDS, kind) ? kind : '',
    part: cleanText(params.get('part')).slice(0, LIMITS.partMax),
    qty: cleanLine(params.get('qty')).slice(0, LIMITS.qtyMax),
  });
}

// ---------- Запасной путь: заявка в мессенджер ----------

/**
 * Заявка полной формы обычным текстом, чтобы вставить в WhatsApp, Telegram или Макс: запчасть и техника первыми.
 * files: приложенные файлы. Строка «Файлы: …» встаёт сразу после техники, чтобы длинная заявка не потеряла её,
 * когда ссылка режет текст до LIMITS.summaryMax (ревью r12, п. 2). Короткая форма сайта пишет текст askSummary.
 * @param {Array<{name: string}>} [files]
 */
export function summaryText(values, files) {
  const lines = [
    'Заявка с сайта DONAT9',
    values.part ? 'Нужно: ' + values.part : '',
    kindLine(values.kind),
    filesLine(files),
    values.qty ? 'Количество: ' + values.qty : '',
    values.city ? 'Куда: ' + values.city : '',
    values.urgency ? 'Срочность: ' + labelOf(URGENCY, values.urgency) : '',
    values.name ? 'Имя: ' + values.name : '',
    values.company ? 'Компания: ' + values.company : '',
    values.phone ? 'Телефон: ' + formatPhone(values.phone) : '',
    values.telegram ? 'Telegram: @' + values.telegram : '',
    values.email ? 'Почта: ' + values.email : '',
    values.messenger ? 'Удобнее: ' + labelOf(MESSENGERS, values.messenger) : '',
    values.comment ? 'Комментарий: ' + values.comment : '',
  ];
  return lines.filter(Boolean).join('\n');
}

/**
 * Строка текста заявки о приложенных файлах: ссылка в мессенджер или письмо файлы не несёт, поэтому человек
 * приложит их сам, а Донат по именам увидит, что ждать (07.11, придирки клиентов, А1). Без файлов ''.
 * @param {Array<{name: string}>} [files] подготовленные файлы формы
 */
export function filesLine(files) {
  const list = Array.from(files || []);
  if (!list.length) return '';
  const names = list.map((file) => asString(file && file.name)).join(', ');
  // Замена функцией: «$&» в имени файла строковая замена приняла бы за шаблон.
  return TEXT.filesLine.replace('{count}', String(list.length)).replace('{names}', () => names);
}

function cutForLink(text) {
  const chars = Array.from(asString(text));
  return chars.length <= LIMITS.summaryMax ? chars.join('') : chars.slice(0, LIMITS.summaryMax - 1).join('') + '…';
}

const MAIL_SUBJECT = 'Заявка с сайта DONAT9';

// Образцы для заглушек tbc, когда контакт не задан. Образец почты не похож на настоящий адрес (r2-fixes, п. 2).
export const CONTACT_SAMPLES = Object.freeze({ telegram: '@donat9', phone: '+7 900 000-00-00', email: 'почта появится к запуску' });
const CONTACT_ORDER = Object.freeze(['telegram', 'whatsapp', 'max', 'phone', 'email']);
// Ссылка, которая сама подставляет текст заявки: в чат Telegram и WhatsApp, в письмо. В профиль Макса и в звонок нет.
export const PREFILLED_KINDS = Object.freeze(['telegram', 'whatsapp', 'email']);
const CONTACT_QUESTIONS = Object.freeze({
  telegram: 'в каком мессенджере принимаешь заявки: Telegram, WhatsApp, Макс',
  phone: 'телефон для звонков',
  email: 'почта для заявок',
});

/** Вопрос Донату из CONTACTS.tbc для этого контакта или ''. */
function contactQuestion(source, kind) {
  const tbc = source.tbc && typeof source.tbc === 'object' ? source.tbc : {};
  return typeof tbc[kind] === 'string' ? tbc[kind] : '';
}

// Строки с контактами посетителя из summaryText. В чат Telegram и WhatsApp они не идут: человек пишет со своего
// аккаунта, а согласие обещает, что данные за рубеж не передаются (santa-d, предложение 5). В письмо идут как есть.
// «Компания» тоже: у ИП там фамилия, имя и отчество (ревью r12, п. 7).
const VISITOR_LINE_RE = /^(?:Имя|Компания|Телефон|Telegram|Почта): /;
const chatText = (text) => asString(text).split('\n').filter((line) => !VISITOR_LINE_RE.test(line)).join('\n');

const withText = (href, name, message) => (message ? href + (href.includes('?') ? '&' : '?') + name + '=' + encodeURIComponent(message) : href);

/**
 * Живые ссылки для связи из CONTACTS в config.js: только заданные значения, странные пропускаются.
 * Telegram и WhatsApp открывают чат с текстом заявки (t.me/<ник>?text=, core.telegram.org/api/links),
 * почта открывает письмо с темой и текстом. question: вопрос из CONTACTS.tbc, если контакт ещё под вопросом
 * (тогда ссылку оборачивают в span.tbc).
 * @returns {ReadonlyArray<{kind: string, href: string, label: string, question: string}>}
 */
export function contactLinks(contacts, text) {
  const source = contacts || {};
  const phone = normalizePhone(source.phone) || '';
  // WhatsApp только явно заданный: телефон ещё не значит, что Донат отвечает в WhatsApp.
  const whatsappPhone = normalizePhone(source.whatsapp) || '';
  const nick = normalizeNick(source.telegram);
  const max = asString(source.max).trim();
  const email = cleanLine(source.email);
  const message = cutForLink(text);
  const chat = cutForLink(chatText(text)); // без имени, телефона, ника и почты посетителя
  const mailto = 'mailto:' + email + '?subject=' + encodeURIComponent(MAIL_SUBJECT);
  const links = {
    telegram: NICK_RE.test(nick) ? { href: withText('https://t.me/' + nick, 'text', chat), label: 'Telegram @' + nick } : null,
    whatsapp: whatsappPhone ? { href: withText('https://wa.me/' + whatsappPhone.replace(/\D/g, ''), 'text', chat), label: 'WhatsApp' } : null,
    max: /^https:\/\/\S+$/.test(max) ? { href: max, label: 'Макс' } : null,
    phone: phone ? { href: 'tel:' + phone, label: formatPhone(phone) } : null,
    email: isEmail(email) ? { href: withText(mailto, 'body', message), label: email } : null,
  };
  return Object.freeze(CONTACT_ORDER.filter((kind) => links[kind]).map((kind) => Object.freeze({
    kind, ...links[kind], question: contactQuestion(source, kind),
  })));
}

/** Режим проверки ?review=1: класс review на <html> ставит встроенный скрипт head.html сайта (только на превью). */
export function isReviewMode() {
  const root = globalThis.document && globalThis.document.documentElement;
  return Boolean(root && root.classList && root.classList.contains('review'));
}

/**
 * Как связаться без формы: живые ссылки из contactLinks (live: true). Незаданные telegram, phone и email
 * показываются образцами tbc с вопросом Донату только в режиме проверки (r2-fixes, «Интерфейс»), в обычном
 * режиме их нет совсем. Неактивных кнопок не бывает.
 * @param {{review?: boolean}} [options] review по умолчанию из isReviewMode()
 * @returns {ReadonlyArray<{kind: string, live: boolean, href: string, label: string, question: string}>}
 */
export function contactSlots(contacts, text, options) {
  const source = contacts || {};
  const review = options && typeof options.review === 'boolean' ? options.review : isReviewMode();
  const live = contactLinks(source, text).map((link) => Object.freeze({ ...link, live: true }));
  const pending = review ? ['telegram', 'phone', 'email'].filter((kind) => !live.some((link) => link.kind === kind))
    .map((kind) => Object.freeze({ kind, live: false, href: '', label: CONTACT_SAMPLES[kind],
      question: contactQuestion(source, kind) || CONTACT_QUESTIONS[kind] })) : [];
  return Object.freeze([...live, ...pending]);
}

/**
 * Сколько знаков осталось человеку в комментарии, если часть места заняли служебные строки:
 * короткая форма шлёт строки своих полей и сам комментарий одним полем comment (r2-code, находка 6).
 * @param {string} serviceText всё, что встанет перед словами человека, вместе с подписью «Комментарий: »
 */
export function commentRoom(serviceText) {
  const used = cleanText(serviceText).length;
  return Math.max(0, LIMITS.commentMax - used - (used ? 1 : 0));
}

// ---------- Фото и файлы в браузере ----------
// Нужны обеим формам. Работают только при вызове: импорт модуля в Node ничего из браузера не требует.

const IMAGE_MAX_SIDE = 2000; // шильдик читается, а фото с телефона весит в разы меньше
const IMAGE_QUALITY = 0.82;
const IMAGE_SHRINK_FROM = 400 * 1024;
const HEAD_BYTES = 4096;
const BASE64_CHUNK = 0x8000;
let fileSeq = 0;

function jpgName(name) {
  const base = asString(name).replace(/\.[A-Za-z0-9]{1,5}$/, '');
  return (base || 'photo') + '.jpg';
}

/** Фото больше 400 КБ сжимается до 2000 px по большей стороне в JPEG; если не вышло меньше, остаётся как было. */
async function shrinkImage(file) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < IMAGE_SHRINK_FROM || typeof createImageBitmap !== 'function') {
    return file;
  }
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, IMAGE_MAX_SIDE / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = globalThis.document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  context.fillStyle = '#ffffff'; // прозрачный PNG в JPEG без белой подложки стал бы чёрным
  context.fillRect(0, 0, width, height);
  context.drawImage(bitmap, 0, 0, width, height);
  if (typeof bitmap.close === 'function') bitmap.close();
  const blob = await new Promise((resolve) => {
    canvas.toBlob(resolve, 'image/jpeg', IMAGE_QUALITY);
  });
  if (!blob || blob.size >= file.size) return file;
  return new File([blob], jpgName(file.name), { type: 'image/jpeg', lastModified: Date.now() });
}

/**
 * Готовит файл к заявке: сжимает фото и сверяет первые байты с расширением, как это сделает сервер.
 * Сжатие не удалось: файл уходит как был. Файл не читается: valid false, форма покажет ошибку.
 * @param {File} file
 * @returns {Promise<Readonly<{id: string, name: string, size: number, valid: boolean, blob: Blob}>>}
 */
export async function prepareFile(file) {
  const ready = await shrinkImage(file).catch(() => file);
  const head = new Uint8Array(await ready.slice(0, HEAD_BYTES).arrayBuffer().catch(() => new ArrayBuffer(0)));
  const checked = checkFileBytes(ready.name || file.name, head, ready.size);
  fileSeq += 1;
  return Object.freeze({ id: 'f' + fileSeq, name: checked.name, size: ready.size, valid: checked.valid, blob: ready });
}

/**
 * Готовит выбранные файлы по одному, чтобы в памяти было одно фото за раз, и не больше, чем осталось места:
 * лишние не декодируются вовсе (r2-code, находка 7).
 * @param {ArrayLike<File>} files что выбрал человек
 * @param {number} room сколько файлов форма ещё примет: rules.maxCount минус уже приложенные
 * @returns {Promise<Readonly<{prepared: ReadonlyArray<Object>, skipped: number}>>}
 */
export async function prepareFiles(files, room) {
  const list = Array.from(files || []);
  const picked = list.slice(0, Math.max(0, Math.floor(Number(room) || 0)));
  const prepared = [];
  for (const file of picked) prepared.push(await prepareFile(file)); // по одному, не Promise.all
  return Object.freeze({ prepared: Object.freeze(prepared), skipped: list.length - picked.length });
}

async function toBase64(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  const parts = [];
  for (let start = 0; start < bytes.length; start += BASE64_CHUNK) {
    parts.push(String.fromCharCode.apply(null, bytes.subarray(start, start + BASE64_CHUNK)));
  }
  return btoa(parts.join(''));
}

/** Файлы для тела запроса: [{name, data}], data в base64 без префикса data:. */
export async function encodeFiles(files) {
  return Promise.all(Array.from(files || []).map(async (file) => ({ name: file.name, data: await toBase64(file.blob) })));
}
