// Настройки сайта DONAT9 для формы заявки (ask.js на сайте, запасная lead-form.js) и наличия на складе (stock-core.js).
// Файл публичный, его видит любой посетитель: никаких токенов, паролей и ключей здесь быть не должно.
// Пустые значения нормальны: форма и склад работают и без них, только честно ведут в мессенджер.

// Куда форма отправляет заявку. Формат запроса один для обоих вариантов бэкенда (backend/README.md):
//   основной, данные в России: '/api/lead.php' (обработчик на хостинге reg.ru, папка backend/ru-hosting);
//   запасной: адрес веб-приложения Google Apps Script, кончается на /exec (риск по 152-ФЗ, см. README).
// Пока пусто, форма не отправляет заявку на сервер, а предлагает отправить её текст в мессенджер.
export const ENDPOINT = '/api/lead.php';

// Где окно «Статус заявки» (значок корзины в шапке, track.js) узнаёт статус по номеру. При запуске вписать
// '/api/status.php' (обработчик на хостинге reg.ru, backend/README.md, часть 1, шаг 10). У запасного варианта
// с Google проверки статуса нет. Пока пусто, окно не ходит в сеть и честно пишет, что проверка заработает после запуска.
export const STATUS_ENDPOINT = '/api/status.php';

// Контакты из одного источника (review/r1-fixes.md, п. 3): формы и site.js (разметка data-contact) берут их отсюда.
// Значение задано: живая ссылка (https://t.me/<ник>, tel:, mailto:). Пусто: образец-заглушка, мёртвой ссылки нет.
// Ключ есть в tbc: ссылка или образец оборачивается в span.tbc с этим вопросом (подсветка по адресу ?review=1).
// По желанию, когда Донат подтвердит: whatsapp: '+7…' (номер WhatsApp) и max: 'https://…' (профиль в Максе).
export const CONTACTS = Object.freeze({

  email: 'info@donat9.com',
});

// Какие способы связи предлагать клиенту в полной форме («Как удобнее связаться»): call, telegram, whatsapp, max.
// Пока подтверждены только звонок и Telegram, и те под вопросом (tbc). WhatsApp и Макс добавить, когда Донат подтвердит.
export const MESSENGER_CHOICES = Object.freeze(['call', 'telegram']);

// Фото и файлы в заявке. maxCount и maxTotalMb можно уменьшить, но не поднять выше 5 и 8:
// больше не примет бэкенд. enabled: false прячет поле файлов совсем.
export const FILES = Object.freeze({ enabled: true, maxCount: 5, maxTotalMb: 8 });

// Наличие на складе. csvUrl: ссылка «Опубликовать в интернете» на лист Google Таблицы в формате CSV
// (backend/README.md, часть 3). Пока пусто, берётся локальный файл data/stock.json с примерами.
export const STOCK = Object.freeze({
  csvUrl: '',
  jsonUrl: new URL('../../data/stock.json', import.meta.url).href,
});

// Версия текста согласия на обработку персональных данных (дата редакции на странице /privacy/consent/).
// Уходит с каждой заявкой в журнал согласий. Поменял текст согласия: поменяй и дату.
export const CONSENT_VERSION = '2026-11-24';

// Адреса страниц считаются от этого файла (site/assets/js/config.js), поэтому сайт работает
// и в корне домена, и в подпапке на локальном сервере. ask: главная с формой заявки (страницы /request/ нет,
// правки Доната 11.11, Р5); ссылки на заявку сами дописывают якорь #ask.
export const PAGES = Object.freeze({
  ask: new URL('../../', import.meta.url).href,
  privacy: new URL('../../privacy/', import.meta.url).href,
  consent: new URL('../../privacy/consent/', import.meta.url).href,
});
