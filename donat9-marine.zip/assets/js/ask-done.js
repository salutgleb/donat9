// Экран после отправки заявки (правки Доната 11.11, SPEC, Р12 и раздел 4): блок #ask-done на месте формы.
// Разметка экрана лежит в куске src/partials/ask.html (скрытая), скрипт только заполняет её через textContent:
// номер заявки, строки «В наличии в России по вашей заявке» из data/stock.json (поиск stock-core.js по строкам поля
// запчасти), кнопки «Отправить в Telegram» на превью без адреса приёма. Сроки доставки собраны сборкой (eta_legs).
//
// Режимы (ask.js решает, какой): {type: 'success', id, bot, files} сервер принял заявку, номер настоящий;
// {type: 'preview'} превью без адреса приёма: пометка «Пример экрана…» сразу под заголовком (и в aria-describedby
// заголовка, на который ставится фокус), номер-образец под tbc, рабочая кнопка Telegram.
//
// Наличие (ревью 12.11, п. 1): строки-примеры (demo: true) только на превью (html[data-mode="preview"]) и с заметной
// пометкой «Пример» у заголовка блока; без совпадений на превью под фразой «ничего не нашли» три строки-примера под
// подзаголовком «Пример списка…». В live примеры посетителю не показываются: если весь список из примеров,
// «Наличие проверим вручную и ответим вместе с ценой.».

import { STOCK } from './config.js';
import { TEXT as FORM_TEXT } from './lead-core.js';
import { allDemo, availabilityLabel, loadStock, prepareStock, searchStock, stockMatches } from './stock-core.js';
import { messengerNode, node, rich, sendParts } from './ask-ui.js';

const SAMPLE_ROWS = 3; // «Пример списка.»: столько строк-примеров под пустым результатом
const STOCK_LABELS = Object.freeze({ pieces: 'шт.', none: 'нет в наличии', unknown: 'уточним' });
const STOCK_STATES = Object.freeze(['loading', 'empty', 'manual', 'table', 'demo', 'sample']);
const FILES_FAILED = 'Файлы не сохранились. Пришлите их, пожалуйста, в {messenger}.';
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

let stockCache = null;

/** Наличие загружается один раз за страницу; после сбоя следующая заявка попробует снова. */
function stockData() {
  if (!stockCache) {
    stockCache = loadStock({ csvUrl: STOCK.csvUrl, jsonUrl: STOCK.jsonUrl })
      .then((data) => ({ ...data, entries: prepareStock(data.items) }));
    stockCache.then((data) => { if (data.error) stockCache = null; });
  }
  return stockCache;
}

function stockRow(item) {
  const row = document.createElement('tr');
  row.append(node('td', '', item.sku || item.oem), node('td', '', item.name), node('td', '', item.maker),
    node('td', '', availabilityLabel(item.availability, STOCK_LABELS)));
  return row;
}

/**
 * Что показать в блоке наличия. live: строки-примеры не показываются совсем (их нет в поиске), весь список из примеров
 * даёт «проверим вручную». Превью: найденные примеры с пометкой «Пример», без совпадений «ничего не нашли» и три
 * строки-примера под подзаголовком «Пример списка…».
 */
function stockView(data, part, kind, live) {
  if (data.error) return { states: ['manual'], items: [] };
  const entries = live ? data.entries.filter((entry) => !entry.item.demo) : data.entries;
  if (!entries.length) return { states: ['manual'], items: [] };
  const found = stockMatches(entries, part, { kind });
  if (found.length) return { states: allDemo(found) ? ['demo', 'table'] : ['table'], items: found };
  if (live || !allDemo(data.items)) return { states: ['empty'], items: [] };
  const sample = searchStock(entries, '', { kind, limit: SAMPLE_ROWS }).items;
  return { states: sample.length ? ['empty', 'sample', 'table'] : ['empty'], items: sample };
}

/**
 * Подключает экран после отправки.
 * @param {HTMLElement} done блок #ask-done из куска ask.html
 * @param {{onAgain: Function}} options «Отправить ещё одну заявку»
 */
export function mountDone(done, options) {
  const find = (selector) => done.querySelector(selector);
  const title = find('.ask-done__title');
  const rows = find('#ask-done-rows');
  const id = find('#ask-done-id');
  const send = find('#ask-done-send');
  const extra = find('#ask-done-extra');
  let token = 0; // новая заявка отменяет запоздалый ответ наличия по старой

  const showStock = (states) => STOCK_STATES.forEach((state) => {
    done.querySelectorAll(`[data-stock="${state}"]`).forEach((item) => { item.hidden = !states.includes(state); });
  });
  const isLive = () => document.documentElement.dataset.mode === 'live';

  async function renderStock(part, kind) {
    const mine = ++token;
    rows.replaceChildren();
    showStock(['loading']);
    const data = await stockData();
    if (mine !== token) return;
    const view = stockView(data, part, kind, isLive());
    rows.replaceChildren(...view.items.map(stockRow));
    showStock(view.states);
  }

  function renderNumber(result) {
    const sample = result.type !== 'success';
    id.textContent = sample ? '' : result.id;
    id.hidden = sample;
    done.querySelectorAll('[data-done-sample], [data-done-sample-id]').forEach((item) => { item.hidden = !sample; });
    // Фокус встаёт на заголовок: пометку «Пример экрана…» читалка услышит как его описание.
    const note = find('[data-done-sample]');
    if (sample && note) title.setAttribute('aria-describedby', note.id);
    else title.removeAttribute('aria-describedby');
  }

  function renderExtra(result) {
    const parts = [];
    if (result.files === 'failed' || result.files === 'skipped') {
      const warn = node('p', 'ask-done__warn');
      warn.append(...rich(FILES_FAILED, { messenger: messengerNode() }));
      parts.push(warn);
    }
    if (result.bot) {
      const bot = node('a', 'btn btn--ghost', FORM_TEXT.openBot);
      bot.href = result.bot;
      bot.target = '_blank';
      bot.rel = 'noopener';
      const actions = node('div', 'ask__actions');
      actions.append(bot);
      parts.push(node('p', 'ask-done__text', FORM_TEXT.successBot), actions);
    }
    extra.replaceChildren(...parts);
    extra.hidden = parts.length === 0;
  }

  function renderSend(result, request) {
    const shown = result.type === 'preview';
    send.replaceChildren(...(shown ? sendParts(request.text, request.filesCount).nodes : []));
    send.hidden = !shown || send.childElementCount === 0;
  }

  /**
   * @param {{type: string, id?: string, bot?: string, files?: string}} result
   * @param {{part: string, kind: string, text: string, filesCount: number}} request
   */
  function show(result, request) {
    renderNumber(result);
    renderExtra(result);
    renderSend(result, request);
    renderStock(request.part, request.kind);
    done.hidden = false;
    title.focus({ preventScroll: true });
    done.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
  }

  function hide() {
    token += 1;
    done.hidden = true;
    send.replaceChildren();
    extra.replaceChildren();
    rows.replaceChildren();
  }

  find('[data-done-again]').addEventListener('click', () => options.onAgain());
  return Object.freeze({ show, hide });
}
