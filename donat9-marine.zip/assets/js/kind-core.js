// Одно правило «какая это запчасть» для формы заявки и поиска по наличию DONAT9 (review/r2-fixes.md,
// «Интерфейс»): нормализация текста, словарь русских и бытовых написаний, тип по номеру и словам.
// Без DOM, проверяется в node --test. Импортируют lead-core.js (форма) и stock-core.js (наличие).

// Кириллица, похожая на латиницу. После toLowerCase и NFKD остаются только эти строчные.
const LOOKALIKES = Object.freeze({
  а: 'a', в: 'b', е: 'e', к: 'k', м: 'm', н: 'h', о: 'o', р: 'p', с: 'c', т: 't', у: 'y', х: 'x',
});
const LOOKALIKE_RE = /[авекмнорстух]/g;
const COMBINING_MARKS_RE = /[̀-ͯ]/g;
const NOT_ALNUM_RE = /[^\p{L}\p{N}]+/gu;
const WORD_SPLIT_RE = /[\s,.;:/]+/;
const STEM_MIN = 3;

function asString(value) {
  return value === null || value === undefined ? '' : String(value);
}

/**
 * Текст для сравнения: без диакритики (Wärtsilä = wartsila, ё = е), в нижнем регистре,
 * кириллица, похожая на латиницу, заменена латиницей (АZ712734006532 с русской А найдётся).
 */
export function foldText(value) {
  return asString(value)
    .normalize('NFKD')
    .replace(COMBINING_MARKS_RE, '')
    .toLowerCase()
    .replace(LOOKALIKE_RE, (letter) => LOOKALIKES[letter]);
}

/** Только буквы и цифры: «WG9725-220 362» и «wg9725220362» совпадают. */
export function compact(value) {
  return foldText(value).replace(NOT_ALNUM_RE, '');
}

/**
 * Словарь синонимов: русские и бытовые написания марок и запчастей. Слова одной группы равны,
 * поэтому «турбина ситрак» находит «Турбокомпрессор SITRAK», а «тнвд» и «топливный насос высокого давления»
 * находят друг друга. kind говорит о типе запчасти: марка тягача значит «Грузовая».
 * Марки здесь нужны только для поиска и ничего не говорят о том, с кем работает DONAT9.
 */
export const SYNONYMS = Object.freeze([
  { kind: 'truck', terms: ['sitrak', 'ситрак', 'ситрек', 'зитрак'] },
  { kind: 'truck', terms: ['howo', 'хово', 'хова', 'хаво'] },
  { kind: 'truck', terms: ['shacman', 'шакман', 'шахман', 'шекман'] },
  { kind: 'truck', terms: ['faw', 'фав'] },
  { kind: 'truck', terms: ['dongfeng', 'донгфенг', 'донфенг', 'дунфэн'] },
  { kind: 'truck', terms: ['foton', 'фотон'] },
  { kind: 'truck', terms: ['jac', 'джак'] },
  { kind: '', terms: ['weichai', 'вейчай', 'вэйчай', 'вейчаи', 'вейчей'] },
  { kind: '', terms: ['yuchai', 'ючай', 'ючаи'] },
  { kind: '', terms: ['cummins', 'камминс', 'каминс'] },
  { kind: 'marine', terms: ['wartsila', 'вартсила', 'вартсиля', 'вяртсиля'] },
  { kind: '', terms: ['турбокомпрессор', 'турбина', 'турбо', 'турбонагнетатель', 'турбокомпрессора'] },
  { kind: '', terms: ['тнвд', 'топливный насос высокого давления'] },
  { kind: '', terms: ['форсунка', 'инжектор', 'распылитель'] },
  { kind: '', terms: ['шрус', 'гранату', 'граната'] },
  { kind: '', terms: ['кпп', 'коробка передач'] },
].map((group) => Object.freeze({ kind: group.kind, terms: Object.freeze(group.terms) })));

// Слова, по которым видно тип запчасти, если марки в запросе нет. Сравниваются начала слов.
const KIND_HINTS = Object.freeze({
  truck: Object.freeze(['тягач', 'грузов', 'самосвал', 'vin']), // не «вин»: «гребной винт» судовой
  marine: Object.freeze(['судн', 'судов', 'imo', 'имо', 'морск', 'танкер', 'балкер', 'буксир', 'теплоход', 'гребн']),
});
const VIN_TOKEN_RE = /^[a-hj-npr-z0-9]{17}$/;
// IMO судна: слово IMO или ИМО и семь цифр. Проверяется после foldText: «ИМО» там «иmo», «№» там «no».
const IMO_RE = /(?:^|[\s,;:(])(?:imo|иmo)[\s:#.-]*(?:no[\s.:#-]*)?\d{7}(?=$|[\s,;.)])/;
// Типичные начала артикулов китайских тягачей: WG и AZ (SINOTRUK: HOWO, SITRAK), VG и 612600 (двигатели), DZ (Shacman).
// Это подсказка «похоже на артикул тягача», не уверенность: человек тип переключит.
export const TRUCK_PART_PREFIX_RE = /^(?:wg|az|vg|dz)\d{4,}|^612600\d*/;
// Похоже на артикул: первое слово с цифрой, от 4 знаков, латиница, цифры, точка, дефис, косая черта.
const CODE_RE = /^(?=.*\d)[a-z0-9][a-z0-9.\-/]{3,}$/i;

/**
 * Основа слова для сравнения: без окончания у длинных слов («турбину» и «турбина» совпадут).
 * Слово уже прошло foldText, поэтому а, е, о, у здесь латинские.
 */
function stem(word) {
  return word.length > 4 ? word.replace(/[aeoyиыюяйь]$/u, '') : word;
}

const SYNONYM_GROUPS = Object.freeze(SYNONYMS.map((group) => Object.freeze({
  kind: group.kind,
  forms: Object.freeze(group.terms.map(compact)),
  stems: Object.freeze(group.terms.map((term) => stem(compact(term)))),
})));

/** Группы синонимов, к которым относится слово: точное совпадение или та же основа. */
function groupsFor(token) {
  return SYNONYM_GROUPS.filter((group) => group.forms.includes(token) ||
    group.stems.some((base) => base.length >= STEM_MIN && token.length >= STEM_MIN && token.startsWith(base)));
}

/** Варианты слова запроса: само слово и все слова его групп синонимов. */
export function expandToken(token) {
  const forms = groupsFor(token).flatMap((group) => group.forms);
  return Object.freeze([...new Set([token, ...forms])]);
}

const isVin = (token) => VIN_TOKEN_RE.test(token) && /[a-z]/.test(token) && /\d/.test(token);
const hintKinds = (token) => Object.keys(KIND_HINTS)
  .filter((kind) => KIND_HINTS[kind].some((hint) => token.startsWith(compact(hint))));

/** Что говорит о типе одно слово текста: VIN, артикул тягача, марка или слово-подсказка. */
function tokenClues(token) {
  const brandKinds = groupsFor(token).map((group) => group.kind).filter(Boolean);
  return {
    vin: isVin(token),
    truckCode: TRUCK_PART_PREFIX_RE.test(token),
    kinds: [...brandKinds, ...hintKinds(token)],
  };
}

/**
 * Тип запчасти по тексту и признак, по которому он понятен. Одно правило для поля заявки и поиска наличия.
 * kind: 'truck' (VIN, артикулы WG, AZ, VG, DZ, 612600, марки тягачей кириллицей и латиницей, «тягач»),
 * 'marine' (IMO или ИМО, «судно», «танкер» и другие судовые слова) или null, если непонятно или признаки спорят.
 * clue: 'vin', 'imo', 'truckCode', 'truckWord', 'marineWord', 'code' (похоже на артикул), 'text' или '' для пустого.
 * @returns {{kind: 'marine'|'truck'|null, clue: string}}
 */
export function detectClue(text) {
  const folded = foldText(text).trim();
  if (!folded) return Object.freeze({ kind: null, clue: '' });
  const clues = folded.split(WORD_SPLIT_RE).map(compact).filter(Boolean).map(tokenClues);
  const kinds = new Set(clues.flatMap((clue) => clue.kinds));
  const hasVin = clues.some((clue) => clue.vin);
  const hasCode = clues.some((clue) => clue.truckCode);
  if (hasVin || hasCode) kinds.add('truck');
  const kind = kinds.size === 1 ? [...kinds][0] : null;
  let clue = 'text';
  if (hasVin) clue = 'vin';
  else if (IMO_RE.test(folded)) clue = 'imo';
  else if (hasCode) clue = 'truckCode';
  else if (kind === 'truck') clue = 'truckWord';
  else if (kind === 'marine') clue = 'marineWord';
  else if (CODE_RE.test(folded.split(/[\s,;:]+/)[0])) clue = 'code';
  return Object.freeze({ kind, clue });
}

/** Тип запчасти по тексту: 'marine', 'truck' или null. Подробности и признак в detectClue. */
export function detectKind(text) {
  return detectClue(text).kind;
}
