// Общие кусочки разметки формы «Заявка на запчасть» (ask.js) и экрана после отправки (ask-done.js): элемент с текстом,
// заглушка tbc, строка с подстановками, кнопки отправки заявки в мессенджер или письмом из CONTACTS (config.js).
// Всё, что видит посетитель, пишется через textContent: HTML из данных не вставляется.

import { CONTACTS } from './config.js';
import { PREFILLED_KINDS, TEXT as FORM_TEXT, contactLinks, contactSlots, typo } from './lead-core.js';

const doc = document;
const finePointer = window.matchMedia('(pointer: fine)').matches;
const MESSENGER_NAMES = Object.freeze({ telegram: 'Telegram', whatsapp: 'WhatsApp', max: 'Макс' });
// Вопросы к заглушкам, если в CONTACTS.tbc своего нет. Подтверждены пока только звонок и Telegram, оба под вопросом.
const STUBS = Object.freeze({
  messenger: Object.freeze(['ник Telegram для заявок', 'Telegram']),
  phone: Object.freeze(['телефон для звонков', '+7 900 000-00-00']),
});

export const fill = (template, values) => template.replace(/\{(\w+)\}/g, (_, key) => String(values[key]));
const contactQuestions = () => (CONTACTS && CONTACTS.tbc) || {};

/** Элемент с классом и текстом; текст всегда как текст. */
export function node(tag, className, text) {
  const item = doc.createElement(tag);
  if (className) item.className = className;
  if (text !== undefined) item.textContent = typo(text);
  return item;
}

export function tbc(question, sample, extraClass) {
  const span = node('span', extraClass ? 'tbc ' + extraClass : 'tbc', sample);
  span.setAttribute('data-tbc', question);
  return span;
}

/** Строка с подстановками: {name} заменяется узлом или текстом из slots. */
export function rich(template, slots) {
  return template.split(/(\{\w+\})/).filter(Boolean).map((part) => {
    const key = /^\{(\w+)\}$/.exec(part);
    if (!key) return doc.createTextNode(typo(part));
    const value = slots[key[1]];
    return value instanceof Node ? value : doc.createTextNode(String(value));
  });
}

/** Заглушка контакта: вопрос из CONTACTS.tbc, иначе из STUBS. */
export function contactStub(kind, extraClass) {
  const [question, sample] = STUBS[kind];
  return tbc(contactQuestions()[kind === 'messenger' ? 'telegram' : kind] || question, sample, extraClass);
}

/** «Telegram» живой ссылкой из CONTACTS или заглушкой, если ника нет. */
export function messengerNode() {
  const link = contactLinks(CONTACTS, '').find((item) => item.kind === 'telegram');
  if (!link && CONTACTS.email) {
    const email = node('a', 'text-link', CONTACTS.email);
    email.href = 'mailto:' + CONTACTS.email;
    return email;
  }
  if (!link) return contactStub('messenger');
  const anchor = node('a', 'text-link');
  anchor.href = link.href;
  anchor.target = '_blank';
  anchor.rel = 'noopener';
  const question = contactQuestions().telegram;
  anchor.append(question ? tbc(question, 'Telegram') : doc.createTextNode('Telegram'));
  return anchor;
}

export async function copyText(text) {
  if (!navigator.clipboard || !window.isSecureContext) return false;
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    return false; // нет разрешения на буфер: человек скопирует текст сам
  }
}

/**
 * Контакты для отправки заявки без адреса приёма из contactSlots (lead-core.js): заданные живыми ссылками,
 * незаданные telegram, phone, email образцами-заглушками только в ?review=1, неактивных кнопок нет.
 * Письмо первым, если приложены файлы или это ноутбук (r1-buyer, замечание 4).
 */
export function fallbackContacts(text, withFiles) {
  const slots = contactSlots(CONTACTS, text);
  const live = slots.filter((slot) => slot.live);
  const mailFirst = withFiles || finePointer;
  return {
    live: mailFirst ? [...live].sort((a, b) => Number(b.kind === 'email') - Number(a.kind === 'email')) : live,
    pending: slots.filter((slot) => !slot.live),
  };
}

/** Подпись кнопки контакта: «Отправить в Telegram», «Отправить письмом», номер телефона. */
export function buttonLabel(slot) {
  if (slot.kind === 'phone') return slot.label;
  if (slot.kind === 'email') return FORM_TEXT.sendMail;
  return fill(FORM_TEXT.sendTo, { messenger: MESSENGER_NAMES[slot.kind] || slot.label });
}

/** Кнопка-ссылка контакта, первая красная; контакт под вопросом из CONTACTS.tbc обёрнут в span.tbc. */
export function linkButton(slot, index) {
  const anchor = node('a', index === 0 ? 'btn btn--red' : 'btn btn--ghost', buttonLabel(slot));
  anchor.href = slot.href;
  anchor.rel = 'noopener';
  if (slot.kind !== 'phone' && slot.kind !== 'email') anchor.target = '_blank';
  if (!slot.question) return anchor;
  const wrap = tbc(slot.question, '');
  wrap.append(anchor);
  return wrap;
}

/** «Телефон: +7 900 000-00-00 · почта: …»: незаданные контакты образцами tbc одной строкой. */
export function pendingLine(pending) {
  const line = node('p', 'ask__contacts-pending');
  pending.forEach((slot, index) => {
    const label = FORM_TEXT.contactLabels[slot.kind] || '';
    const shown = index ? label : label.charAt(0).toUpperCase() + label.slice(1);
    line.append((index ? ' · ' : '') + typo(shown) + ' ', tbc(slot.question, slot.label, 'nowrap'));
  });
  return line;
}

/**
 * Кнопки отправки заявки с готовым текстом: ряд кнопок, строка незаданных контактов (только ?review=1)
 * и примечание про файлы: ссылка их не несёт.
 * @returns {{nodes: Array<Node>, live: Array<Object>}}
 */
export function sendParts(text, filesCount) {
  const { live, pending } = fallbackContacts(text, filesCount > 0);
  const nodes = [];
  if (live.length) {
    const actions = node('div', 'ask__actions');
    actions.append(...live.map(linkButton));
    nodes.push(actions);
  }
  if (live.length && pending.length) nodes.push(pendingLine(pending));
  if (filesCount) nodes.push(node('p', '', live.some((slot) => slot.kind === 'email') ? FORM_TEXT.filesNoteMail : FORM_TEXT.filesNote));
  return { nodes, live, pending };
}

/**
 * Строка статуса под формой. Без адреса приёма (r2-fixes п. 1): первая кнопка открывает чат или письмо уже с текстом
 * заявки, поэтому «Последний шаг: нажмите …»; текст ещё и в буфере. Звонок или нет кнопок: отправить скопированный
 * текст. Сбои отправки своими словами со ссылкой на мессенджер (statusInline в lead-text.js, круг 4).
 */
export function fallbackStatus(kind, first, copied) {
  if (kind !== 'offline') return FORM_TEXT.statusInline[kind] || FORM_TEXT.statusInline.server;
  if (first && PREFILLED_KINDS.includes(first.kind)) {
    const base = first.kind === 'email' ? FORM_TEXT.status.offlineMail : FORM_TEXT.status.offline;
    return copied ? base + ' ' + FORM_TEXT.status.copiedToo : base;
  }
  return copied ? FORM_TEXT.status.offlineCopy : FORM_TEXT.status.offlineManual;
}

/** Текст заявки только для чтения, кнопка «Скопировать текст» и тихое сообщение о копировании. */
export function summaryBox(text) {
  const area = node('textarea', 'ask__summary');
  area.id = 'ask-summary';
  area.readOnly = true;
  area.rows = 6;
  area.value = text;
  const label = node('label', 'ask__summary-label', FORM_TEXT.summary);
  label.htmlFor = area.id;
  const copy = node('button', 'btn btn--ghost btn--sm', FORM_TEXT.copy);
  copy.type = 'button';
  const copyLive = node('p', 'visually-hidden');
  copyLive.setAttribute('role', 'status');
  copy.addEventListener('click', async () => {
    const ok = await copyText(area.value);
    if (!ok) {
      area.focus();
      area.select();
    }
    copy.textContent = typo(ok ? FORM_TEXT.copied : FORM_TEXT.copyManual);
    copyLive.textContent = copy.textContent;
  });
  return [label, area, copy, copyLive];
}

const THUMB_PX = 40;

/**
 * Миниатюры фото в списке файлов (07.11, придирки клиентов, А17): адрес blob: на файл живёт, пока файл в форме,
 * и освобождается, когда файл убран или форма сброшена (release с оставшимися файлами). Только для файлов,
 * которые пропускает previewable (isPreviewable в lead-core.js: проверенные JPEG, PNG, WebP), остальным имя.
 */
export function createPreviews(previewable) {
  const urls = new Map(); // адрес blob: по id файла

  function urlFor(file) {
    if (!previewable(file) || !window.URL || typeof URL.createObjectURL !== 'function') return '';
    if (!urls.has(file.id)) urls.set(file.id, URL.createObjectURL(file.blob));
    return urls.get(file.id);
  }

  function release(files) {
    const kept = new Set(Array.from(files || []).map((file) => file.id));
    urls.forEach((url, id) => {
      if (kept.has(id)) return;
      URL.revokeObjectURL(url);
      urls.delete(id);
    });
  }

  function thumb(file, item) {
    const url = urlFor(file);
    if (!url) return null;
    const image = node('img', 'file-pill__thumb');
    image.alt = ''; // имя файла рядом
    image.width = THUMB_PX;
    image.height = THUMB_PX;
    image.decoding = 'async';
    image.addEventListener('error', () => { // браузер фото не нарисовал: остаётся имя
      image.remove();
      item.classList.remove('has-thumb');
    }, { once: true });
    image.src = url;
    item.classList.add('has-thumb');
    return image;
  }

  return Object.freeze({ release, thumb });
}
