// Запчасти заявки и её черновик: то из формы «Заявка на запчасть» (ask.js), чему не нужно состояние формы.
// Правки Доната 12.11: запчастей в заявке может быть несколько, карточка полей повторяется кнопкой «Добавить
// запчасть». У полей добавленной карточки те же id с хвостом («ask-part-2»), у групп выбора свои имена.

import { LIMITS } from './lead-core.js';

// Запчастей в одной заявке: больше не уместится в поля бэкенда (номер и комментарий по 1000 знаков).
export const MAX_PARTS = 10;
// Поля одной запчасти (в каждой карточке свои) и поля на всю заявку.
export const CARD_FIELDS = Object.freeze(['ask-part', 'ask-imo', 'ask-mech', 'ask-serial',
  'ask-qty', 'ask-port', 'ask-term', 'ask-advance', 'ask-comment']);
export const SHARED_FIELDS = Object.freeze(['ask-email', 'ask-phone', 'ask-telegram', 'ask-name', 'ask-company']);
export const RADIO_GROUPS = Object.freeze(['ask-orig', 'ask-logistics']);
// Новая карточка наследует сведения о судне, производителе, месте доставки и авансе.
export const CARRY = Object.freeze(['ask-imo', 'ask-mech', 'ask-port', 'ask-advance']);
// Атрибуты со ссылками на id: у добавленной карточки к каждому id дописывается её хвост.
const ID_ATTRS = Object.freeze(['id', 'for', 'aria-describedby', 'aria-labelledby']);

/** Чистая копия карточки запчасти: без значений, которые браузер мог вернуть в поля до скрипта. */
export function blankCard(source) {
  const copy = source.cloneNode(true);
  copy.querySelectorAll('input, textarea').forEach((input) => {
    if (input.type === 'radio' || input.type === 'checkbox') input.checked = false;
    else input.value = '';
  });
  return copy;
}

/** Хвост к каждому id карточки и ссылкам на него, свои имена групп выбора: карточки друг другу не мешают. */
export function renameCard(element, suffix) {
  element.querySelectorAll('*').forEach((item) => {
    ID_ATTRS.filter((attr) => item.hasAttribute(attr)).forEach((attr) => {
      const ids = item.getAttribute(attr).split(/\s+/).filter(Boolean);
      item.setAttribute(attr, ids.map((id) => id + suffix).join(' '));
    });
    if (item instanceof HTMLInputElement && item.type === 'radio') item.name += suffix;
  });
}

/** Отмечает в карточке вариант группы выбора с этим значением, если такой есть. */
export function checkRadio(element, name, value) {
  const input = Array.from(element.querySelectorAll('input[type="radio"]')).find((item) => item.name === name && item.value === value);
  if (input) input.checked = true;
}

// ---------- Черновик в браузере: до 14 дней (как обещает политика), согласие не запоминается ----------

// v1 был у формы с путями и «Срочно», v2 у формы с одной запчастью и чипом «Почта»: их поля к новой форме не подходят.
const DRAFT_KEY = 'donat9-ask-draft-v3';
const DRAFT_VERSION = 3;
const OLD_DRAFT_KEYS = Object.freeze(['donat9-ask-draft-v1', 'donat9-ask-draft-v2']);

function storage() {
  try {
    return window.localStorage;
  } catch (error) {
    return null; // приватный режим: форма работает и без черновика
  }
}

/** Сохраняет черновик; fields null (в форме пусто) убирает его. */
export function saveDraft(kind, fields) {
  const store = storage();
  if (!store) return;
  try {
    if (fields) store.setItem(DRAFT_KEY, JSON.stringify({ v: DRAFT_VERSION, savedAt: Date.now(), kind, fields }));
    else store.removeItem(DRAFT_KEY);
  } catch (error) {
    // хранилище переполнено: черновик не сохранится, заявка от этого не пострадает
  }
}

export function clearDraft() {
  const store = storage();
  if (!store) return;
  try {
    [DRAFT_KEY, ...OLD_DRAFT_KEYS].forEach((key) => store.removeItem(key));
  } catch (error) {
    // нечего чистить
  }
}

/** Свежий черновик этой версии формы или null; старый и просроченный убираются. */
export function readDraft() {
  const store = storage();
  try {
    OLD_DRAFT_KEYS.forEach((key) => store && store.removeItem(key)); // старый черновик новой форме не подходит
    const draft = JSON.parse((store && store.getItem(DRAFT_KEY)) || 'null');
    const age = draft ? Date.now() - Number(draft.savedAt) : -1;
    const fresh = draft && draft.v === DRAFT_VERSION && draft.fields && typeof draft.fields === 'object'
      && age >= 0 && age <= LIMITS.draftMaxAgeMs;
    if (draft && !fresh) clearDraft();
    return fresh ? draft : null;
  } catch (error) {
    return null; // испорченный черновик: форма пустая
  }
}
