// Форма «Заявка на запчасть» (src/partials/ask.html): единственная форма сайта, на главной, /marine/ .
// В подробной заявке все поля видны сразу. Обязательного
// поля в карточке нет (номер или название, комментарий или файл), способы связи чипами с множественным выбором
// и контактом на каждый, согласие не отмечено, после отправки экран «Мы уже обрабатываем вашу заявку» (ask-done.js).
// Проверка, тело запроса, отправка, тексты, файлы и тип по номеру: lead-core.js и config.js из tech/.
//
// Без адреса приёма (ENDPOINT в config.js пуст): на превью (html[data-mode="preview"]) тот же экран после отправки
// с пометкой «Пример экрана…» и рабочей кнопкой «Отправить в Telegram»; в live прежний «Последний шаг» под формой.
// Черновик хранится в браузере до 14 дней (как обещает политика), согласие не запоминается (ask-parts.js).
//
// Правки Доната 12.11: запчастей в заявке может быть несколько. Карточка полей повторяется кнопкой «Добавить
// запчасть»; в новую подставляются значения предыдущей (CARRY), номер, комментарий и файлы свои. У полей
// добавленной карточки те же id с хвостом «-2», «-3»: всё, что относится к запчасти, читается через карточку
// (card.id, card.value), а не напрямую по id. Заявка уходит одним запросом (askParts в lead-core.js).
// Почта видна сразу, без чипа: написана, значит выбрана.
//
// Другие скрипты начинают заявку событием: document.dispatchEvent(new CustomEvent('donat9:ask',
//   {detail: {kind: 'marine', part: 'Турбокомпрессор: ', focus: 'part' | 'contact'}})): узел чертежа (site.js).
// Ссылка ?kind=…&part=…#ask на главную делает то же самое.

import { CONSENT_VERSION, ENDPOINT, FILES } from './config.js';
import {
  LIMITS, TEXT as FORM_TEXT, askLines, askParts, askSummary, buildBody, channelContacts, channelErrors,
  channelFields, cleanAdvance, cleanChannels, cleanLine, cleanText, cleanValues, commentRoom, encodeFiles,
  fileRules, filesErrorText, findErrors, hasRequestSubject, imoProblem, isEndpointSet, isPreviewable, isVideoTooBig,
  limitMb, parseContact, partsComment, partsSummary, phoneChannelsText, prepareFiles, requestComment, requestTimeoutMs, sendLead, typo,
  videoTooBigText,
} from './lead-core.js';
import {
  buttonLabel, contactStub, copyText, createPreviews, fallbackStatus, fill, messengerNode, node, rich, sendParts, summaryBox,
} from './ask-ui.js';
import { mountDone } from './ask-done.js';
import {
  CARD_FIELDS, CARRY, MAX_PARTS, RADIO_GROUPS, SHARED_FIELDS, blankCard, checkRadio, clearDraft as dropDraft, readDraft,
  renameCard, saveDraft as storeDraft,
} from './ask-parts.js';

const ASK_EVENT = 'donat9:ask';
const DRAFT_DELAY_MS = 400;
const FOCUS_DELAY_MS = 450;
// Бэкенд требует имя, а в форме оно по желанию (copy-final, раздел 6): без имени уходит эта строка.
const NAME_FALLBACK = 'Не указано';
const KIND = 'marine';
const VIDEO_NOTICE = 'filesVideo';
// Запас к порогу бэкенда (minElapsedMs): таймеры браузера срабатывают с округлением, 2999,6 мс бэкенд счёл бы ботом.
const ELAPSED_MARGIN_MS = 50;

// Подписи распознавания номера на главной (концепт C, r1-fixes п. 5).
const T = Object.freeze({
  sending: 'Отправляем…',
  noContacts: 'Отправьте его Донату в {messenger} или позвоните: {phone}.',
  filesAdded: 'Добавлено файлов: {added}. Всего: {total}.',
  filesRemoved: 'Файл убран. Осталось: {total}.',
  draftNoFiles: 'Восстановили текст заявки. Файлы при переходе не сохраняются: приложите их ещё раз.',
  // Мягкая подсказка под «IMO или название судна»: 7 цифр есть, последняя не сходится (07.11, придирки клиентов, А18).
  imoChecksum: 'Проверьте номер IMO: последняя цифра не сходится. Если не помните, напишите название судна.',
  partAdded: 'Добавлена запчасть {n}. Часть полей заполнена как у предыдущей.',
  partRemoved: 'Запчасть убрана. Осталось: {total}.',
});

// «Отправить ещё одну заявку»: контакты человека остаются.
const KEPT_FIELDS = SHARED_FIELDS;

// Поле с ошибкой: где показать текст и что получит фокус. card: слот и поле лежат в карточке запчасти.
// invalid: false — без aria-invalid (группа, файлы).
const SLOTS = Object.freeze({
  part: { slot: 'ask-part-error', input: 'ask-part', card: true },
  city: { slot: 'ask-port-error', input: 'ask-port', card: true },
  kind: { slot: 'ask-part-error', input: 'ask-part', card: true },
  qty: { slot: 'ask-qty-error', input: 'ask-qty', card: true },
  advance: { slot: 'ask-advance-error', input: 'ask-advance', card: true },
  files: { slot: 'ask-files-error', input: 'ask-photo', invalid: false, card: true },
  comment: { slot: 'ask-comment-error', input: 'ask-comment', card: true },
  // Ни почты, ни другого способа связи: ошибка у почты, она первая в блоке (правки Доната 12.11).
  channels: { slot: 'ask-email-error', input: 'ask-email' },
  contact: { slot: 'ask-channels-error', input: 'channel', invalid: false, group: true },
  messenger: { slot: 'ask-channels-error', input: 'channel', invalid: false, group: true },
  email: { slot: 'ask-email-error', input: 'ask-email' },
  phone: { slot: 'ask-phone-error', input: 'ask-phone' },
  telegram: { slot: 'ask-telegram-error', input: 'ask-telegram' },
  name: { slot: 'ask-name-error', input: 'ask-name' },
  quickContact: { slot: 'ask-quick-error', input: 'ask-quick-contact' },
  company: { slot: 'ask-company-error', input: 'ask-company' },
  consent: { slot: 'ask-consent-error', input: 'ask-agree', consent: true },
});
// Ошибки из findErrors, которые форма показывает сама; контакты и пустую заявку проверяют channelErrors и hasRequestSubject.
const CORE_ERRORS = Object.freeze(['qty', 'city', 'company', 'comment', 'files', 'consent']);

const doc = document;
const root = doc.documentElement;
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function mount(form) {
  const byId = (id) => doc.getElementById(id);
  const value = (id) => (byId(id) ? byId(id).value : '');
  const radioValue = (name) => (form.querySelector(`input[name="${name}"]:checked`) || { value: '' }).value;

  /** Карточка запчасти: поля по id с её хвостом, свои файлы. */
  function makeCard(element, suffix) {
    const id = (name) => byId(name + suffix);
    return {
      el: element, suffix, id,
      value: (name) => (id(name) ? id(name).value : ''),
      radio: (name) => radioValue(name + suffix),
      files: [], filesNotice: '',
    };
  }

  const first = makeCard(form.querySelector('[data-card]'), '');
  const blank = blankCard(first.el);
  const partsBox = byId('ask-parts');
  const partsLive = byId('ask-parts-live');
  const addButton = form.querySelector('[data-add-part]');
  const part = first.id('ask-part');
  const channelsBox = byId('ask-channels');
  const modePicker = form.querySelector('.ask__modes');
  const quickContact = byId('ask-quick-contact');
  const isQuick = () => form.dataset.formMode === 'quick';
  const channelInputs = Array.from(form.querySelectorAll('input[name="ask-channel"]'));
  const agree = byId('ask-agree');
  const consentBox = byId('ask-consent');
  const status = byId('ask-status');
  const fallback = byId('ask-fallback');
  const draftNote = byId('ask-draft');
  const send = form.querySelector('.ask__send');
  const sendLabel = send.querySelector('[data-send-label]');
  const sendText = sendLabel.textContent;
  const imoLengthText = byId('ask-imo-soft').textContent; // «В номере IMO 7 цифр…» из разметки
  const rules = fileRules(FILES);
  const draftText = draftNote.firstChild.textContent.trim();
  // submitting ставится до первого await: второе нажатие, пока готовятся файлы, заявку не задвоит (r2-code № 1).
  const state = {
    cards: [first], cardSeq: 1, filesCard: null, // filesCard: карточка, где последним трогали файлы (там ошибка файлов)
    filesReady: Promise.resolve(), preparing: 0, pendingFiles: 0, epoch: 0, busy: false, submitting: false, attempted: false,
    draftTimer: 0, shownAt: performance.now(), sendStarted: false, lastPrefill: '',
    fallbackKind: '', // вид блока под формой: 'offline' («Последний шаг» в live) или сбой отправки ('network'…)
    radios: {}, // выбранное значение каждой группы с повторным нажатием (data-toggle-radio)
  };

  const allFiles = () => state.cards.flatMap((card) => card.files);
  const cardOf = (target) => state.cards.find((card) => target instanceof Node && card.el.contains(target)) || null;

  /** Отмеченные чипы: мессенджеры и звонок. */
  const chips = () => cleanChannels(channelInputs.filter((input) => input.checked).map((input) => input.value));
  /** Способы связи заявки: чипы и почта. Почта без чипа (правки Доната 12.11): написана, значит выбрана. */
  const channels = () => cleanChannels([...chips(), ...(value('ask-email').trim() ? ['email'] : [])]);

  function detailedContact() {
    return channelContacts(channels(), { phone: value('ask-phone'), telegram: value('ask-telegram'), email: value('ask-email') });
  }

  function setMode(mode) {
    if (!modePicker) return;
    form.dataset.formMode = mode === 'detailed' ? 'detailed' : 'quick';
    modePicker.querySelector(`[value="${form.dataset.formMode}"]`).checked = true;
  }

  function changeMode(mode) {
    const quick = parseContact(quickContact.value);
    const detailed = detailedContact();
    if (mode === 'detailed' && quick.kind) {
      const kind = quick.kind;
      byId('ask-' + kind).value = quick[kind];
      if (kind !== 'email' && !channelFields(chips())[kind]) {
        const channel = kind === 'phone' ? 'call' : 'telegram';
        channelInputs.find((input) => input.value === channel).checked = true;
      }
    } else if (mode === 'quick') {
      quickContact.value = detailed[quick.kind] || detailed.email || detailed.telegram || detailed.phone || '';
    }
    setMode(mode);
    syncChannelFields();
    growAll();
    hideFallback();
    setStatus('', false);
  }

  /** Телефон и ник по выбору чипов (Р9); почта, имя и компания видны всегда; без скрипта видны все поля. */
  function syncChannelFields() {
    const shown = channelFields(chips());
    form.querySelectorAll('[data-channel-field]').forEach((field) => {
      field.hidden = !shown[field.getAttribute('data-channel-field')];
    });
  }

  /** Высота поля запчасти по тексту: одна строка, со списком до шести, дальше прокрутка (forms.css). */
  function grow(card) {
    const area = card.id('ask-part');
    area.style.height = 'auto';
    area.style.height = area.scrollHeight + 'px';
  }

  const growAll = () => state.cards.forEach(grow);

  /** Мягкие подсказки: IMO по числу цифр и контрольной цифре. */
  function softHints() {
    state.cards.forEach((card) => {
      const imoSoft = card.id('ask-imo-soft');
      const imoProblemNow = imoProblem(card.value('ask-imo'));
      imoSoft.hidden = !imoProblemNow;
      imoSoft.textContent = imoProblemNow === 'checksum' ? typo(T.imoChecksum) : imoLengthText;
    });
  }

  // ---------- Карточки запчастей: «Добавить запчасть», «Убрать» (правки Доната 12.11) ----------

  /** Лимиты файлов в подсказке карточки; FILES.enabled прячет приложение (r2-code № 6). */
  function setupCard(card) {
    card.id('ask-files').hidden = !rules.enabled;
    card.id('ask-files-hint').textContent = typo(fill(FORM_TEXT.filesHint, { count: rules.maxCount, mb: limitMb(rules.maxBytes) }));
  }

  /** Заголовки «Запчасть N» (с одной запчастью их нет), «Убрать» у добавленных, кнопка добавления до MAX_PARTS. */
  function syncCards() {
    const many = state.cards.length > 1;
    state.cards.forEach((card, index) => {
      const title = fill(FORM_TEXT.lines.partTitle, { n: index + 1 });
      card.el.querySelector('[data-card-head]').hidden = !many;
      card.el.querySelector('[data-card-title]').textContent = title;
      card.el.querySelector('[data-card-remove]').hidden = card === first;
      if (many) {
        card.el.setAttribute('role', 'group');
        card.el.setAttribute('aria-label', title);
      } else {
        card.el.removeAttribute('role');
        card.el.removeAttribute('aria-label');
      }
    });
    addButton.hidden = state.cards.length >= MAX_PARTS;
  }

  /** Новая запчасть берёт у предыдущей поля из CARRY и выбор качества и логистики. */
  function carryFrom(previous, card) {
    CARRY.forEach((name) => { card.id(name).value = previous.value(name); });
    RADIO_GROUPS.forEach((name) => checkRadio(card.el, name + card.suffix, previous.radio(name)));
  }

  function addCard(carry) {
    state.cardSeq += 1;
    const suffix = '-' + state.cardSeq;
    const element = blank.cloneNode(true);
    renameCard(element, suffix);
    const card = makeCard(element, suffix);
    const previous = state.cards[state.cards.length - 1];
    partsBox.append(element);
    state.cards = [...state.cards, card];
    setupCard(card);
    if (carry) carryFrom(previous, card);
    syncCards();
    return card;
  }

  function onAddCard() {
    if (state.cards.length >= MAX_PARTS) return;
    const card = addCard(true);
    afterCardsChange(false); // пустую новую запчасть ошибкой не встречаем: её проверит следующая правка или отправка
    partsLive.textContent = typo(fill(T.partAdded, { n: state.cards.length }));
    card.id('ask-part').focus();
  }

  function removeCard(card) {
    if (!card || card === first) return;
    const index = state.cards.indexOf(card);
    card.el.remove();
    state.cards = state.cards.filter((item) => item !== card);
    previews.release(allFiles());
    syncCards();
    afterCardsChange(true);
    partsLive.textContent = typo(fill(T.partRemoved, { total: state.cards.length }));
    const next = state.cards[index];
    if (next) next.id('ask-part').focus();
    else if (isQuick()) state.cards.at(-1).id('ask-part').focus();
    else addButton.focus();
  }

  function afterCardsChange(repaint) {
    syncRadios();
    softHints();
    growAll();
    dropLastStep(); // текст заявки в «Последнем шаге» уже другой
    if (repaint && state.attempted) paint(errorsOf(collect()));
    scheduleDraft();
  }

  // ---------- Значения и ошибки ----------

  function cardFields(card) {
    const basic = { card, part: cleanText(card.value('ask-part')), files: card.files };
    if (isQuick()) return { ...basic, comment: '' };
    return {
      ...basic, comment: card.value('ask-comment').trim(), qty: card.value('ask-qty'),
      place: card.value('ask-port'),
      imo: card.value('ask-imo'), mech: card.value('ask-mech'), serial: card.value('ask-serial'),
      term: card.value('ask-term'),
      orig: card.radio('ask-orig'), advance: card.value('ask-advance'), logistics: card.radio('ask-logistics'),
    };
  }

  /**
   * Заявка из формы. Одна запчасть: номер, количество и место своими полями бэкенда, остальное строками комментария
   * (Р10). Несколько: номера списком в part, поля запчастей блоками в комментарии (askParts, partsComment).
   */
  function collect() {
    const kind = KIND;
    const quick = isQuick();
    const reply = quick ? parseContact(quickContact.value) : null;
    const chosen = quick ? cleanChannels([reply.kind === 'phone' ? 'call' : reply.kind]) : channels();
    const items = state.cards.map(cardFields);
    const files = allFiles();
    const shared = { kind, vat: !quick && byId('ask-vat').checked, channels: chosen };
    const name = quick ? '' : cleanLine(value('ask-name'));
    const contacts = quick ? channelContacts(chosen, reply) : detailedContact();
    const base = {
      kind, urgency: '', name: name || NAME_FALLBACK, ...contacts, company: quick ? '' : value('ask-company'), consent: agree.checked,
      hp: value('ask-hp'),
    };
    const common = {
      kind, chosen, items, files, nameGiven: Boolean(name),
      partText: items.map((item) => item.part).filter(Boolean).join('\n'), // для поиска наличия после отправки
    };
    if (items.length > 1) {
      const parsed = askParts(kind, items);
      const tail = askLines(shared).terms;
      const values = cleanValues({ ...base, part: parsed.part, qty: '', city: parsed.city, comment: partsComment(parsed, tail) });
      return { ...common, parsed, tail, values };
    }
    const [item] = items;
    const lines = askLines({ ...item, ...shared });
    const subject = hasRequestSubject(item.part, item.comment, files);
    const values = cleanValues({
      ...base,
      // Бэкенду нужен номер или файл; заявка из одного комментария уходит с запасной строкой (Р1, контракт POST тот же).
      part: item.part || (subject && !files.length ? FORM_TEXT.partFallback : ''),
      qty: item.qty,
      city: item.place,
      comment: requestComment([...lines.tech, ...lines.terms], item.comment), // строки Р10, потом слова человека
    });
    return { ...common, lines, userComment: item.comment, values };
  }

  /** Ошибки списком [поле, ключ текста, карточка]: карточка у полей запчасти, null у полей на всю заявку. */
  function errorsOf(data) {
    const core = findErrors(data.values, data.files, rules);
    const multi = data.items.length > 1;
    const firstCard = data.items[0].card;
    const lastCard = data.items[data.items.length - 1].card;
    const withFiles = data.items.find((item) => item.files.length) || data.items[0];
    const filesCard = state.cards.includes(state.filesCard) ? state.filesCard : withFiles.card;
    const cardFor = { files: filesCard, comment: multi ? lastCard : firstCard };
    const picked = CORE_ERRORS.filter((field) => core[field])
      .map((field) => [field, multi && field === 'comment' ? 'requestLong' : core[field], cardFor[field] || firstCard]);
    const perCard = data.items.flatMap((item) => [
      ...(hasRequestSubject(item.part, item.comment, item.files) ? [] : [['part', 'partOrComment', item.card]]),
      ...(cleanAdvance(item.advance) === null ? [['advance', 'advance', item.card]] : []),
    ]);
    const long = core.part === 'partLong' ? [['part', multi ? 'requestLong' : 'partLong', multi ? lastCard : firstCard]] : [];
    const name = core.name === 'nameLong' ? [['name', 'nameLong', null]] : [];
    const reach = Object.entries(channelErrors(data.chosen, data.values)).map(([field, key]) => [field, key, null]);
    return [...picked, ...perCard, ...long, ...name, ...reach];
  }

  const filesErrorOf = (errors) => errors.find(([field]) => field === 'files') || null;


  function messageFor(key) {
    if (isQuick() && key === 'partOrComment') return 'Укажите артикул или название запчасти либо прикрепите файл.';
    if (isQuick() && key === 'channels') return FORM_TEXT.errors.contact;
    if (isQuick() && key === 'messengerPhone') return FORM_TEXT.errors.phone;
    if (key === 'commentLong') {
      const { lines } = collect();
      if (!lines) return FORM_TEXT.errors.requestLong;
      const service = requestComment([...lines.tech, ...lines.terms], '') + '\n' + FORM_TEXT.comment + ': ';
      return fill(FORM_TEXT.errors.commentRoom, { n: commentRoom(service) });
    }
    if (key === 'messengerPhone') return fill(FORM_TEXT.errors.messengerPhone, { channels: phoneChannelsText(channels()) });
    // Ошибки файлов с числами и именем файла, которого форма не примет (07.11, придирки клиентов, А5).
    if (key.startsWith('files')) return filesErrorText(key, allFiles(), rules);
    return FORM_TEXT.errors[key] || '';
  }

  function clearErrors() {
    form.querySelectorAll('.ask__error').forEach((slot) => { slot.hidden = true; slot.textContent = ''; });
    form.querySelectorAll('[aria-invalid]').forEach((input) => input.removeAttribute('aria-invalid'));
    channelsBox.classList.remove('is-invalid');
    consentBox.classList.remove('is-error');
  }

  /** Видео тяжелее лимита не взяли (Р11): текст у приложения, если там нет настоящей ошибки. Заявку не держит. */
  function paintNotice() {
    state.cards.forEach((card) => {
      const slot = card.id('ask-files-error');
      if (!card.filesNotice || !slot.hidden) return;
      slot.textContent = typo(videoTooBigText(rules));
      slot.hidden = false;
    });
  }

  /** Рисует ошибки рядом с полями и возвращает поля с ошибкой в порядке на экране. */
  function paint(errors) {
    clearErrors();
    const invalid = errors.map(([field, key, card]) => {
      let target = SLOTS[field];
      if (isQuick()) {
        if (['channels', 'contact', 'messenger', 'email', 'phone', 'telegram'].includes(field)) target = SLOTS.quickContact;
        if (field === 'files') target = { ...SLOTS.files, input: 'ask-file' };
        if (field === 'comment') target = SLOTS.part;
      }
      if (!target) return null;
      const find = target.card ? (card || first).id : byId;
      const slot = find(target.slot);
      if (!slot || !slot.hidden) return null;
      slot.textContent = typo(messageFor(key));
      slot.hidden = false;
      if (target.group) channelsBox.classList.add('is-invalid');
      if (target.consent) consentBox.classList.add('is-error');
      const input = target.input === 'channel' ? channelInputs[0] : find(target.input);
      if (input && target.invalid !== false) input.setAttribute('aria-invalid', 'true');
      return input;
    }).filter(Boolean);
    paintNotice();
    return invalid.sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));
  }

  // ---------- Приложение: три кнопки и список в каждой карточке, лимит общий на заявку (Р11) ----------

  // Миниатюры фото в списке (07.11, придирки клиентов, А17): адреса blob: ведёт createPreviews (ask-ui.js).
  const previews = createPreviews(isPreviewable);

  function renderFiles(card) {
    const list = card.id('ask-files-list');
    previews.release(allFiles());
    list.replaceChildren(...card.files.map((file) => {
      const item = node('li', 'file-pill');
      const remove = node('button', '', '×');
      remove.type = 'button';
      remove.dataset.file = file.id;
      remove.setAttribute('aria-label', FORM_TEXT.removeFile + ': ' + file.name);
      const thumb = previews.thumb(file, item);
      item.append(...(thumb ? [thumb] : []), node('span', '', file.name), remove);
      return item;
    }));
    list.hidden = card.files.length === 0;
  }

  function repaintFiles() {
    const errors = errorsOf(collect());
    paint(state.attempted ? errors : errors.filter(([field]) => field === 'files'));
    return errors;
  }

  /** Итог выбора файлов одним тихим сообщением: что добавилось или что не так (r1-a11y, находка 6). */
  function announceFiles(card, errors, text) {
    const found = filesErrorOf(errors);
    card.id('ask-files-live').textContent = found ? typo(messageFor(found[1])) : typo(text);
  }

  /** Подготовка выбранных файлов по одному, не больше, чем осталось места; видео тяжелее лимита не берём. */
  function prepare(card, list, room) {
    const filesList = card.id('ask-files-list');
    const taking = Math.min(list.length, room);
    const epoch = state.epoch;
    // Запчасть убрали или форму очистили, пока файлы готовились: в чистую форму они не возвращаются.
    const gone = () => epoch !== state.epoch || !state.cards.includes(card);
    state.preparing += 1;
    state.pendingFiles += taking; // место занято уже сейчас: выбор в другой карточке общий лимит не перескочит
    filesList.hidden = false;
    filesList.append(node('li', 'file-pill is-pending', FORM_TEXT.preparing));
    state.filesReady = state.filesReady
      .then(() => prepareFiles(list, room))
      .then(({ prepared, skipped }) => {
        state.pendingFiles -= taking;
        if (gone()) return;
        card.files = card.files.concat(prepared);
        dropLastStep(); // файл выбрали, пока шаг уже на экране: строка «Файлы: …» в нём устарела (ревью r12, п. 1)
        renderFiles(card);
        const added = fill(T.filesAdded, { added: prepared.length, total: allFiles().length });
        const text = skipped ? added + ' ' + fill(FORM_TEXT.filesSkipped, { count: rules.maxCount }) : added;
        if (skipped) setStatus(typo(fill(FORM_TEXT.filesSkipped, { count: rules.maxCount })), false);
        announceFiles(card, repaintFiles(), text);
      })
      .catch(() => {
        state.pendingFiles -= taking;
        if (gone()) return;
        const failed = [['files', 'filesRead', card]];
        renderFiles(card);
        paint(failed);
        announceFiles(card, failed, '');
      })
      .finally(() => { state.preparing -= 1; });
  }

  function takeFiles(card, input) {
    const picked = Array.from(input.files || []);
    input.value = '';
    if (!card || !picked.length) return;
    state.filesCard = card;
    const heavy = picked.filter((file) => isVideoTooBig(file, rules));
    const list = picked.filter((file) => !isVideoTooBig(file, rules));
    card.filesNotice = heavy.length ? VIDEO_NOTICE : '';
    if (heavy.length) {
      repaintFiles();
      card.id('ask-files-live').textContent = typo(videoTooBigText(rules));
    }
    if (!list.length) return;
    const room = Math.max(0, rules.maxCount - allFiles().length - state.pendingFiles);
    if (!room) {
      const full = [['files', 'filesCount', card]];
      paint(full);
      announceFiles(card, full, '');
      return;
    }
    prepare(card, list, room);
  }

  function removeFile(card, fileId) {
    if (!card) return;
    card.files = card.files.filter((file) => file.id !== fileId);
    card.filesNotice = '';
    state.filesCard = card;
    dropLastStep(); // в тексте заявки строка «Файлы: …» уже другая
    renderFiles(card);
    announceFiles(card, repaintFiles(), fill(T.filesRemoved, { total: allFiles().length }));
    card.id(isQuick() ? 'ask-file' : 'ask-photo').focus();
  }

  // ---------- Один выбор с повторным нажатием: «Качество», логистика ----------

  form.addEventListener('click', (event) => {
    const input = event.target instanceof HTMLInputElement && event.target.matches('[data-toggle-radio]') ? event.target : null;
    if (!input) return;
    if (state.radios[input.name] !== input.value) {
      state.radios[input.name] = input.value;
      return;
    }
    input.checked = false; // нажали на уже выбранный вариант: снимаем выбор
    state.radios[input.name] = '';
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });

  /** Выбранное в каждой группе каждой карточки: имена групп у карточек свои. */
  function syncRadios() {
    const checked = Array.from(form.querySelectorAll('input[data-toggle-radio]:checked'));
    state.radios = Object.fromEntries(checked.map((input) => [input.name, input.value]));
  }

  // ---------- Черновик ----------

  const filledTexts = (read, ids) => Object.fromEntries(ids.map((id) => [id, read(id).slice(0, LIMITS.commentMax)]).filter(([, text]) => text));

  function readDraftFields() {
    const cards = state.cards.map((card) => ({
      texts: filledTexts(card.value, CARD_FIELDS),
      radios: Object.fromEntries(RADIO_GROUPS.map((name) => [name, card.radio(name)]).filter(([, chosen]) => chosen)),
    }));
    const texts = filledTexts(value, SHARED_FIELDS);
    const chosen = chips();
    const vatOff = !byId('ask-vat').checked;
    const filled = cards.some((card) => Object.keys(card.texts).length || Object.keys(card.radios).length);
    const quickReply = quickContact?.value || '';
    const meaningful = filled || cards.length > 1 || Object.keys(texts).length || chosen.length || quickReply || vatOff || allFiles().length;
    if (!meaningful) return null;
    return { cards, texts, channels: chosen, vat: vatOff ? '0' : '1', files: allFiles().length,
      mode: form.dataset.formMode, quickContact: quickReply };
  }

  const saveDraft = () => storeDraft(KIND, readDraftFields());

  function scheduleDraft() {
    window.clearTimeout(state.draftTimer);
    state.draftTimer = window.setTimeout(saveDraft, DRAFT_DELAY_MS);
  }

  function clearDraft() {
    window.clearTimeout(state.draftTimer);
    dropDraft();
  }

  function restoreCard(card, saved) {
    const texts = saved && typeof saved.texts === 'object' && saved.texts ? saved.texts : {};
    const radios = saved && typeof saved.radios === 'object' && saved.radios ? saved.radios : {};
    CARD_FIELDS.forEach((id) => {
      if (typeof texts[id] === 'string' && card.id(id) && !card.id(id).value) card.id(id).value = texts[id];
    });
    RADIO_GROUPS.forEach((name) => checkRadio(card.el, name + card.suffix, radios[name]));
  }

  function restoreDraft() {
    const draft = readDraft();
    if (!draft || draft.kind !== KIND) return false;
    const { cards: saved, channels: chosen, vat, files } = draft.fields;
    const texts = draft.fields.texts && typeof draft.fields.texts === 'object' ? draft.fields.texts : {};
    (Array.isArray(saved) ? saved : []).slice(0, MAX_PARTS).forEach((item, index) => {
      restoreCard(state.cards[index] || addCard(false), item);
    });
    SHARED_FIELDS.forEach((id) => {
      if (typeof texts[id] === 'string' && byId(id) && !byId(id).value) byId(id).value = texts[id];
    });
    const picked = cleanChannels(Array.isArray(chosen) ? chosen : []);
    channelInputs.forEach((input) => { input.checked = picked.includes(input.value); });
    byId('ask-vat').checked = vat !== '0';
    // Drafts created before the switch always used the detailed form.
    setMode(draft.fields.mode === 'quick' ? 'quick' : 'detailed');
    if (quickContact && typeof draft.fields.quickContact === 'string') quickContact.value = draft.fields.quickContact;
    draftNote.firstChild.textContent = typo(files ? T.draftNoFiles : draftText) + ' ';
    return true;
  }

  // ---------- Состояния: отправка, «Последний шаг», экран после отправки ----------

  // Статус всегда в дереве доступности, aria-busy на форме нет: иначе текст не звучит (r1-a11y, находка 1).
  function setStatus(content, isError) {
    status.classList.toggle('is-error', Boolean(isError));
    status.replaceChildren(...(Array.isArray(content) ? content : [content || '']));
  }

  function setBusy(busy) {
    state.busy = busy;
    sendLabel.textContent = busy ? T.sending : sendText;
    send.setAttribute('aria-disabled', String(busy));
    setStatus(busy ? typo(allFiles().length ? FORM_TEXT.sendingFiles : FORM_TEXT.sendingStatus) : '', false);
  }

  function summaryFor(data) {
    const name = data.nameGiven ? data.values.name : '';
    if (data.parsed) return partsSummary({ ...data.values, name }, data.parsed, data.tail);
    return askSummary({ ...data.values, part: data.items[0].part, name }, data.lines, data.userComment, data.files);
  }

  /** «Последний шаг» (live без адреса приёма) и сбои отправки: кнопки контактов, текст заявки и копирование. */
  async function showFallback(kind, text) {
    const { nodes, live } = sendParts(text, allFiles().length);
    const copied = kind === 'offline' ? await copyText(text) : false;
    // Форма не подключена: не ошибка посетителя, красным не пугаем. Сбои сети и сервера красные.
    setStatus(rich(fallbackStatus(kind, live[0], copied), { messenger: messengerNode(), action: live[0] ? buttonLabel(live[0]) : '' }), kind !== 'offline');
    const parts = nodes.slice();
    if (!live.length && root.classList.contains('review')) {
      // Контактов нет совсем: образцы с вопросами только для Доната, посетитель видит текст заявки и статус.
      const line = node('p', 'ask__fallback-text');
      line.append(...rich(T.noContacts, { messenger: contactStub('messenger'), phone: contactStub('phone', 'nowrap') }));
      parts.push(line);
    }
    fallback.replaceChildren(...parts, ...summaryBox(text));
    fallback.hidden = false;
    state.fallbackKind = kind;
    markLastStep(kind === 'offline');
    fallback.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'nearest' });
  }

  function hideFallback() {
    fallback.hidden = true;
    fallback.replaceChildren();
    state.fallbackKind = '';
    markLastStep(false);
  }

  /** Пока виден «Последний шаг», красная кнопка одна: «Отправить в Telegram»; у кнопки формы контур (07.11, клиенты, А1). */
  function markLastStep(shown) {
    send.classList.toggle('btn--red', !shown);
    send.classList.toggle('btn--ghost', shown);
  }

  /**
   * Правка формы после «Последнего шага» прячет его: ссылка в мессенджер ушла бы со старым текстом заявки.
   * Только шаг без адреса приёма (вид 'offline'): блок сбоя с «заявка могла не дойти» остаётся до следующей
   * отправки (ревью r12, п. 6).
   */
  function dropLastStep() {
    if (fallback.hidden || state.fallbackKind !== 'offline') return;
    hideFallback();
    setStatus('', false);
  }

  const doneScreen = mountDone(byId('ask-done'), { onAgain: () => { startOver(); part.focus(); } });

  function showDone(result, data, text) {
    form.hidden = true;
    doneScreen.show(result, { part: data.partText, kind: data.kind, text, filesCount: data.files.length });
  }

  /** Новая заявка после отправленной: без прежних запчастей, файлов и согласия; контакты, способы связи и техника остаются. */
  function startOver() {
    const kept = KEPT_FIELDS.map((id) => [id, value(id)]);
    const chosen = chips();
    const mode = form.dataset.formMode;
    const quickReply = quickContact?.value || '';
    resetForm();
    setMode(mode);
    if (quickContact) quickContact.value = quickReply;
    kept.forEach(([id, text]) => { byId(id).value = text; });
    channelInputs.forEach((input) => { input.checked = chosen.includes(input.value); });
    syncChannelFields();
    scheduleDraft();
    doneScreen.hide();
    form.hidden = false;
  }

  function resetForm() {
    state.cards.filter((card) => card !== first).forEach((card) => card.el.remove());
    state.cards = [first];
    form.reset(); // счёт с НДС снова отмечен (checked в разметке), согласие снято
    setMode('quick');
    state.epoch += 1; // файлы, которые ещё готовятся, в очищенную форму не попадут
    first.files = [];
    first.filesNotice = '';
    state.filesCard = null;
    state.attempted = false;
    renderFiles(first);
    paint([]);
    hideFallback();
    setStatus('', false);
    clearDraft();
    draftNote.hidden = true;
    partsLive.textContent = '';
    first.id('ask-files-live').textContent = '';
    syncCards();
    syncRadios();
    syncChannelFields();
    growAll();
    softHints();
  }

  const elapsed = () => performance.now() - state.shownAt;

  /**
   * Быстрее 3 секунд бэкенд принял бы заявку за бота и молча выбросил. Ждём порог с запасом в цикле: таймер может
   * сработать на долю миллисекунды раньше. Начало отправки замораживает момент показа формы (ревью 12.11, п. 6).
   */
  async function waitElapsed() {
    state.sendStarted = true;
    const target = LIMITS.minElapsedMs + ELAPSED_MARGIN_MS;
    while (elapsed() < target) await new Promise((resolve) => { window.setTimeout(resolve, target - elapsed()); });
  }

  async function sendWithFiles(data) {
    let files;
    try {
      files = await encodeFiles(data.files);
    } catch (error) {
      return { type: 'field', field: 'files', key: 'filesRead' };
    }
    await waitElapsed();
    const body = buildBody(data.values, files, Math.ceil(elapsed()), window.location.href, CONSENT_VERSION);
    return sendLead({ endpoint: ENDPOINT, body, timeoutMs: requestTimeoutMs(body.toString().length) });
  }

  async function onSubmit(event) {
    event.preventDefault();
    if (state.submitting || state.busy) return;
    state.submitting = true; // до первого await: второе нажатие сюда уже не пройдёт
    if (modePicker) modePicker.disabled = true;
    try {
      await submitOnce();
    } finally {
      state.submitting = false;
      if (modePicker) modePicker.disabled = false;
    }
  }

  /** Ждёт все подготовки файлов, и те, что начались, пока ждали: иначе заявка ушла бы без них (ревью r12, п. 1). */
  async function filesSettled() {
    let current;
    do {
      current = state.filesReady;
      await current;
    } while (current !== state.filesReady);
  }

  async function submitOnce() {
    if (state.preparing) setStatus(typo(FORM_TEXT.preparing), false);
    await filesSettled();
    state.attempted = true;
    const data = collect();
    hideFallback();
    setStatus('', false);
    const invalid = paint(errorsOf(data));
    if (invalid.length) {
      invalid[0].focus();
      return;
    }
    saveDraft();
    const text = summaryFor(data);
    if (!isEndpointSet(ENDPOINT)) {
      // Превью: тот же экран после отправки с пометкой «Пример экрана…»; live: честный «Последний шаг» (Р12).
      if (root.dataset.mode === 'preview') showDone({ type: 'preview' }, data, text);
      else await showFallback('offline', text);
      return;
    }
    setBusy(true);
    const result = await sendWithFiles(data);
    setBusy(false);
    await afterSend(result, data, text);
  }

  async function afterSend(result, data, text) {
    if (result.type === 'success') {
      clearDraft();
      showDone(result, data, text);
      return;
    }
    if (result.type === 'field') {
      // Поле назвал сервер: у полей запчасти это первая карточка, у файлов та, где их трогали последними.
      const card = result.field === 'files' && state.cards.includes(state.filesCard) ? state.filesCard : first;
      const fieldInvalid = paint([[result.field, result.key, card]]);
      if (fieldInvalid[0]) fieldInvalid[0].focus();
      return;
    }
    await showFallback(result.type, text);
  }

  // ---------- Подстановка из листов чертежа и адреса ----------

  function prefill(detail) {
    const source = detail || {};
    if (form.hidden) startOver();
    dropLastStep(); // узел чертежа меняет заявку
    if (typeof source.part === 'string' && source.part) {
      const next = source.part.slice(0, LIMITS.partMax);
      const own = part.value.trim() && part.value.trim() !== state.lastPrefill.trim(); // это человек написал сам
      const already = part.value.split('\n').some((line) => line.trim() && line.trim() === next.trim());
      if (!already) part.value = own ? (part.value.trimEnd() + '\n' + next).slice(0, LIMITS.partMax) : next;
      state.lastPrefill = next;
      grow(first);
      scheduleDraft();
    }
    const contactInput = isQuick() ? quickContact : byId('ask-email');
    const target = source.focus === 'contact' && part.value.trim() ? contactInput : part;
    form.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
    window.setTimeout(() => {
      target.focus({ preventScroll: true });
      if (target === part) part.setSelectionRange(part.value.length, part.value.length);
    }, reduceMotion ? 0 : FOCUS_DELAY_MS);
  }

  // ---------- События ----------

  form.addEventListener('submit', onSubmit);
  form.addEventListener('click', (event) => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const fileButton = target.closest('button[data-file]');
    const removeButton = target.closest('[data-card-remove]');
    if (target.closest('[data-add-part]')) onAddCard();
    else if (removeButton) removeCard(cardOf(removeButton));
    else if (fileButton) removeFile(cardOf(fileButton), fileButton.dataset.file);
  });
  // Своё поле «Последнего шага» (текст заявки только для чтения) правкой формы не считается.
  const isEdit = (event) => event.target instanceof Node && !fallback.contains(event.target);
  form.addEventListener('input', (event) => {
    if (isEdit(event)) dropLastStep();
    const card = cardOf(event.target);
    if (card && event.target === card.id('ask-part')) {
      grow(card);
    }
    if (state.attempted) paint(errorsOf(collect()));
    scheduleDraft();
  });
  form.addEventListener('change', (event) => {
    const target = event.target;
    if (isEdit(event)) dropLastStep();
    if (target instanceof HTMLInputElement && target.name === 'ask-mode') changeMode(target.value);
    if (target instanceof HTMLInputElement && target.type === 'file') {
      takeFiles(cardOf(target), target);
      return;
    }
    if (target instanceof HTMLInputElement && target.name === 'ask-channel') syncChannelFields();
    if (target instanceof HTMLInputElement && target.matches('[data-toggle-radio]')) syncRadios();
    softHints();
    if (state.attempted) paint(errorsOf(collect()));
    scheduleDraft();
  });
  draftNote.querySelector('[data-draft-clear]').addEventListener('click', () => {
    resetForm();
    part.focus();
  });
  doc.addEventListener(ASK_EVENT, (event) => prefill(event.detail));
  window.addEventListener('resize', growAll);

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      if (state.sendStarted || !entries.some((entry) => entry.isIntersecting)) {
        if (state.sendStarted) observer.disconnect(); // отправка началась: момент показа больше не двигаем
        return;
      }
      state.shownAt = performance.now();
      observer.disconnect();
    }, { threshold: 0.1 });
    observer.observe(form);
  }

  setupCard(first);
  try {
    draftNote.hidden = !restoreDraft();
  } catch (error) {
    clearDraft(); // черновик испорчен так, что не читается: форма должна работать и без него
    draftNote.hidden = true;
  }
  syncCards();
  syncRadios();
  syncChannelFields();
  growAll();
  softHints();
  prefillFromAddress(prefill);
  // Файлы выбрали раньше, чем подключился скрипт.
  Array.from(first.el.querySelectorAll('input[type="file"][data-pick]'))
    .filter((input) => input.files && input.files.length)
    .forEach((input) => takeFiles(first, input));
  // В разметке кнопка disabled: без скрипта Enter в форме её не отправит (santa-d, предложение 1).
  send.disabled = false;
  if (modePicker) modePicker.hidden = false;
  root.classList.add('js');
  root.dataset.ask = 'ready';
}

/**
 * Запчасть из адреса: узлы чертежа и ссылки на заявку ведут на главную ?kind=marine&part=…#ask (Р5).
 * Пробел в конце part не срезается: узел чертежа передаёт «Турбокомпрессор: ». После подстановки kind и part
 * убираются из адреса: перезагрузка не затрёт дописанное поверх черновика.
 */
function prefillFromAddress(prefill) {
  const address = new URL(window.location.href);
  const rawKind = address.searchParams.get('kind') || '';
  if (rawKind && rawKind !== KIND) return;
  const kind = rawKind;
  const part = (address.searchParams.get('part') || '').slice(0, LIMITS.partMax);
  if (!part.trim() && !(kind && address.hash === '#ask')) return;
  prefill({ kind, part, focus: 'part' });
  address.searchParams.delete('kind');
  address.searchParams.delete('part');
  window.history.replaceState(window.history.state, '', address.pathname + address.search + address.hash);
}

const askForm = doc.querySelector('form[data-ask]');
if (askForm) mount(askForm);
