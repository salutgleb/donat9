// DONAT9: общий скрипт всех страниц. ES-модуль без зависимостей, подключает раскладка (src/partials/layout.html).
// Шапка, меню на телефоне, нижняя панель, выбор «судовые / грузовые» на всю страницу, переходы к форме,
// листы чертежа с узлами, рост полос шкалы сроков, контакты из config.js, пауза бегущих строк, режим проверки ?review=1.
// Окно «Статус заявки» ведёт отдельный модуль track.js. Поиска по наличию и «трёх путей» на страницах нет
// с правок Доната 11.11 (review/donat-korr/SPEC.md, Р6, Р8).
//
// Договорённости разметки (подробно в src/README.md):
//   [data-menu-toggle] + #menu        кнопка меню и само меню
//   #dock, [data-dock-hide]           нижняя панель телефона и блоки, у которых она прячется
//   a[data-to-form]                   ссылка на форму на этой странице: плавно к ней и фокус в первое поле
//   [data-sheet] [data-node]          лист чертежа: узел подсвечивается вместе с легендой, клик начинает заявку
//   [data-eta]                        шкала сроков: полосы раскрываются один раз, когда видно 60 % списка
//   [data-contact="telegram|phone|email|whatsapp|max"]  контакт из CONTACTS в config.js: живая ссылка t.me, tel:,
//                                     mailto:, wa.me, профиль в Максе; пустое значение оставляет образец-заглушку без ссылки
//   [data-marquee] [data-marquee-toggle]  бегущая строка и её кнопка паузы (aria-controls = id строки)
//   .tbc[data-tbc]                    заглушка; в ?review=1 подсвечена, вопросы собраны в список

import { CONTACTS } from './config.js';
import { formatPhone, normalizeNick, normalizePhone } from './lead-core.js';

const doc = document;
const root = doc.documentElement;
const ASK_EVENT = 'donat9:ask'; // ask.js: подставить запчасть в заявку и поставить фокус
const ASK_ANCHOR = 'ask'; // id формы заявки: на главной, /marine/ и /truck/
const MENU_INERT = 'main, .footer, .dock, .skip';
const DESKTOP_MIN_PX = 1100;
const FOCUS_DELAY_MS = 450;
const REVIEW_DEBOUNCE_MS = 150;
const REVIEW_TIP_MAX_PX = 320; // подсказка ?review=1: max-width в base.css, min(320px, 80vw)
const REVIEW_TIP_MAX_SHARE = 0.8;
const REVIEW_TIP_EDGE_PX = 8; // зазор подсказки до края окна
const PING_MS = 1800;
const ETA_SHARE = 0.6; // полосы раскрываются, когда над нижней панелью видно 60 % списка
const ETA_THRESHOLDS = Object.freeze([0.1, 0.2, 0.3, 0.4, 0.5, ETA_SHARE]); // шаги ниже 0,6 для списка выше окна
const ETA_ARM_EVENTS = Object.freeze(['wheel', 'touchstart', 'pointerdown', 'keydown']); // первое действие человека
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const scrollMode = reduceMotion ? 'auto' : 'smooth';

const $ = (selector, context) => (context || doc).querySelector(selector);
const $$ = (selector, context) => Array.from((context || doc).querySelectorAll(selector));
const isShown = (node) => node.getClientRects().length > 0;

// ---------- Шапка: волосяная линия, когда страница прокручена ----------

function initHeader() {
  const header = $('.header');
  if (!header) return;
  let queued = false;
  const update = () => {
    queued = false;
    header.classList.toggle('is-scrolled', window.scrollY > 4);
  };
  window.addEventListener('scroll', () => {
    if (queued) return;
    queued = true;
    window.requestAnimationFrame(update);
  }, { passive: true });
  update();
}

// ---------- Нижняя панель: только между первым экраном и формой, скрытая не ловит фокус ----------

const dock = { node: null, visible: new Set(), ready: false, menuOpen: false };

function syncDock() {
  if (!dock.node) return;
  const on = dock.ready && dock.visible.size === 0 && !dock.menuOpen;
  dock.node.classList.toggle('is-on', on);
  dock.node.inert = !on;
}

function initDock() {
  dock.node = $('#dock');
  if (!dock.node) return;
  const watched = $$('[data-dock-hide]');
  if (!watched.length || !('IntersectionObserver' in window)) {
    dock.ready = true;
    syncDock();
    return;
  }
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) dock.visible.add(entry.target);
      else dock.visible.delete(entry.target);
    });
    dock.ready = true;
    syncDock();
  });
  watched.forEach((node) => observer.observe(node));
}

// ---------- Меню на телефоне: страница под ним inert, фокус внутри и обратно на кнопку ----------

function initMenu() {
  const toggle = $('[data-menu-toggle]');
  const menu = $('#menu');
  if (!toggle || !menu) return;
  const set = (open, returnFocus) => {
    dock.menuOpen = open;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    menu.hidden = !open;
    doc.body.classList.toggle('is-locked', open);
    $$(MENU_INERT).forEach((node) => { node.inert = open; });
    syncDock();
    if (open) {
      const first = $('a', menu);
      if (first) first.focus();
    } else if (returnFocus) {
      toggle.focus();
    }
  };
  toggle.addEventListener('click', () => set(menu.hidden, true));
  menu.addEventListener('click', (event) => {
    if (event.target instanceof Element && event.target.closest('a')) set(false, false);
  });
  doc.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !menu.hidden) set(false, true);
  });
  window.addEventListener('resize', () => {
    if (!menu.hidden && window.innerWidth >= DESKTOP_MIN_PX) set(false, false);
  });
}

// ---------- «Судовые / грузовые»: один выбор на всю страницу ----------


// ---------- Переходы к форме на этой же странице ----------

function focusFirstField(container) {
  const fields = $$('textarea, select, input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="file"])', container);
  const field = fields.find(isShown);
  if (field) field.focus({ preventScroll: true });
}

function initToForm() {
  doc.addEventListener('click', (event) => {
    const link = event.target instanceof Element ? event.target.closest('a[data-to-form]') : null;
    if (!link) return;
    const url = new URL(link.href, window.location.href);
    if (url.pathname !== window.location.pathname || !url.hash) return;
    const target = doc.getElementById(decodeURIComponent(url.hash.slice(1)));
    if (!target || !isShown(target)) return;
    event.preventDefault();
    target.scrollIntoView({ behavior: scrollMode, block: 'start' });
    window.setTimeout(() => focusFirstField(target), reduceMotion ? 0 : FOCUS_DELAY_MS);
  });
}

/** Подставить запчасть в заявку на этой странице; без формы перейти к форме главной (Р5). */
function askFor(detail, requestHref) {
  if (root.dataset.ask === 'ready') {
    doc.dispatchEvent(new CustomEvent(ASK_EVENT, { detail }));
    return;
  }
  if (!requestHref) return;
  const url = new URL(requestHref, window.location.href);
  if (detail.kind === 'marine') url.searchParams.set('kind', detail.kind);
  if (detail.part) url.searchParams.set('part', detail.part);
  url.hash = ASK_ANCHOR; // ask.js на главной подставит kind и part из адреса
  window.location.href = url.href;
}

// ---------- Лист чертежа: номер на рисунке и строка легенды подсвечиваются вместе ----------

function initSheets() {
  $$('[data-sheet]').forEach((sheet) => {
    const hot = (node, on) => $$('[data-node="' + node + '"]', sheet).forEach((item) => item.classList.toggle('is-hot', on));
    const nodeOf = (event) => (event.target instanceof Element ? event.target.closest('[data-node]') : null);
    const toggle = (on) => (event) => {
      const node = nodeOf(event);
      if (node) hot(node.dataset.node, on);
    };
    sheet.addEventListener('pointerover', toggle(true));
    sheet.addEventListener('pointerout', toggle(false));
    sheet.addEventListener('focusin', toggle(true));
    sheet.addEventListener('focusout', toggle(false));
    // Строки легенды в разметке ссылки на форму главной ?kind=…&part=…#ask (без JS тоже начинают заявку, santa-c № 4).
    // Со скриптом переход не нужен: узел уходит в форму этой страницы, а подсказка про узлы описывает строки.
    const hint = $('.sheet__hint', sheet);
    if (hint && hint.id) $$('.legend [data-node]', sheet).forEach((item) => item.setAttribute('aria-describedby', hint.id));
    sheet.addEventListener('click', (event) => {
      const node = nodeOf(event);
      if (!node) return;
      event.preventDefault();
      const row = $('.legend [data-node="' + node.dataset.node + '"]', sheet);
      askFor({ kind: sheet.dataset.sheet, part: row ? row.dataset.part : '', focus: 'part' }, sheet.dataset.requestHref);
    });
  });
}

// ---------- Шкала сроков «Дней в пути»: полосы раскрываются один раз, когда видно 60 % списка ----------
// Полосы прячет только класс eta--anim (src/css/eta.css), и ставит его этот скрипт: без JS, при ошибке скрипта,
// при «меньше движения» и в печати полосы полные. Следим за списком полос, а не за карточкой: верх карточки бывает
// в первом экране, а полосы ниже его края.
// Раскрытие начинается, когда над нижней панелью телефона видно 60 % списка (на десктопе панели нет, её высота 0);
// высоту панели берём заново при повороте и смене размера окна. Список выше окна раскрывается, когда занял 60 % окна.
// Шкала, которая видна при запуске скрипта, остаётся полной. С якорем в адресе (/delivery/#sroki) и после
// перезагрузки браузер сам прокручивает страницу, и сделает это позже нашего скрипта: тогда видимость проверяем
// при первом действии человека (колесо, касание, клавиша, нажатие), и шкала, которая к нему в окне, остаётся полной.

function initEta() {
  if (reduceMotion || !('IntersectionObserver' in window)) return;
  const lists = $$('[data-eta] .eta__list');
  if (!lists.length) return;
  const waiting = new Set();
  let observer = null;
  let dockHeight = -1;
  const reveal = (entry) => {
    const room = entry.rootBounds ? entry.rootBounds.height : window.innerHeight;
    const enough = entry.intersectionRatio >= ETA_SHARE || entry.intersectionRect.height >= room * ETA_SHARE;
    if (!entry.isIntersecting || !enough) return;
    entry.target.closest('[data-eta]').classList.add('is-in');
    waiting.delete(entry.target);
    observer.unobserve(entry.target);
  };
  const watch = () => {
    const panel = $('#dock');
    const height = panel ? panel.offsetHeight : 0;
    if (observer && height === dockHeight) return;
    dockHeight = height;
    if (observer) observer.disconnect();
    observer = new IntersectionObserver((entries) => entries.forEach(reveal),
      { threshold: ETA_THRESHOLDS, rootMargin: '0px 0px -' + height + 'px 0px' });
    waiting.forEach((list) => observer.observe(list));
  };
  const arm = () => {
    ETA_ARM_EVENTS.forEach((type) => window.removeEventListener(type, arm, true));
    lists.forEach((list) => {
      const box = list.getBoundingClientRect();
      if (box.top < window.innerHeight && box.bottom > 0) return; // видна сейчас: остаётся полной
      list.closest('[data-eta]').classList.add('eta--anim');
      waiting.add(list);
    });
    if (!waiting.size) return;
    watch();
    window.addEventListener('resize', watch, { passive: true });
  };
  const navigation = performance.getEntriesByType ? performance.getEntriesByType('navigation')[0] : null;
  const restored = Boolean(navigation) && (navigation.type === 'reload' || navigation.type === 'back_forward');
  if (!window.location.hash && !restored) {
    arm();
    return;
  }
  ETA_ARM_EVENTS.forEach((type) => window.addEventListener(type, arm, { capture: true, passive: true }));
}

// ---------- Контакты из одного источника: CONTACTS в config.js (r1-fixes п. 3) ----------
// <span class="tbc" data-tbc="…" data-contact="phone">номер появится к запуску</span> в разметке: образец-заглушка.
// Если в CONTACTS есть значение, элемент становится ссылкой; вопрос из CONTACTS.tbc[вид] остаётся заглушкой
// вокруг текста ссылки (в ?review=1 подсвечен). data-contact-text: текст ссылки вместо значения,
// data-contact-icon: какой значок поставить, [data-contact-label]: куда писать текст, если внутри есть значок.

const NICK_RE = /^[A-Za-z0-9_]{5,32}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const WHATSAPP_URL = 'https://wa.me/';

/** Профиль в Максе: только https-ссылка (CONTACTS.max), иначе мёртвой или чужой ссылки на сайте не будет. */
function maxProfile(value) {
  try {
    const url = new URL(String(value || '').trim());
    return url.protocol === 'https:' ? url.href : '';
  } catch {
    return ''; // не адрес: образец-заглушка остаётся
  }
}

/** Как из значения CONTACTS сделать ссылку: по виду контакта. Нет значения или оно не годится: null. */
const CONTACT_KINDS = Object.freeze({
  telegram: (source) => {
    const nick = normalizeNick(source.telegram || '');
    return NICK_RE.test(nick) ? { href: 'https://t.me/' + nick, text: 'Telegram', external: true } : null;
  },
  phone: (source) => {
    const phone = normalizePhone(source.phone || '');
    return phone ? { href: 'tel:' + phone, text: formatPhone(phone), external: false } : null;
  },
  email: (source) => {
    const email = String(source.email || '').trim();
    return EMAIL_RE.test(email) ? { href: 'mailto:' + email, text: email, external: false } : null;
  },
  // WhatsApp по номеру: wa.me/<цифры без плюса>. Подпись по умолчанию номер; в подвале и на /contacts/ data-contact-text.
  whatsapp: (source) => {
    const phone = normalizePhone(source.whatsapp || '');
    return phone ? { href: WHATSAPP_URL + phone.replace(/[^0-9]/g, ''), text: formatPhone(phone), external: true } : null;
  },
  max: (source) => {
    const href = maxProfile(source.max);
    return href ? { href, text: 'Макс', external: true } : null;
  },
});

function contactInfo(kind) {
  const read = Object.hasOwn(CONTACT_KINDS, kind) ? CONTACT_KINDS[kind] : null;
  return read ? read(CONTACTS || {}) : null;
}

function contactText(kind, info, question) {
  if (!question) return doc.createTextNode(info.text);
  const span = doc.createElement('span');
  span.className = kind === 'phone' || kind === 'whatsapp' ? 'tbc nowrap' : 'tbc';
  span.setAttribute('data-tbc', question);
  span.textContent = info.text;
  return span;
}

function initContacts() {
  const questions = (CONTACTS && CONTACTS.tbc) || {};
  $$('[data-contact]').forEach((node) => {
    const kind = node.dataset.contact;
    const found = contactInfo(kind);
    if (!found) return; // значения нет: образец-заглушка остаётся, мёртвой ссылки нет
    const info = node.dataset.contactText ? { ...found, text: node.dataset.contactText } : found;
    const link = node.tagName === 'A' ? node : doc.createElement('a');
    if (link !== node) {
      link.className = node.className;
      node.replaceWith(link);
    }
    link.classList.remove('tbc');
    link.removeAttribute('data-tbc');
    link.href = info.href;
    if (info.external) {
      link.target = '_blank';
      link.rel = 'noopener';
    }
    const icon = node.dataset.contactIcon ? $('use', link) : null;
    if (icon) icon.setAttribute('href', node.dataset.contactIcon);
    const label = $('[data-contact-label]', link) || link;
    label.replaceChildren(contactText(kind, info, questions[kind]));
    // Контакт задан: обёртка с образцом (.if-contact) теперь показывается всем.
    const wrap = link.closest('.if-contact');
    if (wrap) wrap.classList.add('is-live');
  });
}

// ---------- Бегущие строки (/about/): пауза кнопкой и за экраном ----------
// Движение и паузу по наведению делает CSS (components.css, .marquee): фокусируемых элементов в ленте нет. Кнопка
// [data-marquee-toggle] ставит строке из aria-controls класс is-paused, отвечает aria-pressed и меняет title
// («Остановить строку» или «Запустить строку»; WCAG 2.2.2: движение дольше 5 секунд можно остановить). Строка за экраном
// стоит (класс is-away): бесконечная анимация не крутится зря. Без скрипта кнопки нет, и строка стоит.
const MARQUEE_TITLES = Object.freeze({ pause: 'Остановить строку', play: 'Запустить строку' });

function watchMarqueeVisibility() {
  const strips = $$('[data-marquee]');
  if (!strips.length || !('IntersectionObserver' in window)) return;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => entry.target.classList.toggle('is-away', !entry.isIntersecting));
  });
  strips.forEach((strip) => {
    strip.classList.add('is-away'); // до первого ответа наблюдателя стоит: за экраном при загрузке не едет
    observer.observe(strip);
  });
}

function initMarquee() {
  watchMarqueeVisibility();
  $$('[data-marquee-toggle]').forEach((button) => {
    const strip = doc.getElementById(button.getAttribute('aria-controls') || '');
    if (!strip) return;
    button.addEventListener('click', () => {
      const paused = button.getAttribute('aria-pressed') !== 'true';
      button.setAttribute('aria-pressed', String(paused));
      button.title = paused ? MARQUEE_TITLES.play : MARQUEE_TITLES.pause; // что сделает следующее нажатие
      strip.classList.toggle('is-paused', paused);
    });
  });
}

// ---------- Режим проверки ?review=1: все вопросы к Донату одним списком ----------

function reviewButton(index, question, places) {
  const button = doc.createElement('button');
  button.type = 'button';
  button.dataset.qa = 'review-item';
  const number = doc.createElement('span');
  number.textContent = String(index + 1).padStart(2, '0');
  const text = doc.createElement('span');
  text.textContent = question;
  const where = doc.createElement('small');
  const sample = places[0].textContent.replace(/\s+/g, ' ').trim().slice(0, 60);
  where.textContent = '«' + sample + '»' + (places.length > 1 ? ', мест: ' + places.length : '');
  button.append(number, text, where);
  button.addEventListener('click', () => {
    const target = places.find(isShown) || places[0];
    target.scrollIntoView({ behavior: scrollMode, block: 'center' });
    target.classList.remove('is-ping');
    void target.offsetWidth;
    target.classList.add('is-ping');
    window.setTimeout(() => target.classList.remove('is-ping'), PING_MS);
  });
  return button;
}

/**
 * Подсказка «Спросить у Доната» не уходит за правый край: перед показом сдвигаем её влево ровно на перелёт
 * (--tbc-dx в base.css). Ширина подсказки та же, что в CSS: не больше 320 px и 80 % окна (круг 4, дизайн, п. 9).
 */
function initReviewTips() {
  const place = (event) => {
    const node = event.target instanceof Element ? event.target.closest('.tbc[data-tbc]') : null;
    if (!node) return;
    const width = Math.min(REVIEW_TIP_MAX_PX, window.innerWidth * REVIEW_TIP_MAX_SHARE);
    const room = doc.documentElement.clientWidth - REVIEW_TIP_EDGE_PX;
    const first = node.getClientRects()[0] || node.getBoundingClientRect(); // строчная заглушка в две строки: от первой
    const left = first.left;
    const shift = Math.min(0, room - (left + width));
    node.style.setProperty('--tbc-dx', `${Math.max(shift, REVIEW_TIP_EDGE_PX - left)}px`);
  };
  doc.addEventListener('mouseover', place);
  doc.addEventListener('focusin', place);
}

function initReview() {
  if (!root.classList.contains('review')) return;
  const panel = doc.createElement('div');
  panel.className = 'rv';
  panel.dataset.qa = 'review-panel';
  const list = doc.createElement('div');
  list.className = 'rv__list';
  list.id = 'rv-list';
  list.hidden = true;
  const toggle = doc.createElement('button');
  toggle.type = 'button';
  toggle.className = 'rv__btn';
  toggle.setAttribute('aria-expanded', 'false');
  toggle.setAttribute('aria-controls', 'rv-list');
  toggle.addEventListener('click', () => {
    list.hidden = !list.hidden;
    toggle.setAttribute('aria-expanded', String(!list.hidden));
  });
  panel.append(list, toggle);
  doc.body.append(panel);

  const build = () => {
    // Один вопрос в списке один раз, сколько бы мест его ни ждало (r2-fixes п. 11): ключ без регистра,
    // лишних пробелов и точки в конце, показывается первая формулировка.
    const groups = new Map();
    $$('.tbc[data-tbc]').forEach((node) => {
      if (panel.contains(node)) return;
      const question = node.getAttribute('data-tbc').replace(/\s+/g, ' ').trim();
      const key = question.toLowerCase().replace(/[.?!\s]+$/, '');
      if (!groups.has(key)) groups.set(key, { question, places: [] });
      groups.get(key).places.push(node);
      if (!node.matches('a, button, input, select, textarea') && !node.hasAttribute('tabindex')) node.tabIndex = 0;
    });
    const intro = doc.createElement('p');
    intro.textContent = 'Подсвечено всё, что нужно подтвердить у Доната. Нажмите на вопрос, страница покажет место.';
    list.replaceChildren(intro, ...Array.from(groups.values(), ({ question, places }, index) => reviewButton(index, question, places)));
    const count = doc.createElement('b');
    count.textContent = String(groups.size);
    toggle.replaceChildren('Вопросы к Донату', count);
  };

  build();
  initReviewTips();
  let timer = 0;
  new MutationObserver((mutations) => {
    if (mutations.every((mutation) => panel.contains(mutation.target))) return;
    window.clearTimeout(timer);
    timer = window.setTimeout(build, REVIEW_DEBOUNCE_MS);
  }).observe(doc.body, { childList: true, subtree: true });
}

initHeader();
initContacts();
initDock();
initMenu();
initToForm();
initSheets();
initEta();
initMarquee();
initReview();
