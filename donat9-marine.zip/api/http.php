<?php
/**
 * DONAT9: общие ответы HTTP для lead.php и status.php: JSON для сайта, CORS по allowed_origins,
 * заголовки служебных страниц с полем для ключа. Снаружи не открывается (.htaccess).
 */

declare(strict_types=1);

function d9_json(int $status, array $data): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function d9_cors(array $config): void
{
    $origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
    if ($origin !== '' && in_array($origin, (array) $config['allowed_origins'], true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    }
}

/**
 * Откуда пришёл служебный POST (выгрузка, смена статуса). С Referrer-Policy: no-referrer браузер шлёт форму
 * своей страницы с «Origin: null», curl и менеджер закачек без Origin, поэтому пропускаем пустой, «null»
 * и адреса из allowed_origins. Явно чужой сайт отвергается до проверки ключа: попытку не тратит, в журнал не пишет.
 */
function d9_service_origin_ok(array $config): bool
{
    $origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
    return $origin === '' || $origin === 'null' || in_array($origin, (array) $config['allowed_origins'], true);
}

/**
 * Заголовки служебной страницы (выгрузка, смена статусов): без кэша, без встраивания во фрейм, без чужих скриптов.
 * Её форму защищает ключ; Origin проверяет d9_service_origin_ok.
 */
function d9_html_headers(int $status): void
{
    http_response_code($status);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer');
    header("Content-Security-Policy: default-src 'none'; form-action 'self'; frame-ancestors 'none'");
}

function d9_html(string $text): string
{
    return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
