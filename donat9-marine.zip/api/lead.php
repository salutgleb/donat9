<?php
/**
 * DONAT9: адрес для формы заявки на российском хостинге. В config.js сайта: ENDPOINT = '/api/lead.php'.
 *   POST  заявка с сайта, ответ JSON как у Code.gs: {"ok":true,"id":"K7Q2M"} и так далее.
 *   GET   проверка: {"ok":true,"service":"donat9-leads-ru","storage":"ok","mail":"ok","telegram":"relay"}.
 *   GET ?export=csv  страница с полем для ключа; POST ?export=csv с полем key: все заявки таблицей для Excel.
 *   Ключ не ходит в адресе: адрес попадает в историю, закладки, журналы сервера и предпросмотр ссылок.
 * Статус заявки по номеру и его смена: status.php.
 */

declare(strict_types=1);

umask(0077); // заявки, файлы и журнал читает только владелец аккаунта
ini_set('display_errors', '0'); // на случай, если хостинг не применяет .user.ini

require_once __DIR__ . '/store.php';
require_once __DIR__ . '/http.php';

function d9_main(): void
{
    $config = d9_load_config(__DIR__);
    $method = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if ($config === null) {
        d9_json($method === 'POST' ? 200 : 500, ['ok' => false, 'error' => 'server', 'hint' => 'config.php']);
        return;
    }
    d9_cors($config);
    if ($method === 'OPTIONS') {
        header('Access-Control-Allow-Methods: POST, GET');
        http_response_code(204);
        return;
    }
    // Выгрузку защищает ключ. Со своей страницы (Referrer-Policy: no-referrer) браузер шлёт «Origin: null»,
    // явно чужой сайт отвергается до ключа (d9_service_origin_ok).
    if (($_GET['export'] ?? '') === 'csv') {
        if ($method === 'POST' && !d9_service_origin_ok($config)) {
            d9_json(403, ['ok' => false, 'error' => 'forbidden']);
        } elseif ($method === 'POST') {
            d9_export($config, (string) ($_POST['key'] ?? ''), (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        } else {
            d9_export_form();
        }
        return;
    }
    $origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
    if ($method === 'POST' && $origin !== '' && !in_array($origin, (array) $config['allowed_origins'], true)) {
        d9_json(403, ['ok' => false, 'error' => 'forbidden']); // форма на чужом сайте не шлёт заявки чужими браузерами
        return;
    }
    if ($method === 'GET') {
        $storage = d9_storage_state($config, (string) ($_SERVER['DOCUMENT_ROOT'] ?? ''));
        if ($storage !== 'not_writable') {
            d9_cleanup_now($config, time()); // срок хранения соблюдается, даже если новых заявок давно нет
        }
        d9_json(200, [
            'ok' => true,
            'service' => D9_SERVICE,
            'storage' => $storage,
            'mail' => $config['leads_email'] !== '' ? 'ok' : 'not_configured',
            'telegram' => d9_signal_mode($config),
            'ip_limit' => d9_ip_key((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 'probe') !== '' ? 'on' : 'off',
        ]);
        return;
    }
    if ($method !== 'POST') {
        d9_json(405, ['ok' => false, 'error' => 'method']);
        return;
    }
    // Тело больше post_max_size PHP молча выбрасывает целиком: говорим сайту, что дело в файлах.
    if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0 && !$_POST) {
        d9_json(200, ['ok' => false, 'error' => 'validation', 'field' => 'files']);
        return;
    }
    try {
        $result = d9_handle_post($_POST, $config, time(), (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
            (string) ($_SERVER['DOCUMENT_ROOT'] ?? ''));
    } catch (Throwable $error) {
        d9_log($config, 'Заявка не принята: ' . $error->getMessage());
        d9_json(200, ['ok' => false, 'error' => 'server']);
        return;
    }
    d9_json(200, $result['answer']);
    if ($result['after'] === null) {
        return;
    }
    // Ответ уходит посетителю сразу, письмо и сигнал отправляются после. Без FPM ответ уйдёт по окончании.
    ignore_user_abort(true);
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    }
    try {
        ($result['after'])();
    } catch (Throwable $error) {
        d9_log($config, 'Письмо или сигнал не ушли: ' . $error->getMessage());
    }
}

function d9_export_form(): void
{
    d9_html_headers(200);
    echo '<!doctype html><meta charset="utf-8"><meta name="robots" content="noindex"><title>Заявки DONAT9</title>',
        '<form method="post" action="?export=csv"><label>Ключ выгрузки ',
        '<input type="password" name="key" autocomplete="current-password" required></label> ',
        '<button>Скачать таблицу</button></form>';
}

function d9_export(array $config, string $key, string $ip): void
{
    if (!d9_prepare_dir($config)) {
        d9_json(500, ['ok' => false, 'error' => 'server']);
        return;
    }
    $verdict = d9_export_check($config, $key, time(), $ip);
    if ($verdict !== 'ok') {
        d9_json($verdict === 'locked' ? 429 : 403, ['ok' => false, 'error' => $verdict === 'locked' ? 'rate' : 'forbidden']);
        return;
    }
    $records = d9_with_lock($config, static function () use ($config) {
        return d9_read_records($config);
    });
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="donat9-leads.csv"');
    header('Cache-Control: no-store');
    echo d9_export_csv($records);
}

d9_main();
