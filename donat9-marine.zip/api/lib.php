<?php
/**
 * DONAT9: приём заявок на российском хостинге (основной вариант, данные хранятся в России).
 * Правила полей и ответы сайту те же, что в backend/Code.gs: сайту всё равно, какой бэкенд за ENDPOINT.
 * Этот файл: чистые функции и работа с файлами данных. Точка входа: lead.php.
 * Синтаксис PHP 7.4+, без библиотек и без mbstring.
 */

declare(strict_types=1);

const D9_SERVICE = 'donat9-leads-ru';
const D9_KINDS = ['marine' => 'Судовая', 'truck' => 'Грузовая'];
const D9_URGENCY = ['urgent' => 'Срочно', 'normal' => 'Обычный срок', 'quote' => 'Пока узнаю цену'];
const D9_MESSENGERS = ['call' => 'Звонок', 'whatsapp' => 'WhatsApp', 'telegram' => 'Telegram', 'max' => 'Макс'];
const D9_PHONE_MESSENGERS = ['call', 'whatsapp', 'max'];
// Те же подписи с маленькой буквы: для темы письма и сигнала в Telegram (mbstring на хостинге может не быть).
const D9_KIND_WORDS = ['marine' => 'судовая', 'truck' => 'грузовая'];
const D9_URGENCY_WORDS = ['urgent' => 'срочно', 'normal' => 'обычный срок', 'quote' => 'пока узнаёт цену'];
const D9_LIMITS = [
    'partMax' => 1000, 'qtyMax' => 40, 'cityMax' => 100, 'nameMax' => 80, 'companyMax' => 120, 'commentMax' => 1000,
    'pageMax' => 300, 'phoneInputMax' => 32, 'phoneDigitsMin' => 8, 'phoneDigitsMax' => 15, 'emailMax' => 254,
    'fileCountMax' => 5, 'fileBytesMax' => 8388608, 'fileNameMax' => 100, 'filesBytesPerDay' => 209715200,
    'minElapsedMs' => 3000, 'leadsPerContactPerHour' => 3, 'leadsPerHour' => 30, 'leadsPerIpPerHour' => 5,
    'leadsPerDay' => 300, 'fieldBytesMax' => 16384, 'fileNameBytesMax' => 1024, 'exportFailsPerHour' => 10,
    'consentVersionMax' => 40,
    'retentionDaysDefault' => 365,
    // Проверка статуса по номеру. Номеров 32^5, перебор упирается в эти лимиты: 30 в час с адреса (IPv6 по /64),
    // 120 с сети IPv6 /48 (адрес внутри неё меняется свободно), 600 со всех вместе. Когда общий лимит выбран,
    // адрес, который сам за час проверял меньше statusFewPerIp раз, всё равно проходит: чужой поток не закрывает
    // проверку всем клиентам.
    'statusPerIpPerHour' => 30, 'statusPerNetPerHour' => 120, 'statusPerHour' => 600, 'statusFewPerIp' => 5,
    'leadIdInputMax' => 64,
    // Ключи служебных страниц: exportFailsPerHour неверных с адреса и keyFailsPerNetPerHour с сети /48 закрывают
    // страницу этому адресу на час. Общего замка нет: верный ключ с адреса без своих промахов проходит всегда.
    // В журнал не больше keyFailLogsPerHour строк о неверных ключах в час и одна строка о замке.
    'keyFailsPerNetPerHour' => 30, 'keyFailLogsPerHour' => 100,
    // Сколько адресов помнить в одном счётчике state.json: поток с тысяч адресов не раздувает файл.
    'rateKeysMax' => 1000,
];
const D9_FILE_TYPES = [
    'jpg' => ['jpeg', 'image/jpeg'], 'jpeg' => ['jpeg', 'image/jpeg'], 'png' => ['png', 'image/png'],
    'webp' => ['webp', 'image/webp'], 'heic' => ['heic', 'image/heic'], 'heif' => ['heic', 'image/heif'],
    'pdf' => ['pdf', 'application/pdf'],
    'xlsx' => ['zip', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
    'docx' => ['zip', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
    'csv' => ['text', 'text/csv'], 'txt' => ['text', 'text/plain'],
    'mp4' => ['mp4', 'video/mp4'], 'mov' => ['mov', 'video/quicktime'],
];
const D9_SIGNATURES = [
    'jpeg' => [[0, "\xFF\xD8\xFF"]],
    'png' => [[0, "\x89PNG\r\n\x1A\n"]],
    'webp' => [[0, 'RIFF'], [8, 'WEBP']],
    'heic' => [[4, 'ftyp']],
    'pdf' => [[0, '%PDF']],
    'zip' => [[0, "PK\x03\x04"]],
    'ole' => [[0, "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1"]],
];
// ISO BMFF: «ftyp» на 4-м байте, бренд на 8-м. Бренды HEIF значат фото HEIC, остальные видео MP4.
const D9_HEIF_BRANDS = ['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1'];
// QuickTime (.mov): «ftyp» с брендом «qt  » или старый файл без ftyp, который начинается с атома moov, mdat, wide, free.
const D9_QUICKTIME_BRAND = 'qt  ';
const D9_QUICKTIME_ATOMS = ['moov', 'mdat', 'wide', 'free'];
// Видео целиком из атомов: 4 байта размера (big-endian) и 4 знака типа. Чтобы под .mp4 и .mov не прошёл HTML, ZIP
// или программа с подставленными первыми байтами, у первого атома правдоподобный размер (от 8 до конца файла,
// 1 значит 64-битный размер следом), а сразу за ним второй атом известного типа. Смотрим первые 4096 байт, как форма
// (js/lead-core.js): дальше она файл не читает, и правила должны совпадать.
const D9_ATOM_SCAN_BYTES = 4096;
const D9_ATOM_HEADER_BYTES = 8;
const D9_ATOM_LARGE_HEADER_BYTES = 16;
const D9_ATOM_LARGE_SIZE = 1;
const D9_ATOM_TO_END = 0; // атом до конца файла: так бывает у последнего, но не у первого
const D9_FTYP_MIN_BYTES = 16;
const D9_SECOND_ATOMS = ['moov', 'mdat', 'free', 'skip', 'wide', 'uuid', 'meta', 'moof', 'sidx', 'pdin', 'udta', 'pnot'];
const D9_UINT32 = 4294967296;
// Документы с макросами не пропускаем: их присылают незнакомые люди, а открывает Донат.
const D9_MACRO_MARKERS = [
    'ole' => "_\0V\0B\0A\0_\0P\0R\0O\0J\0E\0C\0T\0", // поток _VBA_PROJECT в .doc и .xls
    'zip' => 'vbaProject.bin', // макросы в .docx и .xlsx
];
const D9_ID_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const D9_ID_RE = '/^[A-HJ-NP-Z2-9]{5}$/';
const D9_BOT_TRAP_ID = '00000';
const D9_HOUR = 3600;
// Статусы заявки для окна «Статус заявки» на сайте. Коды и подписи те же, что STATUSES в js/track-core.js
// (проверяет tests/contract.test.mjs); подписи пока образцы, какие статусы показывать, решает Донат.
const D9_STATUSES = [
    'new' => 'Принята', 'in_work' => 'В работе', 'offer' => 'Предложение отправлено', 'paid' => 'Оплачена',
    'transit' => 'В пути', 'russia' => 'На складе в России', 'delivered' => 'Доставлена', 'closed' => 'Закрыта',
];
const D9_STATUS_NEW = 'new';
// Кириллица, похожая на латиницу: номер часто набирают в русской раскладке. Та же таблица в js/track-core.js.
const D9_ID_HOMOGLYPHS = [
    'А' => 'A', 'В' => 'B', 'Е' => 'E', 'К' => 'K', 'М' => 'M', 'Н' => 'H', 'Р' => 'P', 'С' => 'C', 'Т' => 'T', 'У' => 'Y',
    'Х' => 'X', 'а' => 'A', 'в' => 'B', 'е' => 'E', 'к' => 'K', 'м' => 'M', 'н' => 'H', 'р' => 'P', 'с' => 'C', 'т' => 'T',
    'у' => 'Y', 'х' => 'X',
];
// Пробельные символы так же, как \s и trim() в JavaScript, чтобы длины совпадали с формой и Code.gs.
const D9_SPACE = '\s\x{00A0}\x{1680}\x{2000}-\x{200A}\x{2028}\x{2029}\x{202F}\x{205F}\x{3000}\x{FEFF}';
const D9_CONTROL_RE = '/[\x{0000}-\x{0008}\x{000B}\x{000C}\x{000E}-\x{001F}\x{007F}-\x{009F}\x{202A}-\x{202E}\x{2066}-\x{2069}]/u';
// Почта: что-то@домен.зона, зона и кириллицей. Тот же шаблон в js/lead-core.js и Code.gs; пробелы как \s в JavaScript.
const D9_EMAIL_CHARS = '[^' . D9_SPACE . '@<>"\'(),;:\\\\';
const D9_EMAIL_RE = '/^' . D9_EMAIL_CHARS . ']+@' . D9_EMAIL_CHARS . ']+\\.' . D9_EMAIL_CHARS . '.]{2,}$/u';

// ---------- Строки ----------

function d9_str($value): string
{
    if ($value === null || is_array($value)) {
        return '';
    }
    $text = (string) $value;
    return preg_match('//u', $text) === 1 ? $text : ''; // битый UTF-8 считаем пустым
}

/** Длина как .length в JavaScript: символы вне BMP (эмодзи) считаются за два. */
function d9_js_length(string $text): int
{
    return (int) preg_match_all('/./us', $text) + (int) preg_match_all('/[\x{10000}-\x{10FFFF}]/u', $text);
}

function d9_clean_text($value): string
{
    $text = str_replace(["\r\n", "\r"], "\n", d9_str($value));
    $text = preg_replace(D9_CONTROL_RE, '', $text);
    $text = preg_replace("/\n{3,}/", "\n\n", $text);
    return preg_replace('/^[' . D9_SPACE . ']+|[' . D9_SPACE . ']+$/u', '', $text);
}

function d9_clean_line($value): string
{
    return preg_replace('/[' . D9_SPACE . ']+/u', ' ', d9_clean_text($value));
}

/** Обрезает по символам и ставит многоточие, как truncate в Code.gs. */
function d9_truncate(string $text, int $max): string
{
    preg_match_all('/./us', $text, $match);
    $chars = $match[0];
    return count($chars) <= $max ? $text : implode('', array_slice($chars, 0, $max - 1)) . '…';
}

// ---------- Контакты ----------

function d9_normalize_nick($value): string
{
    $nick = preg_replace('~^(?:https?://)?(?:www\.)?(?:t|telegram)\.me/~i', '', d9_clean_line($value));
    return preg_replace('/^@/', '', rtrim($nick, '/'));
}

/** +7XXXXXXXXXX, +<код страны><номер>, '' для пустого поля или null, если это не номер. */
function d9_normalize_phone($value): ?string
{
    $raw = d9_clean_line($value);
    if ($raw === '') {
        return '';
    }
    if (d9_js_length($raw) > D9_LIMITS['phoneInputMax'] || !preg_match('/^\+?[\d\s().\x{2010}-\x{2015}-]+$/u', $raw)) {
        return null;
    }
    $digits = preg_replace('/\D/', '', $raw);
    $plus = $raw[0] === '+';
    $national = null;
    if ($plus) {
        $national = $digits[0] === '7' ? substr($digits, 1) : null;
    } elseif (strlen($digits) === 11 && ($digits[0] === '7' || $digits[0] === '8')) {
        $national = substr($digits, 1);
    } elseif (strlen($digits) === 10 && preg_match('/^[349]\d{9}$/', $digits)) {
        $national = $digits;
    }
    if ($national !== null) {
        return preg_match('/^[3-9]\d{9}$/', $national) ? '+7' . $national : null;
    }
    $count = strlen($digits);
    return ($plus && $count >= D9_LIMITS['phoneDigitsMin'] && $count <= D9_LIMITS['phoneDigitsMax']) ? '+' . $digits : null;
}

function d9_format_phone(string $phone): string
{
    return preg_match('/^\+7(\d{3})(\d{3})(\d{2})(\d{2})$/', $phone, $m) ? "+7 {$m[1]} {$m[2]}-{$m[3]}-{$m[4]}" : $phone;
}

// ---------- Файлы ----------

function d9_safe_file_name($value): string
{
    $clean = preg_replace('/^[.\s_]+/u', '', preg_replace('~[\\\\/:*?"<>|]+~', '_', d9_clean_line($value)));
    preg_match_all('/./us', $clean, $match);
    if (count($match[0]) <= D9_LIMITS['fileNameMax']) {
        return $clean;
    }
    $tail = preg_match('/\.[A-Za-z0-9]{1,5}$/', $clean, $ext) ? $ext[0] : '';
    return implode('', array_slice($match[0], 0, D9_LIMITS['fileNameMax'] - strlen($tail))) . $tail;
}

function d9_file_extension(string $name): string
{
    return preg_match('/\.([A-Za-z0-9]{1,5})$/', $name, $m) ? strtolower($m[1]) : '';
}

function d9_base64_length(string $data): int
{
    if ($data === '' || strlen($data) % 4 !== 0 || !preg_match('~^[A-Za-z0-9+/]*={0,2}$~', $data)) {
        return -1;
    }
    $padding = substr($data, -2) === '==' ? 2 : (substr($data, -1) === '=' ? 1 : 0);
    return intdiv(strlen($data), 4) * 3 - $padding;
}

/** Бренд ISO BMFF (4 знака после «ftyp») или '', если файл начинается не с ftyp. */
function d9_iso_brand(string $bytes): string
{
    return substr($bytes, 4, 4) === 'ftyp' && strlen($bytes) >= 12 ? substr($bytes, 8, 4) : '';
}

/** Атом с этого места: ['size', 'type'] или null, если заголовок не в первых 4096 байтах или размер неправдоподобен. */
function d9_atom_at(string $bytes, int $offset, bool $first): ?array
{
    $fileSize = strlen($bytes);
    $scan = min($fileSize, D9_ATOM_SCAN_BYTES);
    if ($offset + D9_ATOM_HEADER_BYTES > $scan) {
        return null;
    }
    $declared = (int) unpack('N', substr($bytes, $offset, 4))[1];
    $type = substr($bytes, $offset + 4, 4);
    if ($declared === D9_ATOM_LARGE_SIZE) {
        if ($offset + D9_ATOM_LARGE_HEADER_BYTES > $scan) {
            return null;
        }
        $parts = unpack('N2', substr($bytes, $offset + 8, 8));
        $size = $parts[1] * D9_UINT32 + $parts[2]; // float на 32-битном PHP, сравнение от этого не ломается
        return $size >= D9_ATOM_LARGE_HEADER_BYTES && $offset + $size <= $fileSize ? ['size' => (int) $size, 'type' => $type] : null;
    }
    if ($declared === D9_ATOM_TO_END) {
        return $first ? null : ['size' => $fileSize - $offset, 'type' => $type];
    }
    return $declared >= D9_ATOM_HEADER_BYTES && $offset + $declared <= $fileSize ? ['size' => $declared, 'type' => $type] : null;
}

/** Первый атом видео, если и он, и следующий за ним правдоподобны; иначе null. */
function d9_first_video_atom(string $bytes): ?array
{
    $first = d9_atom_at($bytes, 0, true);
    $second = $first !== null ? d9_atom_at($bytes, $first['size'], false) : null;
    return $second !== null && in_array($second['type'], D9_SECOND_ATOMS, true) ? $first : null;
}

function d9_matches_video(string $bytes, string $family): bool
{
    $first = d9_first_video_atom($bytes);
    if ($first === null) {
        return false;
    }
    $brand = $first['type'] === 'ftyp' && $first['size'] >= D9_FTYP_MIN_BYTES ? substr($bytes, 8, 4) : '';
    if ($family === 'mov') {
        return $brand === D9_QUICKTIME_BRAND || in_array($first['type'], D9_QUICKTIME_ATOMS, true);
    }
    return $brand !== '' && !in_array($brand, D9_HEIF_BRANDS, true); // фото HEIC под .mp4 не видео
}

/** Совпадает ли начало файла с его типом: расширение можно подделать. */
function d9_matches_family(string $bytes, string $family): bool
{
    if ($family === 'text') {
        return $bytes !== '' && strpos(substr($bytes, 0, 4096), "\0") === false;
    }
    if ($family === 'mp4' || $family === 'mov') {
        return d9_matches_video($bytes, $family);
    }
    if (!isset(D9_SIGNATURES[$family])) {
        return false;
    }
    foreach (D9_SIGNATURES[$family] as [$offset, $signature]) {
        if (substr($bytes, $offset, strlen($signature)) !== $signature) {
            return false;
        }
    }
    return $family !== 'heic' || in_array(d9_iso_brand($bytes), D9_HEIF_BRANDS, true);
}

/** Части .docx и .xlsx с исполняемым содержимым: макросы, ActiveX, вложенные OLE-объекты. Имена частей в ZIP не сжаты. */
const D9_ZIP_ACTIVE_PARTS = ['vbaproject', 'activex', 'oleobject'];

function d9_has_macros(string $bytes, string $family): bool
{
    if ($family === 'zip') {
        foreach (D9_ZIP_ACTIVE_PARTS as $marker) {
            if (stripos($bytes, $marker) !== false) {
                return true;
            }
        }
        return false;
    }
    return isset(D9_MACRO_MARKERS[$family]) && strpos($bytes, D9_MACRO_MARKERS[$family]) !== false;
}

/** Файлы из поля files (JSON [{name, data}]), уже декодированные и проверенные. [] без файлов, null при ошибке. */
function d9_parse_files($raw): ?array
{
    $text = trim(d9_str($raw));
    if ($text === '') {
        return [];
    }
    $list = json_decode($text, true);
    if (!is_array($list) || array_keys($list) !== range(0, count($list) - 1) || count($list) > D9_LIMITS['fileCountMax']) {
        return $list === [] ? [] : null;
    }
    $files = [];
    $total = 0;
    foreach ($list as $item) {
        if (!is_array($item)) {
            return null;
        }
        if (!is_string($item['name'] ?? null) || strlen($item['name']) > D9_LIMITS['fileNameBytesMax']) {
            return null; // огромное имя съело бы память в d9_safe_file_name
        }
        $name = d9_safe_file_name($item['name']);
        $ext = d9_file_extension($name);
        $data = is_string($item['data'] ?? null) ? $item['data'] : '';
        $size = d9_base64_length($data);
        if ($name === '' || !isset(D9_FILE_TYPES[$ext]) || $size <= 0) {
            return null;
        }
        $total += $size;
        if ($total > D9_LIMITS['fileBytesMax']) {
            return null;
        }
        $bytes = base64_decode($data, true);
        [$family, $mime] = D9_FILE_TYPES[$ext];
        if ($bytes === false || !d9_matches_family($bytes, $family) || d9_has_macros($bytes, $family)) {
            return null;
        }
        $files[] = ['name' => $name, 'mime' => $mime, 'bytes' => $bytes, 'size' => strlen($bytes)];
    }
    return $files;
}

// ---------- Проверка заявки ----------

/**
 * Те же правила, что validateLead в Code.gs: сначала ловушки для ботов, потом поля в порядке формы.
 * @return array ['verdict' => 'ok', 'lead' => [...]] | ['verdict' => 'invalid', 'field' => ...] | ['verdict' => 'bot', 'reason' => ...]
 */
function d9_validate_lead(array $p): array
{
    $invalid = static function (string $field): array {
        return ['verdict' => 'invalid', 'field' => $field];
    };
    foreach ($p as $field => $value) {
        if ($field !== 'files' && is_string($value) && strlen($value) > D9_LIMITS['fieldBytesMax']) {
            return ['verdict' => 'bot', 'reason' => 'too_big']; // форма столько не шлёт, разбор съел бы память
        }
    }
    if (d9_str($p['hp'] ?? '') !== '') {
        return ['verdict' => 'bot', 'reason' => 'honeypot'];
    }
    $elapsed = trim(d9_str($p['elapsed'] ?? ''));
    if (!is_numeric($elapsed) || (float) $elapsed < D9_LIMITS['minElapsedMs']) {
        return ['verdict' => 'bot', 'reason' => 'too_fast'];
    }
    $kind = trim(d9_str($p['kind'] ?? ''));
    if (!isset(D9_KINDS[$kind])) {
        return $invalid('kind');
    }
    $files = d9_parse_files($p['files'] ?? '');
    if ($files === null) {
        return $invalid('files');
    }
    $part = d9_clean_text($p['part'] ?? '');
    if (($part === '' && !$files) || d9_js_length($part) > D9_LIMITS['partMax']) {
        return $invalid('part');
    }
    $qty = d9_clean_line($p['qty'] ?? '');
    if (d9_js_length($qty) > D9_LIMITS['qtyMax']) {
        return $invalid('qty');
    }
    $city = d9_clean_line($p['city'] ?? '');
    if (d9_js_length($city) > D9_LIMITS['cityMax']) {
        return $invalid('city');
    }
    $urgency = trim(d9_str($p['urgency'] ?? ''));
    if ($urgency !== '' && !isset(D9_URGENCY[$urgency])) {
        return $invalid('urgency');
    }
    $name = d9_clean_line($p['name'] ?? '');
    if ($name === '' || d9_js_length($name) > D9_LIMITS['nameMax']) {
        return $invalid('name');
    }
    $phone = d9_normalize_phone($p['phone'] ?? '');
    if ($phone === null) {
        return $invalid('phone');
    }
    $telegram = d9_normalize_nick($p['telegram'] ?? '');
    if ($telegram !== '' && !preg_match('/^[A-Za-z0-9_]{5,32}$/', $telegram)) {
        return $invalid('telegram');
    }
    $email = d9_clean_line($p['email'] ?? '');
    if ($email !== '' && (d9_js_length($email) > D9_LIMITS['emailMax'] || !preg_match(D9_EMAIL_RE, $email))) {
        return $invalid('email');
    }
    if ($phone === '' && $telegram === '' && $email === '') {
        return $invalid('contact');
    }
    $messenger = trim(d9_str($p['messenger'] ?? ''));
    if ($messenger !== '' && !isset(D9_MESSENGERS[$messenger])) {
        return $invalid('messenger');
    }
    if ($phone === '' && in_array($messenger, D9_PHONE_MESSENGERS, true)) {
        return $invalid('phone');
    }
    $company = d9_clean_line($p['company'] ?? '');
    if (d9_js_length($company) > D9_LIMITS['companyMax']) {
        return $invalid('company');
    }
    $comment = d9_clean_text($p['comment'] ?? '');
    if (d9_js_length($comment) > D9_LIMITS['commentMax']) {
        return $invalid('comment');
    }
    if (!in_array(d9_str($p['consent'] ?? ''), ['1', 'on'], true)) {
        return $invalid('consent');
    }
    return ['verdict' => 'ok', 'lead' => [
        'kind' => $kind, 'part' => $part, 'qty' => $qty, 'city' => $city, 'urgency' => $urgency, 'name' => $name,
        'phone' => $phone, 'telegram' => $telegram, 'email' => $email, 'messenger' => $messenger, 'company' => $company,
        'comment' => $comment,
        'page' => d9_truncate(d9_clean_line($p['page'] ?? ''), D9_LIMITS['pageMax']),
        'consent_version' => d9_consent_version($p['consent_version'] ?? ''),
        'files' => $files,
    ]];
}

/** Версия текста согласия для журнала: «2026-11-05» и подобное, остальное пустой строкой. */
function d9_consent_version($value): string
{
    $text = d9_clean_line($value);
    return preg_match('/^[\w.-]{1,40}$/', $text) ? $text : '';
}

// ---------- Номера, лимиты, ответы ----------

function d9_make_id(array $taken): string
{
    for ($attempt = 0; $attempt < 10; $attempt++) {
        $id = '';
        for ($i = 0; $i < 5; $i++) {
            $id .= D9_ID_ALPHABET[random_int(0, strlen(D9_ID_ALPHABET) - 1)];
        }
        if (!isset($taken[$id])) {
            return $id;
        }
    }
    throw new RuntimeException('Не удалось подобрать свободный номер заявки');
}

/** Отметки времени из последнего окна; мусор и отметки из будущего выбрасываются. */
function d9_recent(array $stamps, int $now, int $window): array
{
    return array_values(array_filter($stamps, static function ($stamp) use ($now, $window) {
        return is_int($stamp) && $stamp <= $now && $now - $stamp < $window;
    }));
}

/** Скользящее окно: не больше $limit отметок за $window секунд. */
function d9_check_rate(array $stamps, int $now, int $limit, int $window): array
{
    $recent = d9_recent($stamps, $now, $window);
    return count($recent) >= $limit ? ['allowed' => false, 'stamps' => $recent] : ['allowed' => true, 'stamps' => array_merge($recent, [$now])];
}

/**
 * Ключ лимита по адресу посетителя: хеш IP с солью этой установки, сам адрес не хранится.
 * Пусто для локальных и служебных адресов: за прокси хостинга у всех был бы один адрес, и лимит
 * по нему отрезал бы всех клиентов разом.
 */
function d9_ip_key(string $ip, string $salt): string
{
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        return '';
    }
    $packed = (string) inet_pton($ip);
    // У одного абонента IPv6 обычно целая сеть /64: лимит по отдельному адресу обходится сменой адреса.
    $scope = strlen($packed) === 16 ? substr($packed, 0, 8) : $packed;
    return 'ip:' . substr(hash('sha256', $salt . '|' . bin2hex($scope)), 0, 32);
}

/** Ключ сети IPv6 /48 для лимитов статуса и ключей ('' для IPv4 и служебных); заявки считаются по d9_ip_key, как раньше. */
function d9_net_key(string $ip, string $salt): string
{
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        return '';
    }
    return 'net:' . substr(hash('sha256', $salt . '|48|' . bin2hex(substr((string) inet_pton($ip), 0, 6))), 0, 32);
}

// Служебные ключи счётчиков: не адреса, при обрезке по rateKeysMax не выбрасываются.
const D9_RATE_RESERVED = ['all', 'log'];

/**
 * Счётчик без отметок старше часа и не больше rateKeysMax адресов: остаются те, у кого отметки свежее.
 * Служебные ключи 'all' и 'log' остаются всегда.
 */
function d9_prune_stamps(array $map, int $now): array
{
    $fresh = array_filter(array_map(static function ($stamps) use ($now) {
        return d9_recent(is_array($stamps) ? $stamps : [], $now, D9_HOUR);
    }, $map));
    $reserved = array_intersect_key($fresh, array_flip(D9_RATE_RESERVED));
    $addresses = array_diff_key($fresh, $reserved);
    if (count($addresses) <= D9_LIMITS['rateKeysMax']) {
        return $fresh;
    }
    uasort($addresses, static function ($a, $b) {
        return max($b) <=> max($a);
    });
    return array_merge(array_slice($addresses, 0, D9_LIMITS['rateKeysMax'], true), $reserved);
}

/** Ключ для лимита заявок: телефон, без телефона ник, без ника почта; ник и почта без учёта регистра. */
function d9_contact_key(array $lead): string
{
    if ($lead['phone'] !== '') {
        return 'phone:' . $lead['phone'];
    }
    if ($lead['telegram'] !== '') {
        return 'tg:' . strtolower($lead['telegram']);
    }
    return 'mail:' . strtolower((string) ($lead['email'] ?? ''));
}

function d9_site_answer(string $id, string $filesStatus): array
{
    return $filesStatus !== '' ? ['ok' => true, 'id' => $id, 'files' => $filesStatus] : ['ok' => true, 'id' => $id];
}

// ---------- Письмо и сигнал ----------

function d9_lead_lines(array $lead): array
{
    $lines = [
        'Заявка ' . $lead['id'] . ' с сайта DONAT9, ' . $lead['created_at'],
        'Тип: ' . D9_KINDS[$lead['kind']] . ($lead['urgency'] !== '' ? ', ' . D9_URGENCY[$lead['urgency']] : ''),
        'Нужно: ' . ($lead['part'] !== '' ? $lead['part'] : 'по фото'),
        $lead['qty'] !== '' ? 'Количество: ' . $lead['qty'] : null,
        $lead['city'] !== '' ? 'Куда: ' . $lead['city'] : null,
        'Имя: ' . $lead['name'],
        $lead['company'] !== '' ? 'Компания: ' . $lead['company'] : null,
        $lead['phone'] !== '' ? 'Телефон: ' . d9_format_phone($lead['phone']) . ', WhatsApp: https://wa.me/' . substr($lead['phone'], 1) : null,
        $lead['telegram'] !== '' ? 'Telegram: https://t.me/' . $lead['telegram'] : null,
        ($lead['email'] ?? '') !== '' ? 'Почта: ' . $lead['email'] : null,
        $lead['messenger'] !== '' ? 'Удобнее: ' . D9_MESSENGERS[$lead['messenger']] : null,
        $lead['comment'] !== '' ? "Комментарий:\n" . $lead['comment'] : null,
        $lead['file_names'] ? 'Файлы во вложении: ' . implode(', ', $lead['file_names']) : null,
        $lead['files_status'] === 'failed' ? 'Файлы не сохранились: попроси клиента прислать их в мессенджер.' : null,
        $lead['files_status'] === 'skipped' ? 'Файлы не приняты: дневной лимит. Попроси клиента прислать их в мессенджер.' : null,
        $lead['page'] !== '' ? 'Страница: ' . $lead['page'] : null,
        'Согласие на обработку данных: дано, версия текста ' . ($lead['consent_version'] !== '' ? $lead['consent_version'] : 'не указана'),
    ];
    return array_values(array_filter($lines, static function ($line) {
        return $line !== null;
    }));
}

function d9_mime_header(string $text): string
{
    return '=?UTF-8?B?' . base64_encode($text) . '?=';
}

/**
 * Письмо с заявкой и файлами во вложении. Возвращает [subject, body, headers] для mail().
 * Тема и имена файлов в кодировке MIME: русские буквы доходят до любой почты.
 */
function d9_build_email(array $lead, array $files, string $from, string $boundary): array
{
    $subject = d9_mime_header('Заявка ' . $lead['id'] . ': ' . D9_KIND_WORDS[$lead['kind']] . ', ' .
        d9_truncate(explode("\n", $lead['part'] !== '' ? $lead['part'] : 'по фото')[0], 60));
    $text = implode("\n", d9_lead_lines($lead)) . "\n";
    $email = (string) ($lead['email'] ?? '');
    // «Ответить» в почте сразу пишет клиенту. Только латиница: адрес кириллицей в заголовке не дойдёт без SMTPUTF8.
    $replyTo = preg_match('/^[\x21-\x7E]+$/', $email) ? ['Reply-To: ' . $email] : [];
    $headers = implode("\r\n", array_merge([
        'From: ' . d9_mime_header('Сайт DONAT9') . ' <' . $from . '>',
    ], $replyTo, [
        'MIME-Version: 1.0',
        'Content-Type: multipart/mixed; boundary="' . $boundary . '"',
    ]));
    $parts = ["--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" .
        chunk_split(base64_encode($text))];
    foreach ($files as $index => $file) {
        $name = d9_mime_header(($index + 1) . '-' . $file['name']);
        $parts[] = "--{$boundary}\r\nContent-Type: {$file['mime']}; name=\"{$name}\"\r\nContent-Transfer-Encoding: base64\r\n" .
            "Content-Disposition: attachment; filename=\"{$name}\"\r\n\r\n" . chunk_split(base64_encode($file['bytes']));
    }
    return [$subject, implode('', $parts) . "--{$boundary}--\r\n", $headers];
}

/** Сигнал в Telegram без персональных данных: номер, тип, срочность и сколько файлов. Подробности в почте. */
function d9_signal_text(array $lead): string
{
    $kind = D9_KIND_WORDS[$lead['kind']];
    $urgency = $lead['urgency'] !== '' ? ', ' . D9_URGENCY_WORDS[$lead['urgency']] : '';
    $files = $lead['file_names'] ? ', файлов: ' . count($lead['file_names']) : '';
    return 'Новая заявка ' . $lead['id'] . ': ' . $kind . $urgency . $files . '. Подробности в почте.';
}

// ---------- Таблица для Excel ----------

/** Ячейка CSV: формулы и номера не превращаются в вычисления, кавычки удваиваются. */
function d9_csv_cell(string $value): string
{
    $safe = preg_match('/^[=+\-@\t\r]/', $value) ? "'" . $value : $value;
    return '"' . str_replace('"', '""', $safe) . '"';
}

const D9_EXPORT_COLUMNS = ['id', 'created_at', 'kind', 'part', 'qty', 'city', 'urgency', 'name', 'phone', 'telegram', 'email',
    'messenger', 'company', 'comment', 'files', 'page', 'consent_version', 'status', 'status_at'];

/** Все заявки одной таблицей: точка с запятой и BOM, чтобы русский Excel открыл файл без мастера импорта. */
function d9_export_csv(array $records): string
{
    $rows = [implode(';', array_map('d9_csv_cell', D9_EXPORT_COLUMNS))];
    foreach ($records as $record) {
        $rows[] = implode(';', array_map(static function ($column) use ($record) {
            $value = $record[$column] ?? '';
            return d9_csv_cell(is_array($value) ? implode(', ', $value) : (string) $value);
        }, D9_EXPORT_COLUMNS));
    }
    return "\xEF\xBB\xBF" . implode("\r\n", $rows) . "\r\n";
}

// ---------- Срок хранения ----------

function d9_retention_days($value): int
{
    $text = trim((string) $value);
    if ($text === '') {
        return D9_LIMITS['retentionDaysDefault'];
    }
    return preg_match('/^\d{1,5}$/', $text) ? (int) $text : D9_LIMITS['retentionDaysDefault'];
}

/** Делит записи на свежие и старше $days дней. Запись без понятной даты остаётся. */
function d9_split_old(array $records, int $now, int $days): array
{
    if ($days <= 0) {
        return [$records, []];
    }
    $keep = [];
    $old = [];
    foreach ($records as $record) {
        $time = strtotime((string) ($record['created_at'] ?? ''));
        if ($time !== false && $time < $now - $days * 86400) {
            $old[] = $record;
        } else {
            $keep[] = $record;
        }
    }
    return [$keep, $old];
}

// ---------- Статус заявки ----------

/** Номер заявки из ввода: без пробелов, «№» и «#», заглавными, кириллица-двойник латиницей; '' если не номер. */
function d9_normalize_lead_id($value): string
{
    $text = d9_str($value);
    if ($text === '' || strlen($text) > D9_LIMITS['leadIdInputMax']) {
        return '';
    }
    $compact = (string) preg_replace('/[' . D9_SPACE . '№#]+/u', '', $text);
    $latin = strtoupper(strtr($compact, D9_ID_HOMOGLYPHS));
    return preg_match(D9_ID_RE, $latin) ? $latin : '';
}

/** Время в записи заявки: «2026-11-11T16:05:00+03:00», по Москве, как created_at. */
function d9_moscow_stamp(int $now): string
{
    return gmdate('Y-m-d\TH:i:s', $now + 3 * 3600) . '+03:00';
}

/** Статус и дата его смены из записи. У заявок, принятых до статусов, статус «new» с датой заявки. */
function d9_record_status(array $record): array
{
    $status = (string) ($record['status'] ?? '');
    $known = isset(D9_STATUSES[$status]);
    $stamp = (string) ($known ? ($record['status_at'] ?? '') : ($record['created_at'] ?? ''));
    $date = preg_match('/^\d{4}-\d{2}-\d{2}/', $stamp, $match) ? $match[0] : '';
    return ['status' => $known ? $status : D9_STATUS_NEW, 'updated' => $date];
}

/** Ответ окну по записи: только номер, статус и дата. Ни имени, ни контактов, ни текста заявки. */
function d9_status_answer(?array $record): array
{
    if ($record === null) {
        return ['ok' => false, 'error' => 'not_found'];
    }
    $status = d9_record_status($record);
    return ['ok' => true, 'id' => (string) $record['id'], 'status' => $status['status'], 'updated' => $status['updated']];
}

/** Запись с этим номером, если она не старше срока хранения (чистка раз в сутки может ещё не пройти). */
function d9_find_record(array $records, string $id, int $now, int $days): ?array
{
    [$fresh] = d9_split_old($records, $now, $days);
    foreach ($fresh as $record) {
        if (($record['id'] ?? '') === $id) {
            return $record;
        }
    }
    return null;
}

/** Запись заявки из строки leads.jsonl или null, если строку не разобрать. */
function d9_parse_line(string $line): ?array
{
    $record = json_decode($line, true);
    return is_array($record) && isset($record['id']) ? $record : null;
}

/** Записи из строк leads.jsonl; строки, которые не разобрать, пропускаются. */
function d9_records_of(array $lines): array
{
    return array_values(array_filter(array_map('d9_parse_line', $lines)));
}

/**
 * Строки leads.jsonl со сменённым статусом одной заявки или null, если такой заявки нет. Остальные строки,
 * в том числе те, что не разобрать, остаются байт в байт: перезапись ничего не теряет. Вход не меняется.
 */
function d9_lines_with_status(array $lines, string $id, string $status, int $now): ?array
{
    $hit = static function (string $line) use ($id): bool {
        $record = d9_parse_line($line);
        return $record !== null && $record['id'] === $id;
    };
    if (!array_filter($lines, $hit)) {
        return null;
    }
    return array_map(static function (string $line) use ($hit, $status, $now) {
        return $hit($line) ? (string) json_encode(array_merge(d9_parse_line($line), ['status' => $status,
            'status_at' => d9_moscow_stamp($now)]), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $line;
    }, $lines);
}

/** Строки leads.jsonl без заявок с этими номерами; строки, которые не разобрать, остаются как есть. */
function d9_lines_without(array $lines, array $ids): array
{
    $drop = array_flip($ids);
    return array_values(array_filter($lines, static function (string $line) use ($drop) {
        $record = d9_parse_line($line);
        return $record === null || !isset($drop[(string) $record['id']]);
    }));
}

/**
 * Лимит проверок статуса (D9_LIMITS, statusPer…): адрес, сеть IPv6 /48 и все вместе. Когда общий лимит выбран,
 * адрес с меньше чем statusFewPerIp своими проверками за час проходит; неизвестный адрес ($ipKey '') нет.
 * $rate: отметки по ключам 'all', адресов и сетей. Возвращает ['allowed' => bool, 'rate' => новые отметки без старых].
 */
function d9_status_limit(array $rate, string $ipKey, string $netKey, int $now): array
{
    $fresh = d9_prune_stamps($rate, $now);
    $own = $ipKey !== '' ? ($fresh[$ipKey] ?? []) : null;
    $net = $netKey !== '' ? ($fresh[$netKey] ?? []) : [];
    $all = $fresh['all'] ?? [];
    $globalFull = count($all) >= D9_LIMITS['statusPerHour'];
    $fewOwn = $own !== null && count($own) < D9_LIMITS['statusFewPerIp'];
    $allowed = ($own === null || count($own) < D9_LIMITS['statusPerIpPerHour'])
        && count($net) < D9_LIMITS['statusPerNetPerHour']
        && (!$globalFull || $fewOwn);
    if (!$allowed) {
        return ['allowed' => false, 'rate' => $fresh];
    }
    return ['allowed' => true, 'rate' => array_merge($fresh,
        $globalFull ? [] : ['all' => array_merge($all, [$now])],
        $own !== null ? [$ipKey => array_merge($own, [$now])] : [],
        $netKey !== '' ? [$netKey => array_merge($net, [$now])] : [])];
}

/** Закрыта ли служебная страница этому адресу: свои промахи за час или промахи его сети /48. */
function d9_key_locked(array $fails, string $ipKey, string $netKey): bool
{
    return count($fails[$ipKey] ?? []) >= D9_LIMITS['exportFailsPerHour']
        || ($netKey !== '' && count($fails[$netKey] ?? []) >= D9_LIMITS['keyFailsPerNetPerHour']);
}

/**
 * Неверный ключ: отметка адресу и сети, и писать ли в журнал. 'line' обычная строка, 'last' последняя за час
 * (keyFailLogsPerHour), 'none' журнал за этот час уже полон.
 * @return array ['fails' => новые отметки, 'log' => 'line'|'last'|'none']
 */
function d9_key_miss(array $fails, string $ipKey, string $netKey, int $now): array
{
    $logged = $fails['log'] ?? [];
    $room = D9_LIMITS['keyFailLogsPerHour'] - count($logged);
    $next = array_merge($fails, [$ipKey => array_merge($fails[$ipKey] ?? [], [$now])],
        $netKey !== '' ? [$netKey => array_merge($fails[$netKey] ?? [], [$now])] : [],
        $room > 0 ? ['log' => array_merge($logged, [$now])] : []);
    return ['fails' => $next, 'log' => $room <= 0 ? 'none' : ($room === 1 ? 'last' : 'line')];
}
