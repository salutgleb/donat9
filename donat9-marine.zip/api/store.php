<?php
/**
 * DONAT9: хранение заявок на российском хостинге, письмо и сигнал в Telegram, статус заявки.
 * Заявки лежат в папке данных вне папки сайта: leads.jsonl (по строке на заявку, статус и дата его смены
 * в полях status и status_at той же строки), files/<номер>/, state.json (лимиты), errors.log.
 * Все записи под файловой блокировкой.
 */

declare(strict_types=1);

require_once __DIR__ . '/lib.php';

const D9_DEFAULT_CONFIG = [
    'leads_email' => '',
    'mail_from' => 'no-reply@donat9.com',
    'mail_transport' => 'mail',
    'telegram_bot_token' => '',
    'telegram_chat_id' => '',
    'signal_relay_url' => '',
    'signal_relay_key' => '',
    'allowed_origins' => ['https://donat9.com', 'https://www.donat9.com'],
    'data_dir' => '',
    'export_key' => '',
    'status_key' => '',
    'retention_days' => 365,
];

// Проверка ключей служебных страниц: что брать из настроек, где считать неверные попытки и что писать в журнал.
const D9_EXPORT_KEY = ['config' => 'export_key', 'fails' => 'export_fails', 'locked' => 'Выгрузка заявок закрыта на час: много неверных ключей',
    'denied' => 'Выгрузка заявок: неверный ключ', 'granted' => 'Выгрузка заявок скачана'];
const D9_STATUS_KEY = ['config' => 'status_key', 'fails' => 'status_fails', 'locked' => 'Смена статусов закрыта на час: много неверных ключей',
    'denied' => 'Смена статуса: неверный ключ', 'granted' => ''];
const D9_KEY_LOG_FULL = '. Дальше неверные ключи за этот час в журнал не пишутся';

/** Настройки из config.php поверх значений по умолчанию; null, если config.php нет. */
function d9_load_config(string $dir): ?array
{
    $outside = dirname($dir, 2) . '/donat9-config.php'; // вне папки сайта: веб-сервер его не отдаст ни при каких настройках
    $file = is_file($outside) ? $outside : $dir . '/config.php';
    if (!is_file($file)) {
        return null;
    }
    $custom = require $file;
    if (!is_array($custom)) {
        return null;
    }
    $config = array_merge(D9_DEFAULT_CONFIG, $custom);
    $config['data_dir'] = $config['data_dir'] !== '' ? rtrim((string) $config['data_dir'], '/') : dirname($dir, 2) . '/donat9-leads';
    $config['retention_days'] = d9_retention_days($config['retention_days']);
    return $config;
}

function d9_log(array $config, string $message): void
{
    $token = (string) $config['telegram_bot_token'];
    $safe = $token !== '' ? str_replace($token, '***', $message) : $message;
    @file_put_contents($config['data_dir'] . '/errors.log', date('c') . ' ' . $safe . "\n", FILE_APPEND | LOCK_EX);
}

/** Создаёт папку данных и закрывает её от веба на случай, если её всё-таки положили внутрь сайта. */
function d9_prepare_dir(array $config): bool
{
    $dir = $config['data_dir'];
    if (!is_dir($dir) && !@mkdir($dir, 0700, true)) {
        return false;
    }
    @chmod($dir, 0700);
    if (!is_file($dir . '/.htaccess')) {
        @file_put_contents($dir . '/.htaccess', "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n" .
            "<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n");
    }
    return is_writable($dir);
}

/** Где лежат данные: 'ok', 'not_writable' или 'public' (папка внутри сайта, её могут скачать). */
function d9_storage_state(array $config, string $documentRoot): string
{
    if (!d9_prepare_dir($config)) {
        return 'not_writable';
    }
    $data = realpath($config['data_dir']);
    $root = $documentRoot !== '' ? realpath($documentRoot) : false;
    if ($data !== false && $root !== false && strpos($data . '/', rtrim($root, '/') . '/') === 0) {
        return 'public';
    }
    return 'ok';
}

function d9_with_lock(array $config, callable $fn)
{
    $handle = fopen($config['data_dir'] . '/.lock', 'c');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        throw new RuntimeException('Нет блокировки папки данных');
    }
    try {
        return $fn();
    } finally {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
}

function d9_read_state(array $config): array
{
    $raw = @file_get_contents($config['data_dir'] . '/state.json');
    $state = $raw ? json_decode($raw, true) : null;
    return is_array($state) ? $state : [];
}

/** Пишет файл целиком через временный и переименование: сбой записи не оставит пустой файл. */
function d9_write_atomic(string $file, string $contents): void
{
    $temp = $file . '.tmp';
    if (file_put_contents($temp, $contents, LOCK_EX) === false || !rename($temp, $file)) {
        @unlink($temp);
        throw new RuntimeException('Не удалось записать ' . basename($file) . ': место на диске или права');
    }
}

function d9_write_state(array $config, array $state): void
{
    d9_write_atomic($config['data_dir'] . '/state.json', (string) json_encode($state));
}

/** Строки leads.jsonl как есть, без пустых. */
function d9_read_lines(array $config): array
{
    $file = $config['data_dir'] . '/leads.jsonl';
    if (!is_file($file)) {
        return [];
    }
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        throw new RuntimeException('Не удалось прочитать leads.jsonl: права на файл');
    }
    return $lines;
}

/** Все заявки из leads.jsonl; испорченные строки пропускаются (при перезаписи они остаются как есть). */
function d9_read_records(array $config): array
{
    return d9_records_of(d9_read_lines($config));
}

/** Перезапись leads.jsonl целиком через временный файл: строки, которые не разобрать, передаются сюда как есть. */
function d9_write_lines(array $config, array $lines): void
{
    d9_write_atomic($config['data_dir'] . '/leads.jsonl', $lines ? implode("\n", $lines) . "\n" : '');
}

function d9_remove_dir(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }
    foreach (scandir($dir) ?: [] as $name) {
        if ($name !== '.' && $name !== '..') {
            @unlink($dir . '/' . $name);
        }
    }
    @rmdir($dir);
}

/** Раз в сутки удаляет заявки старше retention_days и их файлы. Вызывать под блокировкой. */
function d9_cleanup(array $config, array $state, int $now): array
{
    $today = gmdate('Y-m-d', $now + 3 * 3600);
    if (($state['cleanup_day'] ?? '') === $today) {
        return $state;
    }
    $lines = d9_read_lines($config);
    [, $old] = d9_split_old(d9_records_of($lines), $now, (int) $config['retention_days']);
    if ($old) {
        d9_write_lines($config, d9_lines_without($lines, array_column($old, 'id')));
        foreach ($old as $record) {
            d9_remove_dir($config['data_dir'] . '/files/' . $record['id']);
            @unlink($config['data_dir'] . '/outbox/' . $record['id'] . '.eml');
        }
    }
    return array_merge($state, ['cleanup_day' => $today]);
}

function d9_save_files(array $config, string $id, array $files): array
{
    $dir = $config['data_dir'] . '/files/' . $id;
    if (!@mkdir($dir, 0700, true) && !is_dir($dir)) {
        return [];
    }
    $names = [];
    foreach ($files as $index => $file) {
        $stored = ($index + 1) . '.' . d9_file_extension($file['name']); // «1.jpg»: без имени клиента и двойных расширений
        if (@file_put_contents($dir . '/' . $stored, $file['bytes'], LOCK_EX) === false) {
            return [];
        }
        $names[] = ($index + 1) . '-' . $file['name'];
    }
    return $names;
}

/** Счётчики лимитов без устаревших отметок: метки адресов старше часа исчезают из state.json. */
function d9_prune_rate(array $state, int $now): array
{
    $rate = array_filter(array_map(static function ($stamps) use ($now) {
        return d9_recent(is_array($stamps) ? $stamps : [], $now, D9_HOUR);
    }, is_array($state['rate'] ?? null) ? $state['rate'] : []));
    return array_merge($state, ['rate' => $rate]);
}

/** Чистка по сроку хранения и устаревших счётчиков под блокировкой: её запускает и заявка, и проверка lead.php. */
function d9_cleanup_now(array $config, int $now): void
{
    d9_with_lock($config, static function () use ($config, $now) {
        d9_write_state($config, d9_prune_rate(d9_cleanup($config, d9_read_state($config), $now), $now));
    });
}

/** Соль для хешей адресов из state.json; у новой установки новая случайная. */
function d9_state_salt(array $state): string
{
    return isset($state['salt']) && is_string($state['salt']) ? $state['salt'] : bin2hex(random_bytes(16));
}

/**
 * Запись заявки под блокировкой: лимиты (контакт, адрес посетителя, все вместе), номер, файлы,
 * строка в leads.jsonl. null, если превышен лимит.
 */
function d9_store_lead(array $config, array $fields, int $now, string $ip = ''): ?array
{
    return d9_with_lock($config, static function () use ($config, $fields, $now, $ip) {
        $state = d9_cleanup($config, d9_read_state($config), $now);
        $salt = d9_state_salt($state);
        $state = array_merge($state, ['salt' => $salt]);
        $rate = $state['rate'] ?? [];
        $key = d9_contact_key($fields);
        $ipKey = d9_ip_key($ip, $salt);
        $day = gmdate('Y-m-d', $now + 3 * 3600);
        $leadsToday = ($state['leads_day']['day'] ?? '') === $day ? (int) ($state['leads_day']['count'] ?? 0) : 0;
        $byContact = d9_check_rate($rate[$key] ?? [], $now, D9_LIMITS['leadsPerContactPerHour'], D9_HOUR);
        $byIp = $ipKey !== '' ? d9_check_rate($rate[$ipKey] ?? [], $now, D9_LIMITS['leadsPerIpPerHour'], D9_HOUR) : null;
        // Сверх leadsPerHour заявка всё равно принимается, только без файлов: общий лимит не отрезает всех клиентов.
        $overall = d9_check_rate($rate['all'] ?? [], $now, D9_LIMITS['leadsPerHour'], D9_HOUR);
        if (!$byContact['allowed'] || ($byIp !== null && !$byIp['allowed']) || $leadsToday >= D9_LIMITS['leadsPerDay']) {
            d9_write_state($config, $state);
            return null;
        }
        $taken = array_fill_keys(array_column(d9_read_records($config), 'id'), true);
        $id = d9_make_id($taken);
        $files = $fields['files'];
        $bytes = array_sum(array_column($files, 'size'));
        $quota = ($state['quota']['day'] ?? '') === $day ? (int) ($state['quota']['bytes'] ?? 0) : 0;
        $filesAllowed = $files && $overall['allowed'] && $quota + $bytes <= D9_LIMITS['filesBytesPerDay'];
        $names = $filesAllowed ? d9_save_files($config, $id, $files) : [];
        $filesStatus = !$files ? '' : (!$filesAllowed ? 'skipped' : ($names ? 'saved' : 'failed'));
        $record = array_merge(array_diff_key($fields, ['files' => true]), [
            'id' => $id,
            'created_at' => d9_moscow_stamp($now),
            'files' => $names,
            'files_status' => $filesStatus,
            'consent_at' => d9_moscow_stamp($now),
            'status' => D9_STATUS_NEW, // окно «Статус заявки» на сайте; меняет Донат на status.php?edit=1
            'status_at' => d9_moscow_stamp($now),
        ]);
        $line = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
        if (file_put_contents($config['data_dir'] . '/leads.jsonl', $line, FILE_APPEND | LOCK_EX) === false) {
            d9_remove_dir($config['data_dir'] . '/files/' . $id);
            throw new RuntimeException('Заявка не записалась: место на диске или права');
        }
        $fresh = array_filter(array_map(static function ($stamps) use ($now) {
            return d9_recent(is_array($stamps) ? $stamps : [], $now, D9_HOUR);
        }, $rate)); // старые контакты выпадают, файл состояния не растёт
        $rate = array_merge($fresh, [$key => $byContact['stamps'], 'all' => $overall['stamps']],
            $byIp !== null ? [$ipKey => $byIp['stamps']] : []);
        $state = array_merge($state, ['rate' => $rate, 'leads_day' => ['day' => $day, 'count' => $leadsToday + 1]],
            $filesStatus === 'saved' ? ['quota' => ['day' => $day, 'bytes' => $quota + $bytes]] : []);
        d9_write_state($config, $state);
        return ['record' => $record, 'files' => $filesStatus === 'saved' ? $files : []];
    });
}

/**
 * Проверка ключа служебной страницы под блокировкой. Неверные ключи считаются по адресу (exportFailsPerHour)
 * и по сети IPv6 /48 (keyFailsPerNetPerHour): закрывается только этот адрес, общего замка нет, верный ключ
 * с адреса без своих промахов проходит. Журнал не растёт без предела: не больше keyFailLogsPerHour строк
 * о неверных ключах в час и одна строка о замке в час. Ключа в журнале нет.
 * @param array $spec D9_EXPORT_KEY или D9_STATUS_KEY
 * @return string 'ok', 'denied' или 'locked'
 */
function d9_key_check(array $config, array $spec, string $key, int $now, string $ip): string
{
    return d9_with_lock($config, static function () use ($config, $spec, $key, $now, $ip) {
        $state = d9_read_state($config);
        $salt = d9_state_salt($state);
        $ipKey = d9_ip_key($ip, $salt);
        $netKey = d9_net_key($ip, $salt);
        $fails = d9_prune_stamps(is_array($state[$spec['fails']] ?? null) ? $state[$spec['fails']] : [], $now);
        if (d9_key_locked($fails, $ipKey, $netKey)) {
            d9_note_lock($config, $state, $spec, $now);
            return 'locked';
        }
        $expected = (string) $config[$spec['config']];
        if (d9_export_key_strong($expected) && hash_equals($expected, $key)) {
            if ($spec['granted'] !== '') {
                d9_log($config, $spec['granted']);
            }
            return 'ok';
        }
        $miss = d9_key_miss($fails, $ipKey, $netKey, $now);
        d9_write_state($config, array_merge($state, ['salt' => $salt, $spec['fails'] => $miss['fails']]));
        if ($miss['log'] !== 'none') {
            d9_log($config, $spec['denied'] . ($miss['log'] === 'last' ? D9_KEY_LOG_FULL : ''));
        }
        return 'denied';
    });
}

/**
 * Состояние с новой меткой журнала, если по этой метке за последний час не писали; иначе null.
 * Для строк, которые может вызвать любой посетитель: поток запросов не раздувает errors.log.
 */
function d9_log_mark(array $state, string $mark, int $now): ?array
{
    $marks = is_array($state['log_marks'] ?? null) ? $state['log_marks'] : [];
    if ($now - (int) ($marks[$mark] ?? 0) < D9_HOUR) {
        return null;
    }
    return array_merge($state, ['log_marks' => array_merge($marks, [$mark => $now])]);
}

/** Строка о замке служебной страницы, не чаще раза в час. Вызывать под блокировкой. */
function d9_note_lock(array $config, array $state, array $spec, int $now): void
{
    $next = d9_log_mark($state, $spec['fails'], $now);
    if ($next === null) {
        return;
    }
    d9_write_state($config, $next);
    d9_log($config, $spec['locked']);
}

/**
 * Строка в журнал не чаще раза в час для этой метки, со своей блокировкой. Если папка данных недоступна,
 * писать некуда: d9_log и так молчит, а ответ посетителю уже сказал «server».
 */
function d9_log_hourly(array $config, string $mark, string $message, int $now): void
{
    if (!is_dir($config['data_dir']) || !is_writable($config['data_dir'])) {
        return;
    }
    d9_with_lock($config, static function () use ($config, $mark, $message, $now) {
        $next = d9_log_mark(d9_read_state($config), $mark, $now);
        if ($next !== null) {
            d9_write_state($config, $next);
            d9_log($config, $message);
        }
    });
}

function d9_export_check(array $config, string $key, int $now, string $ip): string
{
    return d9_key_check($config, D9_EXPORT_KEY, $key, $now, $ip);
}

function d9_status_key_check(array $config, string $key, int $now, string $ip): string
{
    return d9_key_check($config, D9_STATUS_KEY, $key, $now, $ip);
}

/** Ключ выгрузки или смены статусов от 24 знаков и не из повторов: «donat9donat9donat9donat9» не годится. */
function d9_export_key_strong(string $key): bool
{
    return strlen($key) >= 24 && count(array_unique(str_split($key))) >= 12;
}

/**
 * Статус заявки для окна на сайте под блокировкой: лимит проверок (адрес и сеть по хешу с солью, все вместе),
 * чистка по сроку хранения, поиск записи. Ответ только с номером, статусом и датой (d9_status_answer).
 */
function d9_lookup_status(array $config, string $id, int $now, string $ip): array
{
    return d9_with_lock($config, static function () use ($config, $id, $now, $ip) {
        $state = d9_cleanup($config, d9_read_state($config), $now);
        $salt = d9_state_salt($state);
        $rate = is_array($state['status_rate'] ?? null) ? $state['status_rate'] : [];
        $limit = d9_status_limit($rate, d9_ip_key($ip, $salt), d9_net_key($ip, $salt), $now);
        d9_write_state($config, array_merge($state, ['salt' => $salt, 'status_rate' => $limit['rate']]));
        if (!$limit['allowed']) {
            return ['ok' => false, 'error' => 'rate'];
        }
        return d9_status_answer(d9_find_record(d9_read_records($config), $id, $now, (int) $config['retention_days']));
    });
}

/**
 * Смена статуса под блокировкой: меняется одна строка leads.jsonl, остальные строки, и те, что не разобрать,
 * остаются как есть. false, если заявки нет или она старше срока хранения; тогда файл не трогается.
 */
function d9_change_status(array $config, string $id, string $status, int $now): bool
{
    return d9_with_lock($config, static function () use ($config, $id, $status, $now) {
        $lines = d9_read_lines($config);
        if (d9_find_record(d9_records_of($lines), $id, $now, (int) $config['retention_days']) === null) {
            return false;
        }
        $next = d9_lines_with_status($lines, $id, $status, $now);
        if ($next === null) {
            return false;
        }
        d9_write_lines($config, $next);
        return true;
    });
}

function d9_send_email(array $config, array $record, array $files): bool
{
    if ($config['leads_email'] === '') {
        d9_log($config, 'Нет leads_email в config.php: письмо о заявке ' . $record['id'] . ' не отправлено');
        return false;
    }
    $lead = array_merge($record, ['file_names' => $record['files']]);
    [$subject, $body, $headers] = d9_build_email($lead, $files, (string) $config['mail_from'], 'd9-' . bin2hex(random_bytes(8)));
    if ($config['mail_transport'] === 'file') {
        $outbox = $config['data_dir'] . '/outbox';
        @mkdir($outbox, 0700, true);
        return file_put_contents($outbox . '/' . $record['id'] . '.eml',
            'To: ' . $config['leads_email'] . "\r\nSubject: " . $subject . "\r\n" . $headers . "\r\n\r\n" . $body) !== false;
    }
    // На Рег.ру используем существующий доменный ящик для возвратов и подписи писем.
    $sent = $config['mail_from'] === 'info@donat9.com'
        ? mail((string) $config['leads_email'], $subject, $body, $headers, '-finfo@donat9.com')
        : mail((string) $config['leads_email'], $subject, $body, $headers);
    if (!$sent) {
        d9_log($config, 'Письмо о заявке ' . $record['id'] . ' не ушло: проверь почту хостинга');
    }
    return $sent;
}

/** Как идёт сигнал в Telegram: 'relay' через Apps Script, 'direct' прямо в Bot API, 'off'. */
function d9_signal_mode(array $config): string
{
    if (!function_exists('curl_init')) {
        return 'off';
    }
    if ($config['signal_relay_url'] !== '' && strlen((string) $config['signal_relay_key']) >= 24) {
        return 'relay';
    }
    return $config['telegram_bot_token'] !== '' && $config['telegram_chat_id'] !== '' ? 'direct' : 'off';
}

/**
 * Сигнал в Telegram без персональных данных. Прямой вызов Bot API из России упирается в блокировку
 * (05.11.2026 api.telegram.org не отвечал с московских узлов), поэтому основной путь: ретранслятор
 * Apps Script (Code.gs, свойство SIGNAL_KEY). Сбой только пишется в журнал: заявка уже сохранена.
 */
function d9_send_signal(array $config, array $record): bool
{
    $mode = d9_signal_mode($config);
    if ($mode === 'off') {
        return false;
    }
    $text = d9_signal_text(array_merge($record, ['file_names' => $record['files']]));
    $relay = $mode === 'relay';
    $curl = curl_init($relay ? (string) $config['signal_relay_url']
        : 'https://api.telegram.org/bot' . $config['telegram_bot_token'] . '/sendMessage');
    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $relay ? http_build_query(['signal_key' => $config['signal_relay_key'], 'text' => $text])
            : json_encode(['chat_id' => $config['telegram_chat_id'], 'text' => $text], JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER => [$relay ? 'Content-Type: application/x-www-form-urlencoded' : 'Content-Type: application/json'],
        CURLOPT_FOLLOWLOCATION => $relay, // Apps Script отвечает через редирект на googleusercontent.com
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => $relay ? 20 : 5,
    ]);
    $answer = curl_exec($curl);
    $ok = is_string($answer) && (json_decode($answer, true)['ok'] ?? false) === true;
    if (!$ok) {
        d9_log($config, 'Сигнал в Telegram о заявке ' . $record['id'] . ' не ушёл (' . $mode . '): ' . curl_error($curl));
    }
    curl_close($curl);
    return $ok;
}

/**
 * Обработка заявки с сайта: ответ сайту в том же формате, что Code.gs, и что сделать после ответа
 * (письмо и сигнал: посетитель не должен ждать почту и Telegram).
 * @return array ['answer' => array, 'after' => callable|null]
 */
function d9_handle_post(array $post, array $config, int $now, string $ip = '', string $documentRoot = ''): array
{
    $check = d9_validate_lead($post);
    if ($check['verdict'] === 'bot') {
        return ['answer' => d9_site_answer(D9_BOT_TRAP_ID, trim(d9_str($post['files'] ?? '')) !== '' ? 'saved' : ''), 'after' => null];
    }
    if ($check['verdict'] === 'invalid') {
        return ['answer' => ['ok' => false, 'error' => 'validation', 'field' => $check['field']], 'after' => null];
    }
    $storage = d9_storage_state($config, $documentRoot);
    if ($storage !== 'ok') {
        d9_log_hourly($config, 'storage', 'Заявка не принята: папка данных ' . ($storage === 'public' ? 'внутри папки сайта' : 'недоступна для записи'), $now);
        return ['answer' => ['ok' => false, 'error' => 'server'], 'after' => null];
    }
    $saved = d9_store_lead($config, $check['lead'], $now, $ip);
    if ($saved === null) {
        return ['answer' => ['ok' => false, 'error' => 'rate'], 'after' => null];
    }
    // Заявка уже записана: сбой письма или сигнала не мешает ответить сайту успехом.
    $after = static function () use ($config, $saved) {
        d9_send_email($config, $saved['record'], $saved['files']);
        d9_send_signal($config, $saved['record']);
    };
    return ['answer' => d9_site_answer($saved['record']['id'], $saved['record']['files_status']), 'after' => $after];
}
